H.fireAt = async (modeIdx, hand) => {
  const s0 = await H.ui(); if (!s0.visibleAliens.length) return 'no alien';
  await page.locator('.bs-hand').nth(hand === undefined ? 1 : hand).tap(); await H.sleep(350);
  const it = page.locator('.bs-menu-item').nth(modeIdx || 0);
  if (!(await it.count()) || /off/.test(await it.getAttribute('class'))) { await H.longPress(600, 500, 700); return 'mode off'; }
  await it.tap(); await H.sleep(250);
  const a = s0.visibleAliens[0];
  const p = await page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), a.id);
  await H.tap(p.x, p.y); await H.sleep(300);
  const s1 = await H.ui();
  await H.tap(p.x, p.y); await H.sleep(300);
  for (let i = 0; i < 80; i++) { const s = await H.ui(); if (!s.playing) break; await H.sleep(150); }
  const s2 = await H.ui();
  const al = await page.evaluate((i) => { const u = OV.BUnits.findUnit(OV.Game.B, i); return u ? [u.status, u.hp] : null; }, a.id);
  return { label: s1.target && s1.target.label, tu: s2.unit && s2.unit.tu, alien: al, vis: s2.visibleAliens.length, mode: s2.mode };
};
return 'ok';
