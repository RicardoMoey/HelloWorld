H.turnPlay = async (gx, gy) => {
  const out = [];
  const b = await H.bs(); if (!b || !b.al.length) return ['no aliens'];
  for (const [id, nm] of b.xs) {
    const bb = await H.bs(); if (!bb || !bb.al.length) break;
    const idx = await page.evaluate((n) => [...document.querySelectorAll('.bs-sq')].findIndex(q => (q.getAttribute('aria-label') || '').startsWith(n)), nm);
    if (idx < 0) continue;
    await H.sel(idx); let s = await H.ui(); if (s.selectedId !== id) continue;
    let r = s.visibleAliens.length ? await H.fireAt(0) : null;
    if (r && r.mode === 'target') { await H.longPress(700, 650, 700); r = null; }
    if (!r) {
      s = await H.ui();
      const t = await H.pick(id, gx, gy, s.unit.tu - 16);
      if (t) { const w = await H.walk(t.x, t.y, 0); out.push(nm + '→' + w.unit.x + ',' + w.unit.y); }
      s = await H.ui();
      if (s.visibleAliens.length && s.unit && s.unit.tu >= 14) { r = await H.fireAt(0); if (r && r.mode === 'target') await H.longPress(700, 650, 700); }
    }
    if (r) out.push(nm + ' fire ' + (r.label || r) + ' → ' + JSON.stringify(r.alien));
  }
  return out;
};
return 'ok';
