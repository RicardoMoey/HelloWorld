// Persistent iPad driver: keeps one browser page alive; accepts JS snippets over HTTP (POST /run) and evaluates
// them in Node with helpers (page, cdp, tap, longPress, pinch, pan2, shot, st, log...). Throwaway QA tool.
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');
const DIR = __dirname;
const GAME_PORT = +process.argv[2];
const CTRL_PORT = +process.argv[3];
const T0 = Date.now();
const logf = path.join(DIR, 'log.txt');
function log(m) { const l = ((Date.now() - T0) / 1000).toFixed(1).padStart(7) + 's ' + m; fs.appendFileSync(logf, l + '\n'); return l; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let browser, ctx, page, cdp, shotN = 0;
const errors = [];
async function open(w, h) {
  if (ctx) await ctx.close();
  ctx = await browser.newContext({
    viewport: { width: w, height: h }, deviceScaleFactor: 2, hasTouch: true, isMobile: true,
    userAgent: 'Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
  });
  page = await ctx.newPage();
  page.on('pageerror', (e) => { errors.push('pageerror: ' + e.message); log('PAGEERROR ' + e.message); });
  page.on('console', (m) => { if (m.type() === 'error') { errors.push('console: ' + m.text()); log('CONSOLE ' + m.text()); } });
  cdp = await ctx.newCDPSession(page);
  await page.goto('http://127.0.0.1:' + GAME_PORT + '/ovni-1999/index.html?nosw=1');
}
async function touchSeq(seq) {
  for (const s of seq) {
    await cdp.send('Input.dispatchTouchEvent', { type: s.type, touchPoints: (s.pts || []).map((p, i) => ({ x: p[0], y: p[1], id: i })) });
    if (s.wait) await sleep(s.wait);
  }
}
const H = {
  sleep, log, errors,
  get page() { return page; }, get cdp() { return cdp; },
  open,
  async tap(x, y) { await page.touchscreen.tap(x, y); },
  async tapSel(sel, i) { const l = page.locator(sel).nth(i || 0); await l.tap(); },
  async longPress(x, y, ms) { await touchSeq([{ type: 'touchStart', pts: [[x, y]], wait: ms || 700 }, { type: 'touchEnd', pts: [] }]); },
  async drag1(x, y, dx, dy, steps) { steps = steps || 10; const seq = [{ type: 'touchStart', pts: [[x, y]], wait: 30 }]; for (let k = 1; k <= steps; k++) seq.push({ type: 'touchMove', pts: [[x + dx * k / steps, y + dy * k / steps]], wait: 25 }); seq.push({ type: 'touchEnd', pts: [] }); await touchSeq(seq); },
  async pinch(cx, cy, from, to) { const steps = 8; const seq = [{ type: 'touchStart', pts: [[cx - from, cy], [cx + from, cy]], wait: 30 }]; for (let k = 1; k <= steps; k++) { const d = from + (to - from) * k / steps; seq.push({ type: 'touchMove', pts: [[cx - d, cy], [cx + d, cy]], wait: 30 }); } seq.push({ type: 'touchEnd', pts: [] }); await touchSeq(seq); },
  async pan2(cx, cy, dx, dy) { const steps = 8; const seq = [{ type: 'touchStart', pts: [[cx - 40, cy], [cx + 40, cy]], wait: 30 }]; for (let k = 1; k <= steps; k++) seq.push({ type: 'touchMove', pts: [[cx - 40 + dx * k / steps, cy + dy * k / steps], [cx + 40 + dx * k / steps, cy + dy * k / steps]], wait: 30 }); seq.push({ type: 'touchEnd', pts: [] }); await touchSeq(seq); },
  async twoTap(cx, cy) { await touchSeq([{ type: 'touchStart', pts: [[cx - 30, cy], [cx + 30, cy]], wait: 80 }, { type: 'touchEnd', pts: [] }]); },
  touchSeq,
  async shot(name) { shotN++; const f = path.join(DIR, 'shots', String(shotN).padStart(3, '0') + '_' + name + '.png'); await page.screenshot({ path: f }); return f; },
  async st() { return page.evaluate(() => ({ top: OV.Scenes.top() && OV.Scenes.top().id, stack: OV.Scenes.stack.map((s) => s.id), date: OV.Game && OV.Game.G ? OV.U.fmtDate(OV.Game.G.t) : null, geo: OV.GeoUI && OV.GeoUI.current ? OV.GeoUI.current() : null })); },
  async btns(scope) { return page.evaluate((scope) => [...document.querySelectorAll((scope || '#hud, #modals') + ' button, ' + (scope || '#hud, #modals') + ' .btn, ' + (scope || '#hud, #modals') + ' [data-act]')].filter((n) => { const b = n.getBoundingClientRect(); return b.width > 0 && b.height > 0 && getComputedStyle(n).visibility !== 'hidden'; }).map((n) => { const b = n.getBoundingClientRect(); return [(n.getAttribute('aria-label') || n.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 30), n.className.toString().slice(0, 40), Math.round(b.x), Math.round(b.y), Math.round(b.width), Math.round(b.height), n.disabled ? 'D' : '']; }), scope); },
  async small(scope) { return page.evaluate((scope) => [...document.querySelectorAll(scope || '#hud button, #modals button, #hud .btn, #modals .btn, #hud [data-act], #modals [data-act], #hud [role=button], #hud input, #modals input, #hud select, #modals select')].filter((n) => { const b = n.getBoundingClientRect(); return b.width > 0 && b.height > 0 && getComputedStyle(n).visibility !== 'hidden' && (b.height < 31.5 || b.width < 31.5); }).map((n) => { const b = n.getBoundingClientRect(); return (n.getAttribute('aria-label') || n.textContent || n.className).toString().trim().replace(/\s+/g, ' ').slice(0, 26) + ' [' + n.className.toString().split(' ')[0] + '] ' + Math.round(b.width) + 'x' + Math.round(b.height); }), scope); },
  async text(sel) { return page.evaluate((s) => { const n = document.querySelector(s || 'body'); return n ? n.innerText.replace(/\s+/g, ' ').trim().slice(0, 1500) : null; }, sel); },
  async scrollInfo() { return page.evaluate(() => ({ sw: document.documentElement.scrollWidth, sh: document.documentElement.scrollHeight, iw: innerWidth, ih: innerHeight, sx: scrollX, sy: scrollY, vv: visualViewport ? { s: visualViewport.scale, ox: visualViewport.offsetLeft, oy: visualViewport.offsetTop } : null })); },
};
(async () => {
  browser = await chromium.launch();
  await open(1194, 834);
  log('driver ready');
  http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', async () => {
      let out;
      try {
        const fn = new Function('H', 'with (H) { return (async () => { ' + body + ' })(); }');
        out = await fn(H);
      } catch (e) { out = 'ERR ' + (e && e.stack || e); }
      res.end(typeof out === 'string' ? out : JSON.stringify(out, null, 0));
    });
  }).listen(CTRL_PORT, '127.0.0.1');
})();
