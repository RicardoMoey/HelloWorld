H.bs = () => page.evaluate(() => { const B = OV.Game.B; if (!B) return null; return { turn: B.turn, side: B.side, map: [B.map.w, B.map.h, B.map.d], ufo: B.ufo, xs: B.units.filter(u => u.side === 'xcom' && u.onMap && u.status === 'ok').map(u => [u.id, u.name ? u.name.split(' ')[0] : '', u.x, u.y, u.z, u.tu, u.hp]), al: B.units.filter(u => u.side === 'alien' && u.status === 'ok' && u.onMap).map(u => [u.id, u.type || u.race, u.x, u.y, u.z, B.visibleTo ? 1 : 0]), vis: OV.BattleUI.debug.state().visibleAliens }; });
H.tts = (x, y, z) => page.evaluate(([a, b, c]) => OV.BattleUI.debug.tileToScreen(a, b, c), [x, y, z]);
H.onScreen = (p) => { const vp = page.viewportSize(); return p && p.x > 200 && p.x < vp.width - 40 && p.y > 60 && p.y < vp.height - 160; };
H.walk = async (x, y, z) => {
  let p = await H.tts(x, y, z || 0);
  for (let k = 0; k < 4 && !H.onScreen(p); k++) { await H.pan2(600, 400, Math.max(-300, Math.min(300, 600 - p.x)), Math.max(-250, Math.min(250, 380 - p.y))); await H.sleep(250); p = await H.tts(x, y, z || 0); }
  await H.tap(p.x, p.y); await H.sleep(350);
  const s1 = await page.evaluate(() => OV.BattleUI.debug.state());
  await H.tap(p.x, p.y); await H.sleep(300);
  for (let i = 0; i < 80; i++) { const s = await page.evaluate(() => OV.BattleUI.debug.state()); if (!s.playing) break; await H.sleep(150); }
  const s2 = await page.evaluate(() => OV.BattleUI.debug.state());
  return { p, lockLabel: s1.pathLabel, lock: s1.lock, unit: s2.unit, vis: s2.visibleAliens, mode: s2.mode };
};
H.sel = async (i) => { await page.locator('.bs-sq').nth(i).tap(); await H.sleep(250); };
return 'ok';
