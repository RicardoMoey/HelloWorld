H.advance = async (gx, gy, keep) => {
  const out = [];
  const b = await H.bs();
  for (let k = 0; k < b.xs.length; k++) {
    const [id, nm, x, y, z, tu] = b.xs[k];
    const idx = await page.evaluate((id) => [...document.querySelectorAll('.bs-sq')].findIndex(n => (n.getAttribute("aria-label")||"").startsWith(id)), nm);
    await H.sel(idx >= 0 ? idx : k);
    const s0 = await H.ui(); if (s0.selectedId !== id) { out.push('selfail ' + nm); continue; }
    if (s0.visibleAliens.length) { out.push('ALIENS VISIBLE'); break; }
    const t = await H.pick(id, gx, gy, tu - keep); if (!t) { out.push(nm + ': no tile'); continue; }
    const r = await H.walk(t.x, t.y, 0);
    out.push(nm + '→' + r.unit.x + ',' + r.unit.y + ' tu' + r.unit.tu + ' vis' + r.vis.length);
    if (r.vis.length) { await H.shot('alien_seen'); break; }
  }
  return out;
};
H.endTurn = async () => {
  const t0 = Date.now();
  await H.tapSel('.bs-end'); await H.sleep(400);
  if (await page.locator('#modals .btn.primary').count()) await H.tapSel('#modals .btn.primary');
  let s; for (let i = 0; i < 400; i++) { await H.sleep(200); s = await H.ui(); if (s.ended || s.result || (s.side === 'xcom' && !s.playing && s.phase === 'play' && Date.now() - t0 > 1500)) break; }
  const dt = (Date.now() - t0) / 1000; H.log('end turn → turn ' + s.turn + ' in ' + dt + 's');
  return [dt, s.turn, s.visibleAliens, s.result];
};
return 'ok';
