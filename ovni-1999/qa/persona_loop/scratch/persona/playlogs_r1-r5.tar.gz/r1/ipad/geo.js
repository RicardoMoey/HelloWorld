H.runUntilEvent = async (speedIdx, maxS) => {
  const t0 = Date.now();
  let s = await H.st();
  if (s.top === 'geoscape' && !(s.geo.popup || s.geo.dialog)) await H.tapSel('.geo-speeds .geo-sp', speedIdx);
  for (let i = 0; i < (maxS || 60) * 4; i++) {
    await H.sleep(250); s = await H.st();
    if (s.top !== 'geoscape' || (s.geo && (s.geo.popup || s.geo.dialog))) break;
  }
  const txt = await H.text('.geo-pop:not(.out)');
  H.log('event after ' + ((Date.now() - t0) / 1000) + 's: ' + s.top + ' ' + (s.geo && s.geo.popup) + ' ' + s.date + ' | ' + (txt || '').slice(0, 120));
  return { dt: (Date.now() - t0) / 1000, top: s.top, popup: s.geo && s.geo.popup, date: s.date, txt };
};
H.popBtn = async (label) => { const b = page.locator('.geo-pop:not(.out) .btn', { hasText: label }); if (!(await b.count())) return false; await b.first().tap(); await H.sleep(400); return true; };
return 'ok';
