// choose a known, reachable tile for unit id that gets closest to goal (gx,gy), costing <= maxTu
H.pick = (id, gx, gy, maxTu) => page.evaluate(([id, gx, gy, maxTu]) => {
  const B = OV.Game.B, m = B.map, u = OV.BUnits.findUnit(B, id);
  const occ = new Set(B.units.filter(x => x.onMap && x.status !== 'dead').map(x => x.x + ',' + x.y));
  let best = null;
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = x + y * m.w; if (!(m.disc[i] & 1) || occ.has(x + ',' + y)) continue;
    const d = Math.hypot(x - gx, y - gy); if (best && d >= best.d) continue;
    if (Math.hypot(x - u.x, y - u.y) > 12) continue;
    const wp = OV.Act.walkPreview(B, u, i, {}); if (!wp || !wp.tiles.length || wp.tu > maxTu || wp.marks.some(k => k === 2)) continue;
    best = { x, y, d, tu: wp.tu };
  }
  return best;
}, [id, gx, gy, maxTu]);
H.ui = () => page.evaluate(() => OV.BattleUI.debug.state());
return 'ok';
