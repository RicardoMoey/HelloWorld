S.st = () => page.evaluate(() => OV.BattleUI.debug.state());
S.waitIdle = async (max=60000) => { const t0=Date.now(); while(Date.now()-t0<max){ const s=await S.st(); if(!s || s.ended) return s; if(!s.playing && s.side==='xcom') return s; await new Promise(r=>setTimeout(r,250)); } return await S.st(); };
S.clickTile = async (x,y,z) => { await page.evaluate(([a,b,c])=>OV.BattleUI.debug.centre(a,b,c),[x,y,z]); await new Promise(r=>setTimeout(r,450)); const p=await page.evaluate(([a,b,c])=>OV.BattleUI.debug.tileToScreen(a,b,c),[x,y,z]); await page.mouse.move(p.x,p.y); await new Promise(r=>setTimeout(r,250)); const s=await S.st(); await page.mouse.click(p.x,p.y); await new Promise(r=>setTimeout(r,250)); const s2=await S.st(); if (s2.lock>=0) { await page.mouse.click(p.x,p.y); } return s; };
S.walkable = (x,y,z) => page.evaluate(([x,y,z])=>{ const B=OV.Game.B; return x>=0&&y>=0&&x<B.map.w&&y<B.map.h; },[x,y,z]);
return 'ok';
