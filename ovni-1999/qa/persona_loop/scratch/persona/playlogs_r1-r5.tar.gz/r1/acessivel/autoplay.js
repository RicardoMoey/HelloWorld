const sl = ms => new Promise(r=>setTimeout(r,ms));
const out=[];
const T0=Date.now();
for (let turn=0; turn<MAXT; turn++) {
  let s = await S.waitIdle(90000);
  if (!s || s.ended || s.result) { out.push('ended '+JSON.stringify(s&&s.result)); break; }
  const ids = await page.evaluate(()=>OV.Game.B.units.filter(u=>u.side==='xcom'&&u.status==='ok'&&u.x>=0).map(u=>u.id));
  for (const id of ids) {
    s = await S.st(); if (!s || s.ended || s.result) break;
    await page.evaluate((id)=>{const u=OV.Game.B.units.find(u=>u.id===id); const b=[...document.querySelectorAll('#hud button')].find(b=>b.getAttribute('aria-label')===u.name); if(b) b.click();}, id);
    await sl(200);
    s = await S.st(); if (!s.unit || s.unit.id!==id) continue;
    // fire if alien visible
    for (let shotN=0; shotN<2; shotN++) {
      s = await S.st();
      if (!s.visibleAliens.length) break;
      await page.keyboard.press('e'); await sl(250);
      s = await S.st();
      if (!s.menu || !s.menu.entries[0] || !s.menu.entries[0].enabled) { await page.keyboard.press('Escape'); await sl(150); break; }
      await page.keyboard.press('1'); await sl(200);
      const a = s.visibleAliens[0];
      await page.evaluate(([x,y,z])=>OV.BattleUI.debug.centre(x,y,z),[a.x,a.y,a.z]); await sl(400);
      const p = await page.evaluate((id)=>OV.BattleUI.debug.unitScreen(id), a.id);
      if (!p) { await page.keyboard.press('Escape'); break; }
      await page.mouse.move(p.x,p.y); await sl(300);
      const s2 = await S.st();
      if (!s2.target || s2.target.blocked || s2.target.hitPct < 15) { out.push('t'+s2.turn+' u'+id+' skip shot '+JSON.stringify(s2.target)); await page.keyboard.press('Escape'); await sl(150); break; }
      await page.mouse.click(p.x,p.y); await S.waitIdle(60000);
      out.push('t'+s2.turn+' u'+id+' fired '+s2.target.hitPct+'%');
    }
    s = await S.st(); if (!s || s.ended || s.result) break;
    if (!s.unit || s.unit.tu < 20) continue;
    // move toward UFO door area (~25,10)
    const u = s.unit;
    const va=s.visibleAliens[0]; const gx = va? va.x : GX, gy = va? va.y+2 : GY;
    const dx = Math.sign(gx-u.x)*Math.min(4,Math.abs(gx-u.x)), dy = Math.sign(gy-u.y)*Math.min(4,Math.abs(gy-u.y));
    if (!dx && !dy) continue;
    let moved=false;
    for (const [ox,oy] of [[0,0],[1,0],[0,1],[-1,0],[0,-1],[1,1]]) {
      const tx=u.x+dx+ox, ty=u.y+dy+oy;
      await page.evaluate(([a,b,c])=>OV.BattleUI.debug.centre(a,b,c),[tx,ty,0]); await sl(350);
      const p=await page.evaluate(([a,b,c])=>OV.BattleUI.debug.tileToScreen(a,b,c),[tx,ty,0]);
      await page.mouse.move(p.x,p.y); await sl(250);
      const sp=await S.st();
      if (sp.pathSteps>0 && sp.pathStates.every(x=>x==='ok'||x==='reserve')) { await page.mouse.click(p.x,p.y); await sl(200); const sl2=await S.st(); if (sl2.lock>=0) await page.mouse.click(p.x,p.y); await S.waitIdle(60000); moved=true; break; }
    }
  }
  s = await S.st(); if (!s || s.ended || s.result) { out.push('ended'); break; }
  await page.keyboard.press('Enter'); await sl(500);
  const conf = await page.evaluate(()=>!!document.querySelector('#modals .modal'));
  if (conf) { await page.keyboard.press('Enter'); }
  const ta=Date.now(); await sl(800); s = await S.waitIdle(120000);
  out.push('turn end '+(s&&s.turn)+' alienTurn '+((Date.now()-ta)/1000).toFixed(1)+'s');
}
out.push('elapsed '+((Date.now()-T0)/1000).toFixed(0)+'s');
out.push(await shot('autoplay-end'));
return out;
