const st = () => page.evaluate(() => (OV.BattleUI.scene && OV.BattleUI.debug.state()) || { gone: true, scene: OV.Scenes.top() && OV.Scenes.top().id });
const stack = () => page.evaluate(() => OV.Scenes.stack.map(s => s.id));
const tp = (x,y,z) => page.evaluate(([a,b,c]) => OV.BattleUI.debug.tileToScreen(a,b,c), [x,y,z]);
const up = (id) => page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), id);
const idle = async (ms=60000) => { const t=Date.now(); try { await page.waitForFunction(() => { if (!OV.BattleUI || !OV.BattleUI.scene) return true; if (OV.Scenes.top() && OV.Scenes.top().id !== 'battlescape') return true; const s = OV.BattleUI.debug.state(); return !!s && !s.playing && !OV.Presenter.playing; }, null, { timeout: ms }); } catch(e) { return 'TIMEOUT ' + (Date.now()-t); } return Date.now()-t; };
const units = () => page.evaluate(() => OV.Game.B ? OV.Game.B.units.map(u => ({id:u.id, side:u.side, x:u.x,y:u.y,z:u.z, hp:u.hp, tu:u.tu, st:u.status, name:u.name, vis: u.side!=='xcom' ? undefined : undefined})) : null);
const txt = (n=1500) => page.evaluate((n) => document.body.innerText.slice(0,n), n);
const toast = () => page.evaluate(() => [...document.querySelectorAll('.toast, .bs-toast, [class*=toast]')].map(e=>e.innerText).filter(Boolean));
const onView = (x,y) => page.evaluate(([x,y]) => { const e = document.elementFromPoint(x,y); return !!e && e.id === 'view'; }, [x,y]);
const sqClick = async (k) => { await page.locator('.bs-squad .bs-sq').nth(k).click(); await sleep(150); };
// kid move: click a point; returns result
const kidClick = async (x,y) => { await page.mouse.move(x,y,{steps:3}); await sleep(120); const s0 = await st(); await page.mouse.click(x,y); await sleep(200); const w = await idle(); const s1 = await st(); return {hover:s0.hover, label:s0.pathLabel, from: s0.unit && [s0.unit.x,s0.unit.y], to: s1.unit && [s1.unit.x,s1.unit.y,s1.unit.tu], ms:w, vis:(s1.visibleAliens||[]).length}; };
// find a reachable screen point toward screen up-left for current unit: try candidate points
const kidMove = async () => {
  const s = await st(); if (!s.unit) return 'nounit';
  const me = await up(s.unit.id); if (!me) return 'noscreen';
  const cands = [];
  for (const r of [260, 200, 150, 110, 70]) for (const a of [-2.6, -2.2, -2.9, -1.9, -3.1, -1.6]) cands.push([Math.round(me.x + r*Math.cos(a)), Math.round(me.y + 40 + r*0.6*Math.sin(a))]);
  for (const [x,y] of cands) {
    if (x<200||y<60||x>1270||y>640) continue;
    if (!(await onView(x,y))) continue;
    await page.mouse.move(x,y,{steps:2}); await sleep(80);
    const h = await st();
    if (h.pathLabel && /^UT \d+\/\d+ ·/.test(h.pathLabel) && !/insuf/.test(h.pathLabel) && h.pathSteps>1) {
      await page.mouse.click(x,y); await sleep(200); const w = await idle(); const s1 = await st();
      return {lab:h.pathLabel, to: s1.unit && [s1.unit.x,s1.unit.y,s1.unit.tu], ms:w, vis:(s1.visibleAliens||[]).length};
    }
  }
  return 'nomove';
};
const kidShoot = async (which='Tiro rápido') => {
  const s = await st(); if (!s.visibleAliens.length) return 'novis';
  await page.mouse.click(567,730); await sleep(250);
  const m = (await st()).menu; if (!m) return 'nomenu';
  const e = m.entries.find(e=>e.label.startsWith(which) && e.enabled) || m.entries.find(e=>e.enabled);
  if (!e) { await page.keyboard.press('Escape'); return 'noentry'; }
  await page.click('.bs-menu-item:has-text("'+e.label+'")'); await sleep(200);
  const a = (await st()).visibleAliens[0]; const p = await up(a.id);
  if (!p || !(await onView(p.x,p.y))) { await page.keyboard.press('c'); }
  const p2 = await up(a.id);
  await page.mouse.move(p2.x,p2.y,{steps:2}); await sleep(150);
  const t = (await st()).target;
  await page.mouse.click(p2.x,p2.y); await sleep(250); const w = await idle();
  const s2 = await st();
  return {e:e.label, t: t && t.label, ms:w, mode:s2.mode, toasts: await toast()};
};
// approach a tile (tx,ty): click on the screen point of the closest reachable tile toward it
const kidApproach = async (tx,ty,tz=0) => {
  const s = await st(); if (!s.unit) return 'nounit';
  const u = s.unit; const cands=[];
  for (let f=0.9; f>=0.2; f-=0.15) { const x=Math.round(u.x+(tx-u.x)*f), y=Math.round(u.y+(ty-u.y)*f); cands.push([x,y]); cands.push([x+1,y]); cands.push([x,y+1]); cands.push([x-1,y]); cands.push([x,y-1]); }
  for (const [x,y] of cands) {
    const p = await tp(x,y,tz); if (!p || p.x<200||p.y<60||p.x>1270||p.y>640) continue;
    if (!(await onView(p.x,p.y))) continue;
    await page.mouse.move(p.x,p.y,{steps:2}); await sleep(80);
    const h = await st();
    if (h.pathLabel && /^UT \d+\/\d+ ·/.test(h.pathLabel) && !/insuf/.test(h.pathLabel) && h.pathSteps>1) {
      await page.mouse.click(p.x,p.y); await sleep(200); const w = await idle(); const s1 = await st();
      return {lab:h.pathLabel, to: s1.unit && [s1.unit.x,s1.unit.y,s1.unit.tu], ms:w};
    }
  }
  return 'nomove';
};
const kidApproach2 = async (tx,ty,tz=0,minD=2) => {
  const s = await st(); if (!s.unit) return 'nounit';
  const u = s.unit; const cands=[];
  for (let dx=-10; dx<=10; dx++) for (let dy=-10; dy<=10; dy++) { const x=tx+dx,y=ty+dy; const d=Math.max(Math.abs(dx),Math.abs(dy)); if (d<minD) continue; const du=Math.max(Math.abs(x-u.x),Math.abs(y-u.y)); if (du>12||du<2) continue; cands.push([d+du*0.1,x,y]); }
  cands.sort((a,b)=>a[0]-b[0]);
  let tries=0;
  for (const [,x,y] of cands) {
    if (tries++>40) break;
    const p = await tp(x,y,tz); if (!p || p.x<200||p.y<60||p.x>1270||p.y>640) continue;
    if (!(await onView(p.x,p.y))) continue;
    await page.mouse.move(p.x,p.y,{steps:1}); await sleep(60);
    const h = await st();
    if (h.pathLabel && /^UT \d+\/\d+ ·/.test(h.pathLabel) && !/insuf/.test(h.pathLabel) && h.pathSteps>1) {
      await page.mouse.click(p.x,p.y); await sleep(200); const w = await idle(); const s1 = await st();
      return {lab:h.pathLabel, to: s1.unit && [s1.unit.x,s1.unit.y,s1.unit.tu], ms:w};
    }
  }
  return 'nomove';
};
const mapInfo = () => page.evaluate(() => ({w:OV.Game.B.map.w, h:OV.Game.B.map.h, d:OV.Game.B.map.d}));
const xcomIdx = async () => (await units()).filter(u=>u.side==='xcom');
const kidTurn = async (goal) => {
  const out=[]; const t0=Date.now();
  const xs = await xcomIdx();
  for (let k=0;k<xs.length;k++){
    const cur=(await xcomIdx())[k]; if(!cur || cur.st!=='ok') continue;
    if ((await stack()).slice(-1)[0] !== 'battlescape') { out.push('scene:'+(await stack()).slice(-1)[0]); break; }
    await sqClick(k);
    let s = await st(); if (!s.unit || s.unit.id!==cur.id) { out.push('selfail'); continue; }
    if (s.visibleAliens.length) {
      let r = await kidShoot();
      if (r && r.t && /Sem linha|na linha/.test(r.t)) { await page.keyboard.press('Escape'); await sleep(120); const a=s.visibleAliens[0]; const m = await kidApproach3(a.x,a.y,a.z,3); r = {first:'blocked', mv:m, again: await kidShoot()}; if ((await st()).mode==='target'){ await page.keyboard.press('Escape'); await sleep(100);} }
      out.push([cur.name, r]);
      // second shot if TU
      const s2 = await st(); if (s2.visibleAliens && s2.visibleAliens.length && s2.unit && s2.unit.tu>20) { const r2 = await kidShoot(); out.push(['again', r2 && r2.t]); if ((await st()).mode==='target'){ await page.keyboard.press('Escape'); await sleep(100);} }
    } else {
      const r = await kidApproach4(goal[0], goal[1], 0); out.push([cur.name, r]);
      const s3=await st(); if (s3.visibleAliens && s3.visibleAliens.length && s3.unit && s3.unit.tu>15) { const r2=await kidShoot(); out.push(['spot-shoot', r2 && r2.t]); if ((await st()).mode==='target'){ await page.keyboard.press('Escape'); await sleep(100);} }
    }
  }
  return {out, ms: Date.now()-t0};
};
const endTurn = async () => {
  const t0 = Date.now(); const turn=(await st()).turn;
  await page.keyboard.press('Enter'); await sleep(400);
  const dlg = await page.locator('button:visible', {hasText:'TERMINAR TURNO'}).count();
  if (dlg) { await page.locator('label:visible', {hasText:'Não voltar'}).click().catch(()=>0); await page.locator('.modal button:visible, .dlg button:visible, button:visible', {hasText:'TERMINAR TURNO'}).last().click(); }
  let s; for (let i=0;i<400;i++){ const sc=(await stack()).slice(-1)[0]; if (sc!=='battlescape') return {ms:Date.now()-t0, scene:sc}; s=await st(); if (s.side==='xcom' && s.turn>turn && !s.playing) break; await sleep(250); }
  return {ms: Date.now()-t0, turn: s.turn, vis: s.visibleAliens.length};
};
const census = async () => { const us=await units(); return us.reduce((a,u)=>{ const k=u.side+':'+u.st; a[k]=(a[k]||0)+1; return a; },{}); };
const fmt = (o) => { if (!Array.isArray(o)) return String(o); const v=o[1]; if (typeof v==='string' || v==null) return o[0]+':'+v; return o[0]+':'+(v.t||v.lab||JSON.stringify(v).slice(0,90)); };
const playTurns = async (n, goal, tag) => {
  const res=[];
  for (let t=0;t<n;t++){
    if ((await stack()).slice(-1)[0]!=='battlescape') break;
    const r=await kidTurn(goal);
    await shot(tag+'_turn_'+(await st()).turn);
    if ((await stack()).slice(-1)[0]!=='battlescape') { res.push({out:r.out.map(fmt)}); break; }
    const e=await endTurn();
    res.push({turn:e.turn, scene:e.scene, play:r.ms, out:r.out.map(fmt), alienTurn:e.ms, c: await census(), toasts: await toast()});
  }
  return res;
};
const _origApproach = kidApproach2;
const kidApproach3 = async (tx,ty,tz=0,minD=1) => { await page.keyboard.press('c'); await sleep(350); let r = await _origApproach(tx,ty,tz,minD); if (r==='nomove') { // pan toward the goal and retry
  const s=await st(); const u=s.unit; const keys=[]; const p=await tp(tx,ty,tz); if (p.x>900) keys.push('ArrowRight'); if (p.x<300) keys.push('ArrowLeft'); if (p.y>550) keys.push('ArrowDown'); if (p.y<100) keys.push('ArrowUp');
  for (const k of keys) await page.keyboard.down(k); await sleep(500); for (const k of keys) await page.keyboard.up(k); await sleep(200); r = await _origApproach(tx,ty,tz,minD); }
  return r; };
const kidApproach4 = async (tx,ty,tz=0) => {
  const s = await st(); if (!s.unit) return 'nounit';
  const best = await page.evaluate(([id,tx,ty]) => { const B=OV.Game.B, m=B.map, u=OV.BUnits.findUnit(B,id); const plane=m.w*m.h; const r=OV.Path.reachable(B,u,Math.max(0,u.tu-14),u.energy|0); let best=null,bd=1e9; for (const i of r.list) { if (B._.unitAt[i]) continue; const z=(i/plane)|0, rr=i-z*plane, x=rr%m.w, y=(rr/m.w)|0; if (z!==u.z) continue; const d=Math.hypot(x-tx,y-ty); if (d<bd){bd=d;best={x,y,z};} } return best; }, [s.unit.id,tx,ty]);
  if (!best) return 'nobest';
  await page.evaluate(([x,y,z]) => OV.BattleUI.debug.centre(x,y,z), [best.x,best.y,best.z]); await sleep(300);
  const p = await tp(best.x,best.y,best.z); if (!(await onView(p.x,p.y))) return 'offview';
  await page.mouse.move(p.x,p.y,{steps:2}); await sleep(100); const h=await st();
  await page.mouse.click(p.x,p.y); await sleep(200); const w = await idle(); const s1 = await st();
  return {lab:h.pathLabel, to: s1.unit && [s1.unit.x,s1.unit.y,s1.unit.tu], ms:w};
};
