// persistent playwright driver: POST node-side JS (async body with `page`) to localhost:DPORT
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const GPORT = process.argv[2], DPORT = process.argv[3];
const DIR = __dirname;
const T0 = Date.now();
const log = (m) => fs.appendFileSync(DIR + '/log.txt', ((Date.now() - T0) / 1000).toFixed(1) + 's ' + m + '\n');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await ctx.newPage();
  const errs = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') { errs.push(m.type() + ': ' + m.text()); } });
  page.on('pageerror', (e) => errs.push('PAGEERROR: ' + e.message));
  page.on('dialog', (d) => { errs.push('DIALOG: ' + d.message()); d.accept(); });
  await page.goto(`http://127.0.0.1:${GPORT}/ovni-1999/index.html?nosw=1`);
  let n = 0;
  const shot = async (name) => { n++; const f = DIR + '/shots/' + String(n).padStart(3, '0') + '_' + name + '.png'; await page.screenshot({ path: f }); return f; };
  const ctxObj = { page, shot, log, errs, sleep: (ms) => page.waitForTimeout(ms), browser };
  http.createServer((req, res) => {
    let body = ''; req.on('data', (c) => body += c);
    req.on('end', async () => {
      try {
        const fn = new Function('c', 'return (async () => { const {page, shot, log, errs, sleep} = c; ' + body + ' })()');
        const r = await fn(ctxObj);
        res.end(JSON.stringify(r, null, 1) || 'undefined');
      } catch (e) { res.end('ERR ' + e.stack); }
    });
  }).listen(DPORT, '127.0.0.1');
  log('driver up');
})();
