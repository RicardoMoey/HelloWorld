const names = await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.name));
const res = [];
for (const n of names) {
  const l = page.getByText(n, { exact: true });
  await l.last().click(); await S.sleep(250);
  await page.getByRole('button', { name: /auto-equipar/i }).click(); await S.sleep(250);
}
const f = await shot('autoequipped');
await page.getByRole('button', { name: /conclu/i }).first().click(); await S.sleep(600);
return { f, lo: await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.name + ':' + JSON.stringify(s.loadout))) };
