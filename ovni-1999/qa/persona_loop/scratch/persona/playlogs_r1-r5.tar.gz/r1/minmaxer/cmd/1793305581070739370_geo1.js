await page.keyboard.press('Escape');
await S.sleep(800);
await page.keyboard.press('6');
const t0 = Date.now();
// wait until a modal appears or 20 s
await page.waitForFunction(() => { const m = document.querySelector('#modals'); return m && m.innerText.trim().length > 20; }, null, { timeout: 30000 }).catch(() => {});
const f = await shot('geo_event');
return { secs: (Date.now() - t0) / 1000, f, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), modal: await page.evaluate(() => document.querySelector('#modals').innerText.slice(0, 1500)) };
