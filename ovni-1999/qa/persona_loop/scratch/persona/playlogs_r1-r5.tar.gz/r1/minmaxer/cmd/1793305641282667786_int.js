await page.keyboard.press('i');
await S.sleep(800);
const f = await shot('intercept');
return { f, pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 1500))) };
