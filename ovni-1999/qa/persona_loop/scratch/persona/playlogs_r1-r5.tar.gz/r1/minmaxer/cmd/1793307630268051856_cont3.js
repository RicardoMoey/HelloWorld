await page.keyboard.press('Enter'); await S.sleep(2500);
for (let k = 0; k < 3; k++) { const p = await page.evaluate(() => { const p = document.querySelector('.geo-pop, .geo-dlg'); return p ? p.innerText.slice(0, 200) : null; }); if (!p) break; await page.keyboard.press('Enter'); await S.sleep(400); }
return { sc: await page.evaluate(() => OV.Scenes.top().id), date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), funds: await page.evaluate(() => OV.Game.G.funds) };
