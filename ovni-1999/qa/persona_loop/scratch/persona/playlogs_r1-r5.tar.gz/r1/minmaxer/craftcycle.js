const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const C = OV.Campaign, W = OV.World, BS = OV.BaseSim, D = OV.Data;
function run(cycle) {
  const G = C.newCampaign({ seed: 7, difficulty: 1 });
  const b = G.bases[0];
  const DAY = 86400; let lastM = 0, it = 0; const log = [];
  while (G.t < 95 * DAY && !G.ended) {
    const end = OV.Clock.monthStartT(G.month + 1);
    if (cycle && G.t >= end - 3600 * 2 && G.t < end) {
      for (const id of Object.keys(G.crafts)) { const c = G.crafts[id]; if (c.type === 'interceptor') { const r = BS.sellCraft(G, c.id); log.push('sell ' + c.id + ' ' + JSON.stringify(r)); } }
    }
    const st = W.step(G, 360); G.events.length = 0; if (++it > 200000) { log.push("STUCK t=" + G.t + " " + JSON.stringify(st) + " df=" + (G.dogfights||[]).length + " am=" + !!G.activeMission); break; }
    if (G.month !== lastM) {
      lastM = G.month; const r = G.reports[G.reports.length - 1];
      log.push('monthEnd ' + r.month + ' upkeep ' + JSON.stringify(r.upkeep) + ' funds ' + G.funds);
      if (cycle) { const r2 = BS.buy(G, b.id, 'interceptor', 2); log.push('buy ' + JSON.stringify(r2) + ' funds ' + G.funds); }
    }
  }
  const nI = Object.values(G.crafts).filter(c => c.type === 'interceptor').length;
  log.push('END funds ' + G.funds + ' interceptors ' + nI);
  return log.join('\n');
}
console.log('--- no cycle\n' + run(false)); console.log('--- cycle\n' + run(true));
