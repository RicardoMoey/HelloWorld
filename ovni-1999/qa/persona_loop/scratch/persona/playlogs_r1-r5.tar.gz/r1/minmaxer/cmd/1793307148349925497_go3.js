await page.getByRole('button', { name: /conclu/i }).first().click(); await S.sleep(600);
for (let k = 0; k < 3 && (await page.evaluate(() => OV.Scenes.top().id)) !== 'geoscape'; k++) { await page.keyboard.press('Escape'); await S.sleep(600); }
await page.getByText('OVNI-5').first().click(); await S.sleep(600);
await page.keyboard.press('e'); await S.sleep(700);
const t = await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 500)));
await page.locator('.geo-dlg').getByText('Skyranger-2').first().click(); await S.sleep(500);
return t;
