await page.keyboard.press('Escape'); await S.sleep(500);
await page.getByRole('button', { name: /sair para o menu/i }).click(); await S.sleep(800);
const f1 = await shot('quit_confirm');
const t1 = await page.evaluate(() => document.body.innerText.slice(-600));
return { f1, t1 };
