await page.getByText('FUNDAR BASE').first().click();
await S.sleep(2500);
const f = await shot('geoscape');
return { f, diff: await page.evaluate(() => OV.Game.G.difficulty), scene: await page.evaluate(() => OV.Scenes.top().id), text: await page.evaluate(() => document.body.innerText.slice(0, 1500)) };
