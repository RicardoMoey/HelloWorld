await page.keyboard.press('b'); await S.sleep(1200);
await page.keyboard.press('8'); await S.sleep(800);
const f = await shot('market');
const t = await page.evaluate(() => document.body.innerText);
return { f, t: t.slice(t.indexOf('HANGARES') , t.indexOf('HANGARES') + 2500) };
