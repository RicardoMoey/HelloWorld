await page.keyboard.press('e'); await S.sleep(700);
await page.locator('.geo-dlg').getByText('Skyranger-1').first().click(); await S.sleep(500);
return await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 300)));
