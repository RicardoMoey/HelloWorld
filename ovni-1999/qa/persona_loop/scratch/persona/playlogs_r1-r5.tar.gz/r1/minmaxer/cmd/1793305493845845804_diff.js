await page.keyboard.press('3');
await S.sleep(300);
await page.getByText('ESCOLHER LOCAL').first().click();
await S.sleep(1500);
const f = await shot('chooseloc');
return { f, text: await page.evaluate(() => document.body.innerText.slice(0, 1200)) };
