const idle = async (ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const p = await page.evaluate(() => { const s = OV.BattleUI.debug.state(); return s.playing || s.side !== 'xcom'; }); if (!p) return true; await S.sleep(150); } return false; };
const sel = async (id) => { const p = await page.evaluate((id) => OV.BattleUI.debug.unitScreen(id), id); await page.mouse.click(p.x, p.y + 8); await S.sleep(250); };
const click = async (x, y, z = 0) => { const p = await page.evaluate(([x, y, z]) => OV.BattleUI.debug.tileToScreen(x, y, z), [x, y, z]); await page.mouse.move(p.x, p.y); await S.sleep(120); await page.mouse.click(p.x, p.y); await S.sleep(250); return p; };
const mv = async (id, x, y, z = 0) => { await sel(id); await page.evaluate(([x,y,z]) => OV.BattleUI.debug.centre(x,y,z), [x,y,z]); await S.sleep(200); await click(x, y, z); const lk = await page.evaluate(() => OV.BattleUI.debug.state().lock); if (lk) await click(x, y, z); await S.sleep(200); await idle(); };
const st = () => page.evaluate(() => { const B = OV.Game.B; const s = OV.BattleUI.debug.state(); return { turn: B.turn, side: s.side, phase: B.phase, result: B.result, vis: s.visibleAliens, xcom: B.units.filter(u => u.side === 'xcom' && u.status !== 'dead').map(u => [u.id, u.x, u.y, u.z, u.tu, u.hp, u.status, u.kneeling ? 'K' : '']), aliens: B.units.filter(u => u.side === 'alien' && B._.visible.xcom.has(u.id)).map(u => [u.id, u.type, u.x, u.y, u.z, u.hp]) }; });
const endTurn = async () => { await page.keyboard.press('Enter'); await S.sleep(500); const d = await page.evaluate(() => /Ainda há soldados/.test(document.body.innerText)); if (d) await page.keyboard.press('Enter'); await S.sleep(800); for (let i = 0; i < 120; i++) { await page.keyboard.press('Space'); await S.sleep(400); const s = await page.evaluate(() => { const s = OV.BattleUI.debug.state(); return { side: s.side, playing: s.playing, ended: s.ended, sc: OV.Scenes.top().id }; }); if (s.ended || s.sc !== 'battlescape' || (s.side === 'xcom' && !s.playing)) break; } };
const shootAt = async (id, alienId, mode = '2') => { await sel(id); await page.keyboard.press('e'); await S.sleep(300); await page.keyboard.press(mode); await S.sleep(300); const p = await page.evaluate((a) => OV.BattleUI.debug.unitScreen(a), alienId); await page.mouse.move(p.x, p.y + 8); await S.sleep(200); await page.mouse.click(p.x, p.y + 8); await S.sleep(300); await idle(); };
const canShoot = (id, aid, mode) => page.evaluate(([id, aid, mode]) => { const B = OV.Game.B; const v = OV.Act.validate(B, { type: 'shoot', unitId: id, hand: 'R', mode, target: { unitId: aid } }); return v.ok; }, [id, aid, mode]);
const turnPlay = async (goal, step = 6) => {
  const log = [];
  const s0 = await st();
  for (const u of s0.xcom) {
    if (u[6] !== 'ok') continue;
    let s = await st(); if (s.result || s.phase === 'over') break;
    // shoot visible aliens if possible
    for (let k = 0; k < 3; k++) {
      s = await st(); if (!s.aliens.length) break;
      let fired = false;
      for (const a of s.aliens) {
        for (const [mode, key] of [['aimed', '2'], ['snap', '1']]) {
          if (await canShoot(u[0], a[0], mode)) { await shootAt(u[0], a[0], key); log.push('shoot ' + u[0] + '->' + a[0] + ' ' + mode); fired = true; break; }
        }
        if (fired) break;
      }
      if (!fired) break;
    }
    s = await st(); const me = s.xcom.find((x) => x[0] === u[0]); if (!me || s.aliens.length) continue;
    const dx = Math.sign(goal[0] - me[1]) * Math.min(step, Math.abs(goal[0] - me[1])), dy = Math.sign(goal[1] - me[2]) * Math.min(step, Math.abs(goal[1] - me[2]));
    const tx = me[1] + dx + ((u[0] % 3) - 1), ty = me[2] + dy;
    await mv(u[0], tx, ty); log.push('mv ' + u[0] + ' ' + tx + ',' + ty);
  }
  return log;
};
const pickTile = (id, goal, keepTU) => page.evaluate(([id, goal, keepTU]) => {
  const B = OV.Game.B; const u = OV.BUnits.findUnit(B, id); const m = B.map; let best = null, bd = 1e9;
  for (let dx = -10; dx <= 10; dx++) for (let dy = -10; dy <= 10; dy++) {
    const x = u.x + dx, y = u.y + dy; if (x < 0 || y < 0 || x >= m.w || y >= m.h) continue;
    const i = (u.z * m.h + y) * m.w + x; if (OV.Battle.unitAt(B, i)) continue;
    const p = OV.Act.walkPreview(B, u, i); if (!p || !p.tu || p.tu > u.tu - keepTU) continue;
    const d = Math.hypot(goal[0] - x, goal[1] - y); if (d < bd) { bd = d; best = [x, y, u.z, p.tu]; }
  }
  return best;
}, [id, goal, keepTU]);
const advance = async (id, goal, keepTU = 20) => { const t = await pickTile(id, goal, keepTU); if (!t) return null; await mv(id, t[0], t[1], t[2]); return t; };
const kneelAll = async () => { const s = await st(); for (const u of s.xcom) { if (u[7] !== 'K' && u[4] >= 4) { await sel(u[0]); await page.keyboard.press('k'); await S.sleep(300); await idle(); } } };
const fullTurn = async (goal, keep = 18) => {
  const log = [];
  const s0 = await st();
  for (const u of s0.xcom) {
    if (u[6] !== 'ok') continue;
    for (let k = 0; k < 3; k++) {
      const s = await st(); if (s.phase === 'over' || !s.aliens.length) break;
      let fired = false;
      for (const a of s.aliens) { for (const [mode, key] of [['aimed', '2'], ['snap', '1']]) { if (await canShoot(u[0], a[0], mode)) { await shootAt(u[0], a[0], key); log.push('shoot ' + u[0] + '->' + a[0] + ' ' + mode); fired = true; break; } } if (fired) break; }
      if (!fired) break;
    }
    const s = await st(); if (s.phase === 'over') break;
    if (!s.aliens.length) log.push(['adv', u[0], await advance(u[0], goal, keep)]);
  }
  return log;
};
