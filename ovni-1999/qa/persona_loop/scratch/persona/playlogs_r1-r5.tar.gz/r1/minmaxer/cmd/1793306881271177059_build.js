await page.keyboard.press('1'); await S.sleep(600);
const pick = async (name) => { await page.evaluate((name) => { const el = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && e.textContent.trim() === name); let r = el; for (let i = 0; i < 4 && r; i++) { if (r.tagName === 'BUTTON' || r.onclick || r.getAttribute && r.getAttribute('role') === 'button') break; r = r.parentElement; } (r || el).click(); }, name); await S.sleep(400); };
await pick('Alojamentos');
await page.mouse.click(103 + 91 * 1, 201 + 91 * 2); await S.sleep(500);
const f1 = await shot('build_lq');
const t1 = await page.evaluate(() => document.body.innerText.slice(-400));
return { f1, t1 };
