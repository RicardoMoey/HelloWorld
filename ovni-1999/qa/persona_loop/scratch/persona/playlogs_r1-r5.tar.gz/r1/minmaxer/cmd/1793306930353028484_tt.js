return await page.evaluate(() => ({ t: OV.Game.G.t, d: OV.Clock.date(OV.Game.G.t), m1: OV.Clock.monthStartT(1) }));
