const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const C = OV.Campaign, W = OV.World, BS = OV.BaseSim, D = OV.Data;
const G = C.newCampaign({ seed: 7, difficulty: 1 });
const DAY=86400; let day=0;
while (G.t < 90*DAY && !G.ended) { W.step(G,720); G.events.length=0; if (Math.floor(G.t/DAY)%15===0 && Math.floor(G.t/DAY)!==day){day=Math.floor(G.t/DAY); console.log('day',day,'funds',G.funds, G.reports.map(r=>r.income+'/'+r.upkeep.total+'/'+r.rating).join(' '));} }
console.log('ended', G.ended, G.funds);
