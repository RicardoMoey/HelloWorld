await page.keyboard.press('Enter'); await S.sleep(2500);
const f = await shot('after_abort_geo');
return { f, crafts: await page.evaluate(() => Object.values(OV.Game.G.crafts).map(c => c.id + ':' + c.type + ':' + c.status)), soldiers: await page.evaluate(() => Object.keys(OV.Game.G.soldiers).length), pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 400))) };
