await page.keyboard.press('e'); await S.sleep(700);
const t1 = await page.evaluate(() => [...document.querySelectorAll('.geo-dlg')].map(p => p.innerText.slice(0, 500)));
await page.locator('.geo-dlg').getByText('Skyranger-2').first().click(); await S.sleep(1200);
const t2 = await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 500)));
const f = await shot('restart_mission');
return { t1, t2, f, sc: await page.evaluate(() => OV.Scenes.top().id) };
