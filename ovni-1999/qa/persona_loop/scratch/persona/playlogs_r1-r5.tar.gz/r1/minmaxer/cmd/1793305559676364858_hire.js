const b = page.getByText('CONTRATAR +10');
await b.nth(1).click(); await S.sleep(300);
await b.nth(1).click(); await S.sleep(500);
const f = await shot('hired');
const t = await page.evaluate(() => document.body.innerText);
return { f, funds: await page.evaluate(() => OV.Game.G.funds), text: t.slice(t.indexOf('Engenheiros'), t.indexOf('Engenheiros') + 600) };
