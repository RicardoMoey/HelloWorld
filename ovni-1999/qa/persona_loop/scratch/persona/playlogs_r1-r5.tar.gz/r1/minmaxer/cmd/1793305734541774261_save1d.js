await page.mouse.click(1058, 488);
await S.sleep(800);
const f = await shot('saved');
const t = await page.evaluate(() => document.body.innerText.slice(0, 3000));
await page.keyboard.press('Escape');
await S.sleep(400);
return { f, t: t.slice(t.indexOf('GRAVAÇÕES'), t.indexOf('GRAVAÇÕES') + 600) };
