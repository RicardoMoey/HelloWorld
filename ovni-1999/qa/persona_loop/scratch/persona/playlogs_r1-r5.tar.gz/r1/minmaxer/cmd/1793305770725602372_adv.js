// advance time at speed SPEED, auto-dismiss benign popups, stop on others or after MAXS seconds
const SPEED = '3', MAXS = 60, BENIGN = /CHEGARAM ENCOMENDAS|INSTALAÇÃO CONCLUÍDA|FABRICO CONCLU|GRAVA/i;
const t0 = Date.now(); const seen = [];
await page.keyboard.press(SPEED);
while ((Date.now() - t0) / 1000 < MAXS) {
  await S.sleep(400);
  const pop = await page.evaluate(() => { const p = document.querySelector('.geo-pop, .geo-dlg'); return p ? p.innerText.slice(0, 900) : null; });
  if (pop) {
    seen.push(pop.slice(0, 120).replace(/\n/g, ' '));
    if (BENIGN.test(pop)) { await page.keyboard.press('Enter'); await S.sleep(300); await page.keyboard.press(SPEED); continue; }
    const f = await shot('pop');
    return { secs: (Date.now() - t0) / 1000, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), funds: await page.evaluate(() => OV.Game.G.funds), pop, f, seen };
  }
  const sc = await page.evaluate(() => OV.Scenes.top().id);
  if (sc !== 'geoscape') return { scene: sc, f: await shot('scene_' + sc), seen };
}
return { timeout: true, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), seen };
