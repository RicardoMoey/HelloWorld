await page.keyboard.press('n'); await S.sleep(1200);
const t = await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText.slice(0, 1500) : ''; });
const f = await shot('np');
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), t };
