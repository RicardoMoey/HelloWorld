await page.getByText('NOVA CAMPANHA').first().click();
await S.sleep(800);
const f = await shot('newcampaign');
return { f, text: await page.evaluate(() => document.body.innerText.slice(0, 1200)) };
