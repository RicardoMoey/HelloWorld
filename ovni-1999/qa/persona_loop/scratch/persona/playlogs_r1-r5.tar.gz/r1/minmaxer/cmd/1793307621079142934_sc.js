const f = await shot('state_now');
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), t: await page.evaluate(() => document.body.innerText.slice(0, 600)) };
