// persistent browser driver: executes cmd/NNN.js (async body with page, S, shot) -> cmd/NNN.out
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const DIR = __dirname;
const PORT = process.argv[2];
const T0 = Date.now();
const logf = path.join(DIR, 'log.txt');
const log = (m) => fs.appendFileSync(logf, ((Date.now() - T0) / 1000).toFixed(1).padStart(7) + 's ' + m + '\n');
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => { errors.push('pageerror: ' + e.message); log('PAGEERROR ' + e.message); });
  page.on('console', (m) => { if (m.type() === 'error') { errors.push('console: ' + m.text()); log('CONSOLE ERR ' + m.text()); } });
  await page.goto('http://127.0.0.1:' + PORT + '/ovni-1999/index.html?nosw=1');
  await page.waitForTimeout(2000);
  log('driver ready');
  const S = { errors, log, sleep: (ms) => page.waitForTimeout(ms) };
  let n = 0;
  const shot = async (name) => { const f = path.join(DIR, 'shots', String(++n).padStart(3, '0') + '_' + name + '.png'); await page.screenshot({ path: f }); return f; };
  S.shot = shot;
  const done = new Set();
  for (;;) {
    const files = fs.readdirSync(path.join(DIR, 'cmd')).filter((f) => f.endsWith('.js') && !done.has(f)).sort();
    for (const f of files) {
      done.add(f);
      const body = fs.readFileSync(path.join(DIR, 'cmd', f), 'utf8');
      let out;
      try {
        const fn = new (Object.getPrototypeOf(async function () {}).constructor)('page', 'S', 'shot', body);
        const r = await fn(page, S, shot);
        out = JSON.stringify(r, null, 1);
      } catch (e) { out = 'ERROR ' + (e && e.stack || e); }
      if (errors.length) { out += '\nERRORS: ' + errors.join('\n'); errors.length = 0; }
      fs.writeFileSync(path.join(DIR, 'cmd', f.replace('.js', '.out')), out || 'undefined');
      if (body.includes('__quit__')) { await browser.close(); process.exit(0); }
    }
    await new Promise((r) => setTimeout(r, 150));
  }
})();
