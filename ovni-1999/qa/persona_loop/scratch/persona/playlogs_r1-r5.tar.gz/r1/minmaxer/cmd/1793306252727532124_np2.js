await page.locator('#modals').getByText('INICIAR').nth(2).click(); await S.sleep(800);
await page.keyboard.press('3'); await S.sleep(800);
await page.keyboard.press('n'); await S.sleep(1000);
const t = await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText.slice(0, 1500) : ''; });
const f = await shot('newprod');
return { f, t };
