const goMenuLoad = async () => {
  await page.keyboard.press('Escape'); await S.sleep(500);
  await page.getByRole('button', { name: /sair para o menu/i }).first().click(); await S.sleep(500);
  await page.getByRole('button', { name: /sair para o menu/i }).last().click(); await S.sleep(1500);
  await page.getByText('CARREGAR').first().click(); await S.sleep(800);
  await page.evaluate(() => { const el = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && /OVNI Aterrado · turno/.test(e.textContent)); let r = el; for (let i = 0; i < 6; i++) { r = r.parentElement; const b = [...r.querySelectorAll('button')].find(b => /abrir/i.test(b.textContent)); if (b) { b.click(); return; } } });
  await S.sleep(4000);
  return page.evaluate(() => ({ sc: OV.Scenes.top().id, turn: OV.Game.B && OV.Game.B.turn }));
};
const report = () => page.evaluate(() => { const B = OV.Game.B; return { turn: B.turn, x: B.units.filter(u => u.origSide === 'xcom' && u.status !== 'dead').map(u => u.id + ':' + u.status + ':' + u.hp + '@' + u.x + ',' + u.y).join(' '), a: B.units.filter(u => u.origSide === 'alien').map(u => u.id + ':' + u.status + ':' + u.hp + '@' + u.x + ',' + u.y).join(' ') }; });
