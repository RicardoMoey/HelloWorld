await page.keyboard.press('6'); await S.sleep(800);
const f = await shot('crafts_new');
const t = await page.evaluate(() => document.body.innerText);
const i = t.indexOf('Naves\n');
return { f, t: t.slice(i, i + 1200), sold: await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.name + ':' + s.craftId + ':' + s.loadout.R)) };
