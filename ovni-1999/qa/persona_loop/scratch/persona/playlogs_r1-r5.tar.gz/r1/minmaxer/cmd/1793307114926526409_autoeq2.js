const f = await shot('equip_partial');
return { f, lo: await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.name + ':' + JSON.stringify(s.loadout))) };
