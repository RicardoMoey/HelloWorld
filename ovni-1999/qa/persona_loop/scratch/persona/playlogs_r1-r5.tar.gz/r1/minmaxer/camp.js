const sim = require('/home/user/HelloWorld/ovni-1999/tools/sim.js');
const OV = globalThis.OV;
const drain = (g, B) => { let r; for (;;) { r = g.next(); if (r.done) return r.value; } };
function campTurn(B, shoot) {
  for (const u of B.units.filter((u) => u.side === 'xcom' && u.status === 'ok' && u.onMap)) {
    if (!u.kneeling) { const v = OV.Act.validate(B, { type: 'kneel', unitId: u.id }); if (v.ok) drain(OV.Act.perform(B, { type: 'kneel', unitId: u.id })); }
    if (!shoot) continue;
    for (let k = 0; k < 3; k++) {
      const vis = B.units.filter((a) => a.side === 'alien' && (a.status === 'ok' || a.status === 'panic') && a.onMap && B._.visible && B._.visible.xcom && B._.visible.xcom.has(a.id));
      if (!vis.length) break;
      let done = false;
      for (const a of vis) for (const mode of ['aimed', 'snap']) {
        if (done) break;
        const act = { type: 'shoot', unitId: u.id, hand: 'R', mode, target: { unitId: a.id } };
        if (OV.Act.validate(B, act).ok) { drain(OV.Act.perform(B, act)); done = true; }
      }
      if (!done) break;
    }
  }
}
function run(o, strat) {
  const mission = sim.missionFor(o);
  const B = OV.Battle.create(mission);
  drain(OV.Battle.beginBattle(B));
  while (B.phase !== 'over' && B.turn <= 40) {
    if (strat === 'bot') drain(OV.AI.turn(B, 'xcom'));
    else campTurn(B, strat === 'campshoot');
    if (B.phase !== 'over') drain(OV.Battle.endPlayerTurn(B));
  }
  const outcome = B.phase === 'over' ? B.result || OV.Battle.outcome(B) : 'cap';
  return { outcome, turns: B.turn, xcomDead: B.units.filter((u) => u.origSide === 'xcom' && u.status === 'dead').length, kills: B.stats.aliensKilled, aliens: B.units.filter(u=>u.origSide==='alien').length };
}
const [ufo, kind, diff, month, seeds] = [process.argv[2] || 'small_scout', process.argv[3] || '', +(process.argv[4] || 2), +(process.argv[5] || 0), +(process.argv[6] || 10)];
for (const strat of ['bot', 'camp', 'campshoot']) {
  const rows = [];
  for (let s = 1; s <= seeds; s++) rows.push(run({ ufo, kind: kind || undefined, diff, month, seed: s, squad: 8, terrain: 'FOREST' }, strat));
  const w = rows.filter((r) => r.outcome === 'win').length;
  const med = rows.map(r=>r.turns).sort((a,b)=>a-b)[rows.length>>1];
  console.log(strat.padEnd(10), ufo, kind, 'win', w + '/' + rows.length, 'loss', rows.filter(r=>r.outcome==='loss').length, 'cap', rows.filter(r=>r.outcome==='cap').length, 'medTurns', med, 'avgDead', (rows.reduce((a, r) => a + r.xcomDead, 0) / rows.length).toFixed(2), 'avgKills', (rows.reduce((a,r)=>a+r.kills,0)/rows.length).toFixed(1));
}
