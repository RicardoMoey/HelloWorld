await page.getByRole('button', { name: /^construir$/i }).last().click(); await S.sleep(500);
const pick = async (name) => { await page.evaluate((name) => { const el = [...document.querySelectorAll('*')].find(e => e.childElementCount === 0 && e.textContent.trim() === name); let r = el; for (let i = 0; i < 4 && r; i++) { if (r.tagName === 'BUTTON' || r.getAttribute('role') === 'button') break; r = r.parentElement; } (r || el).click(); }, name); await S.sleep(400); };
await pick('Oficina');
await page.keyboard.down('Shift'); await page.mouse.click(103 + 91 * 4, 201 + 91 * 2); await page.keyboard.up('Shift'); await S.sleep(500);
await pick('Laboratório');
await page.keyboard.down('Shift'); await page.mouse.click(103 + 91 * 5, 201 + 91 * 3); await page.keyboard.up('Shift'); await S.sleep(500);
const f = await shot('built');
return { f, grid: await page.evaluate(() => OV.Game.G.bases[0].grid.map(g => g.type + '@' + g.x + ',' + g.y + ':' + g.daysLeft).join(' ')), funds: await page.evaluate(() => OV.Game.G.funds) };
