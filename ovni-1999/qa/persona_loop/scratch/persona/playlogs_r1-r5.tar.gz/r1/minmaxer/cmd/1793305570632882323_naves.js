await page.keyboard.press('6');
await S.sleep(800);
const f = await shot('naves');
const t = await page.evaluate(() => document.body.innerText);
return { f, text: t.slice(t.indexOf('HANGARES'), t.indexOf('HANGARES') + 2000) };
