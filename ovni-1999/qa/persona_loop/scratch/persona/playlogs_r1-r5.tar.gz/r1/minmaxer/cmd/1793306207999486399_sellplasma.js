const sellN = async (id, n) => {
  const row = page.locator('[data-sell="' + id + '"]');
  for (let k = 1; k < n; k++) { await row.locator('button', { hasText: /^\+$/ }).click(); await S.sleep(60); }
  await row.locator('[data-act=sell]').click(); await S.sleep(400);
};
const f0 = await page.evaluate(() => OV.Game.G.funds);
await sellN('plasma_pistol', 3);
await sellN('plasma_pistol_clip', 7);
await sellN('sectoid_corpse', 3);
await sellN('medikit', 2);
const f = await shot('sold');
return { before: f0, after: await page.evaluate(() => OV.Game.G.funds), f };
