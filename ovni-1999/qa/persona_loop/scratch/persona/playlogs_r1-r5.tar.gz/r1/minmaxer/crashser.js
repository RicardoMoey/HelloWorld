const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
for (let seed = 1; seed < 40; seed++) {
  const m = OV.Battle.quickMission({ ufoType: 'medium_scout', terrain: 'FOREST', kind: 'crash', difficulty: 2, month: 0, squadSize: 8, seed });
  m.kind = 'crash';
  const B = OV.Battle.create(m);
  const cd = B.units.filter(u => u.crashDead).length;
  if (!cd) continue;
  const B2 = OV.Battle.deserialize(JSON.parse(JSON.stringify(OV.Battle.serialize(B))));
  console.log('seed', seed, 'crashDead orig', cd, 'after serialize', B2.units.filter(u => u.crashDead).length, 'stats', B2.stats.crashDead);
  // finish: kill all aliens
  for (const B_ of [B, B2]) for (const u of B_.units) if (u.side === 'alien' && u.status === 'ok') { u.status = 'dead'; }
  const d1 = OV.Battle.debrief(B, {}), d2 = OV.Battle.debrief(B2, {});
  const k = (d) => (d.lines || d.score_lines || []).filter ? JSON.stringify((d.lines||[]).find(l => /aliensKilled/.test(l.key || l[0]))) : '';
  console.log('  score orig', d1.score, 'after ser', d2.score, k(d1), k(d2));
  break;
}
