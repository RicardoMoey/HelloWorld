await page.getByRole('button', { name: /sair para o menu/i }).last().click(); await S.sleep(1500);
await page.getByText('CARREGAR').first().click(); await S.sleep(1000);
const f = await shot('load_menu');
return { f, t: await page.evaluate(() => document.body.innerText.slice(0, 1200)) };
