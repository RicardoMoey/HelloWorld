const f = await shot('load_state2');
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), t: await page.evaluate(() => document.body.innerText.slice(0, 800)) };
