const idle = async (ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const p = await page.evaluate(() => { const s = OV.BattleUI.debug.state(); return s.playing || s.side !== 'xcom'; }); if (!p) return true; await S.sleep(150); } return false; };
const sel = async (id) => { const p = await page.evaluate((id) => OV.BattleUI.debug.unitScreen(id), id); await page.mouse.click(p.x, p.y + 8); await S.sleep(250); };
const click = async (x, y, z = 0) => { const p = await page.evaluate(([x, y, z]) => OV.BattleUI.debug.tileToScreen(x, y, z), [x, y, z]); await page.mouse.move(p.x, p.y); await S.sleep(120); await page.mouse.click(p.x, p.y); await S.sleep(250); return p; };
const mv = async (id, x, y, z = 0) => { await sel(id); await page.evaluate(([x,y,z]) => OV.BattleUI.debug.centre(x,y,z), [x,y,z]); await S.sleep(200); await click(x, y, z); const lk = await page.evaluate(() => OV.BattleUI.debug.state().lock); if (lk) await click(x, y, z); await S.sleep(200); await idle(); };
const st = () => page.evaluate(() => { const B = OV.Game.B; const s = OV.BattleUI.debug.state(); return { turn: B.turn, side: s.side, phase: B.phase, result: B.result, vis: s.visibleAliens, xcom: B.units.filter(u => u.side === 'xcom' && u.status !== 'dead').map(u => [u.id, u.x, u.y, u.z, u.tu, u.hp, u.status, u.kneeling ? 'K' : '']), aliens: B.units.filter(u => u.side === 'alien' && B._.visible.xcom.has(u.id)).map(u => [u.id, u.type, u.x, u.y, u.z, u.hp]) }; });
// spread out: move soldiers east a bit
const moves = [[1, 9, 13], [7, 10, 15], [13, 9, 17], [19, 10, 19]];
for (const [id, x, y] of moves) await mv(id, x, y);
const f = await shot('t1_moves');
return { f, s: await st() };
