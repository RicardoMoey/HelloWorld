await page.keyboard.press('Enter');
await S.sleep(400);
await page.keyboard.press('s');
await S.sleep(800);
const f = await shot('savedlg');
return { f, pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg, #modals')].map(p => p.innerText.slice(0, 1500))) };
