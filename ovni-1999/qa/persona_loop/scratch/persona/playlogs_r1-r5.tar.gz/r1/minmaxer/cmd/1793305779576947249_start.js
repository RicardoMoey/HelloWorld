await page.keyboard.press('Enter');
await S.sleep(2500);
const f = await shot('briefing');
return { f, scene: await page.evaluate(() => OV.Scenes.top().id), t: await page.evaluate(() => document.body.innerText.slice(0, 1500)) };
