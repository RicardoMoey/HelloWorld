await page.keyboard.press('Enter');
await S.sleep(2000);
const f = await shot('after_debrief');
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 400))) };
