return await page.evaluate(() => ({ shade: OV.Game.B.mission.shade, night: OV.Game.B.mission.night }));
