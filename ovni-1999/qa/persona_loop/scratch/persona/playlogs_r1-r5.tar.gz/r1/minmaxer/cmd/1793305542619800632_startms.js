const items = page.locator('#modals').getByText('INICIAR');
await items.nth(2).click();
await S.sleep(800);
await page.keyboard.press('3');
await S.sleep(800);
const f = await shot('production');
return { f, text: await page.evaluate(() => document.body.innerText.split('Investigação')[0].slice(-10) + document.body.innerText.slice(document.body.innerText.indexOf('HANGARES'), 4000)) };
