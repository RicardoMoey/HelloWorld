await page.keyboard.press('2');
await S.sleep(800);
const f = await shot('research');
return { f, text: await page.evaluate(() => document.querySelector('#modals, body').innerText.slice(0, 2500)) };
