await page.keyboard.press('e');
await S.sleep(800);
const f = await shot('send_team');
const t = await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 900)));
return { f, t };
