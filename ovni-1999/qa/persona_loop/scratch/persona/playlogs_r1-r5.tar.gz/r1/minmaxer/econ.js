const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const C = OV.Campaign, W = OV.World, BS = OV.BaseSim, D = OV.Data;
const item = process.argv[2] || 'motion_scanner';
const extraEng = +(process.argv[3] || 0);
const G = C.newCampaign({ seed: 7, difficulty: 1 });
const b = G.bases[0];
console.log('start funds', G.funds, 'eng', b.engineers, 'cap', JSON.stringify(BS.capacities(G, b.id).workshops));
const topic = D.manufacture[item].requires;
// research chain
function researchAll() {
  const av = C.availableResearch(G, b.id);
  if (!b.research || !b.research.length) {
    // research needed topic chain
  }
}
let order = { motion_scanner: ['motion_scanner'], medikit: ['medikit'], laser_cannon: ['laser_weapons', 'laser_pistol', 'laser_rifle', 'heavy_laser', 'laser_cannon'], laser_pistol: ['laser_weapons','laser_pistol'] }[item];
let oi = 0;
if (extraEng) console.log('hire', JSON.stringify(BS.hire(G, b.id, 'engineer', extraEng)));
let started = false, sold = 0, soldN = 0, day = 0;
const step = (h) => W.step(G, h * 720 / 1);
const DAY = 86400;
let prodStart = null;
while (G.t < 90 * DAY && !G.ended) {
  // research
  if (oi < order.length && G.researched.includes(order[oi])) oi++;
  const running = (b.research || []).length;
  if (oi < order.length && !running) {
    const r = BS.startResearch(G, b.id, order[oi], b.scientists);
    if (!r.ok) console.log('research fail', order[oi], r.reason);
  }
  if (!started && G.researched.includes(topic)) {
    const ws = BS.capacities(G, b.id).workshops;
    const free = BS.staff(G, b.id).engineers.free;
    const n = Math.min(free, ws.cap - ws.used - D.manufacture[item].space);
    const r = BS.startProduction(G, b.id, item, n, 0);
    console.log('day', (G.t / DAY).toFixed(1), 'start production', item, n, JSON.stringify(r.ok), r.reason || '', 'funds', G.funds);
    started = true; prodStart = G.funds;
  } else if (started) {
    const p = b.production[0];
    if (p && p.engineers < Math.min(BS.staff(G,b.id).engineers.total, 50 - D.manufacture[item].space)) BS.setEngineers(G, b.id, p.id, Math.min(BS.staff(G,b.id).engineers.total, 50 - D.manufacture[item].space));
  }
  const n = b.stores[item] | 0;
  const keep = item === 'medikit' ? 3 : 0;
  if (started && n > keep) { const r = BS.sell(G, b.id, item, n - keep); if (r.ok) { soldN += n - keep; sold += (n - keep) * D.items[item].sell; } }
  W.step(G, 720);
  // drain events
  G.events.length = 0;
  if (G.dogfights && G.dogfights.length) { /* ignore */ }
  if (Math.floor(G.t / DAY) % 15 === 0 && Math.floor(G.t / DAY) !== day) { day = Math.floor(G.t / DAY); console.log('day', day, 'funds', G.funds, 'sold', soldN, 'revenue', sold, 'month', G.month, 'reports', G.reports.length ? G.reports[G.reports.length-1].fundsAfter : ''); }
}
console.log('END funds', G.funds, 'soldN', soldN, 'revenue', sold);
