const f = await shot('menu');
return { f, scene: OV_scene = await page.evaluate(() => OV.Scenes.top() && OV.Scenes.top().id), text: await page.evaluate(() => document.body.innerText.slice(0, 500)) };
