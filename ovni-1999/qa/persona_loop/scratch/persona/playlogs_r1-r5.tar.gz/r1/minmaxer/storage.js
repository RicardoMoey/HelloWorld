const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const C = OV.Campaign, W = OV.World, BS = OV.BaseSim;
const G = C.newCampaign({ seed: 3, difficulty: 1 }); const b = G.bases[0];
G.researched.push('laser_weapons','laser_pistol','laser_rifle','heavy_laser');
console.log(BS.startProduction(G, b.id, 'heavy_laser', 10, 0).ok);
for (let d = 0; d < 60; d++) { for (let h = 0; h < 24; h++) { W.step(G, 720); G.events.length = 0; if (G.dogfights.length) G.dogfights.length = 0; } }
const cap = BS.capacities(G, b.id).storage; console.log('storage', JSON.stringify(cap), 'heavy lasers', b.stores.heavy_laser, 'prod', JSON.stringify(b.production.map(p=>[p.done,p.stalled])));
console.log('buy check', JSON.stringify(BS.buy(G, b.id, 'rifle', 1)));
