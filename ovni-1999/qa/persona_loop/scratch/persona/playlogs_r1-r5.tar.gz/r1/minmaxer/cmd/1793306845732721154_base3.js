const sellN = async (id, n) => {
  const row = page.locator('[data-sell="' + id + '"]');
  for (let k = 1; k < n; k++) { await row.locator('button', { hasText: /^\+$/ }).click(); await S.sleep(60); }
  await row.locator('[data-act=sell]').click(); await S.sleep(400);
};
await page.keyboard.press('Enter'); await S.sleep(400);
await page.keyboard.press('b'); await S.sleep(1200);
await page.keyboard.press('8'); await S.sleep(600);
await page.getByRole('button', { name: /vender/i }).first().click(); await S.sleep(600);
const n = await page.evaluate(() => OV.Game.G.bases[0].stores.motion_scanner | 0);
const f0 = await page.evaluate(() => OV.Game.G.funds);
const row = page.locator('[data-sell="motion_scanner"]');
await row.getByRole('button', { name: /tudo/i }).click(); await S.sleep(200);
await row.locator('[data-act=sell]').click(); await S.sleep(500);
const f = await shot('sold_scanners');
return { n, f0, f1: await page.evaluate(() => OV.Game.G.funds), f, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)) };
