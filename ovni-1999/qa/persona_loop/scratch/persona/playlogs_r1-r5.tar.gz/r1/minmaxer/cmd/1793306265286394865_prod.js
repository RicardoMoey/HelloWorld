await page.locator('#modals').getByText('∞').first().click(); await S.sleep(800);
const f = await shot('prod_running');
const t = await page.evaluate(() => document.body.innerText);
const i = t.indexOf('Produção');
return { f, t: t.slice(i, i + 900), research: await page.evaluate(() => OV.Game.G.bases[0].research) };
