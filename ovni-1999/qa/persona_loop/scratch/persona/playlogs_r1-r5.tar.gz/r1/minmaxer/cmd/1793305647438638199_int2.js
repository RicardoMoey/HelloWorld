await page.locator('.geo-dlg').getByText('Intercetor-1').first().click();
await S.sleep(800);
const f = await shot('intercept2');
return { f, pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 1500))) };
