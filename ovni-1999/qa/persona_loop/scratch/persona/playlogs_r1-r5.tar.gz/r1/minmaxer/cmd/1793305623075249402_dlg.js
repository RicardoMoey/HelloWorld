return await page.evaluate(() => [...document.querySelectorAll('[role=dialog], .dialog, .modal, .popup')].map(e => e.className + ' | ' + e.id + ' | ' + e.innerText.slice(0, 80)));
