await page.keyboard.press('Escape'); await S.sleep(800); return await page.evaluate(() => OV.Scenes.top().id);
