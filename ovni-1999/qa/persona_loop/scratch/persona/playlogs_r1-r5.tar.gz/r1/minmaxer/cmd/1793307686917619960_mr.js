const f = await shot('month_report');
return { f, t: await page.evaluate(() => document.body.innerText.slice(0, 1800)), rep: await page.evaluate(() => { const r = OV.Game.G.reports[OV.Game.G.reports.length - 1]; return { rating: r.rating, xcom: r.xcom, alien: r.alien, research: r.research, income: r.income, upkeep: r.upkeep.total, council: r.councilKey, bad: r.badMonths }; }) };
