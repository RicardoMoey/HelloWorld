await page.getByRole('button', { name: /vender/i }).first().click(); await S.sleep(800);
const f = await shot('market_sell');
const t = await page.evaluate(() => document.body.innerText);
const i = t.indexOf('Mercado');
return { f, t: t.slice(i, i + 3000) };
