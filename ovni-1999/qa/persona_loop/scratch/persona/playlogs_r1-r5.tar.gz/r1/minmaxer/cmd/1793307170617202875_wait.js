await page.keyboard.press('w'); await S.sleep(800);
const f = await shot('waiting');
return { f, pop: await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg')].map(p => p.innerText.slice(0, 500))), craft: await page.evaluate(() => { const c = OV.Game.G.crafts.c4; return [c.status, c.fuel, c.patrol]; }), ufo: await page.evaluate(() => OV.Game.G.ufos.map(u => u.id + ':' + u.status + ':' + u.crashLeftS)) };
