const prod = await page.evaluate(() => JSON.stringify(OV.Game.G.bases[0].production));
const f0 = await shot('geo_lowfunds');
await page.keyboard.press('b'); await S.sleep(1200);
await page.keyboard.press('8'); await S.sleep(600);
await page.getByRole('button', { name: /vender/i }).first().click(); await S.sleep(600);
const row = page.locator('[data-sell="motion_scanner"]');
await row.getByRole('button', { name: /tudo/i }).click(); await S.sleep(200);
await row.locator('[data-act=sell]').click(); await S.sleep(500);
return { prod, f0, funds: await page.evaluate(() => OV.Game.G.funds), date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)) };
