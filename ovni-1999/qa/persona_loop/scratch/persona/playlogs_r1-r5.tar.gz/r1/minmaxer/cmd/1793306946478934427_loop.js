// play geoscape until UNTIL (game date ms), auto handling
const UNTIL = 1020000; const t0 = Date.now(); const seen = [];
const sc = () => page.evaluate(() => OV.Scenes.top().id);
for (let k = 0; k < 3 && (await sc()) !== 'geoscape'; k++) { await page.keyboard.press('Escape'); await S.sleep(600); }
await page.keyboard.press('6');
let lastSell = 0;
while ((Date.now() - t0) / 1000 < 100) {
  await S.sleep(300);
  const s = await sc();
  if (s === 'dogfight') { await page.keyboard.press('2'); await S.sleep(1500); continue; }
  if (s !== 'geoscape') { seen.push('SCENE ' + s); break; }
  const g = await page.evaluate(() => ({ t: OV.Game.G.t, funds: OV.Game.G.funds, sc: OV.Game.G.bases[0].stores.motion_scanner | 0 }));
  if (g.t >= UNTIL) break;
  const pop = await page.evaluate(() => { const p = document.querySelector('.geo-pop, .geo-dlg'); return p ? p.innerText.slice(0, 600) : null; });
  if (pop) {
    const head = pop.split('\n').slice(0, 3).join(' ');
    seen.push(OV_d = head.slice(0, 140));
    if (/OVNI DETETADO/.test(pop) && /Em voo/.test(pop) && /INTERCETAR/.test(pop)) {
      await page.keyboard.press('i'); await S.sleep(600);
      const ok = await page.evaluate(() => { const d = document.querySelector('.geo-dlg'); if (!d) return false; const it = [...d.querySelectorAll('button, [role=button], .geo-dlg-row, li')].find(e => /Intercetor-\d/.test(e.innerText) && /Pronta/.test(e.innerText)); if (it) { it.click(); return true; } return false; });
      if (!ok) { await page.keyboard.press('Escape'); await S.sleep(300); }
      seen.push('  intercept ' + ok);
      await page.keyboard.press('3'); continue;
    }
    if (/INVESTIGAÇÃO CONCLUÍDA|NAVE PRONTA|EQUIPA NO LOCAL|ENVIAR EQUIPA|TERROR|ATAQUE|MENSAL|RELATÓRIO MENSAL/.test(pop) && !/CHEGARAM|INSTALA/.test(pop)) { await shot('loop_stop'); seen.push('STOP'); return { seen, pop, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)) }; }
    await page.keyboard.press('Enter'); await S.sleep(250); await page.keyboard.press('6');
  }
}
return { seen, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), funds: await page.evaluate(() => OV.Game.G.funds), scanners: await page.evaluate(() => OV.Game.G.bases[0].stores.motion_scanner | 0), secs: (Date.now() - t0) / 1000 };
