await S.sleep(1500);
const f = await shot('debrief');
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), t: await page.evaluate(() => document.body.innerText.slice(0, 2500)) };
