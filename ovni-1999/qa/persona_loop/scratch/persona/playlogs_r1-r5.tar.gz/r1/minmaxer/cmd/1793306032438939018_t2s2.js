const idle = async (ms = 20000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const p = await page.evaluate(() => { const s = OV.BattleUI.debug.state(); return s.playing || s.side !== 'xcom'; }); if (!p) return true; await S.sleep(150); } return false; };
const sel = async (id) => { const p = await page.evaluate((id) => OV.BattleUI.debug.unitScreen(id), id); await page.mouse.click(p.x, p.y + 8); await S.sleep(250); };
const click = async (x, y, z = 0) => { const p = await page.evaluate(([x, y, z]) => OV.BattleUI.debug.tileToScreen(x, y, z), [x, y, z]); await page.mouse.move(p.x, p.y); await S.sleep(120); await page.mouse.click(p.x, p.y); await S.sleep(250); return p; };
const mv = async (id, x, y, z = 0) => { await sel(id); await page.evaluate(([x,y,z]) => OV.BattleUI.debug.centre(x,y,z), [x,y,z]); await S.sleep(200); await click(x, y, z); const lk = await page.evaluate(() => OV.BattleUI.debug.state().lock); if (lk) await click(x, y, z); await S.sleep(200); await idle(); };
const st = () => page.evaluate(() => { const B = OV.Game.B; const s = OV.BattleUI.debug.state(); return { turn: B.turn, side: s.side, phase: B.phase, result: B.result, vis: s.visibleAliens, xcom: B.units.filter(u => u.side === 'xcom' && u.status !== 'dead').map(u => [u.id, u.x, u.y, u.z, u.tu, u.hp, u.status, u.kneeling ? 'K' : '']), aliens: B.units.filter(u => u.side === 'alien' && B._.visible.xcom.has(u.id)).map(u => [u.id, u.type, u.x, u.y, u.z, u.hp]) }; });
const endTurn = async () => { await page.keyboard.press('Enter'); await S.sleep(500); const d = await page.evaluate(() => /Ainda há soldados/.test(document.body.innerText)); if (d) await page.keyboard.press('Enter'); await S.sleep(800); for (let i = 0; i < 120; i++) { await page.keyboard.press('Space'); await S.sleep(400); const s = await page.evaluate(() => { const s = OV.BattleUI.debug.state(); return { side: s.side, playing: s.playing, ended: s.ended, sc: OV.Scenes.top().id }; }); if (s.ended || s.sc !== 'battlescape' || (s.side === 'xcom' && !s.playing)) break; } };
const shootAt = async (id, alienId, mode = '2') => { await sel(id); await page.keyboard.press('e'); await S.sleep(300); await page.keyboard.press(mode); await S.sleep(300); const p = await page.evaluate((a) => OV.BattleUI.debug.unitScreen(a), alienId); await page.mouse.move(p.x, p.y + 8); await S.sleep(200); await page.mouse.click(p.x, p.y + 8); await S.sleep(300); await idle(); };
await page.keyboard.press('Escape'); await S.sleep(200);
const log = [];
for (const id of [25, 31, 7, 13]) {
  const s = await st(); if (!s.aliens.length || s.result) break;
  await shootAt(id, 61, '2'); 
  const s2 = await st(); log.push([id, s2.aliens.map(a => a[5]), s2.xcom.find(u => u[0] === id)]);
}
const f = await shot('after_shots');
return { f, log, s: await st() };
