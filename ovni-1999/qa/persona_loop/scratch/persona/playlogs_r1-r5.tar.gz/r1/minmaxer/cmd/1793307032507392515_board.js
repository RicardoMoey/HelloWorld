await page.getByText('Skyranger-2').first().click(); await S.sleep(600);
const names = await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.name));
for (const n of names) { const l = page.getByText(n, { exact: true }); if (await l.count()) { await l.first().click(); await S.sleep(200); } }
const f = await shot('boarded');
return { f, crew: await page.evaluate(() => Object.values(OV.Game.G.soldiers).map(s => s.craftId).join(',')), t: (await page.evaluate(() => document.body.innerText)).match(/TRIPULAÇÃO[^\n]*/) };
