await page.keyboard.press('n');
await S.sleep(800);
const f = await shot('newproj');
return { f, text: await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText.slice(0, 2500) : ''; }) };
