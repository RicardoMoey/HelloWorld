const keys = await page.evaluate(() => Object.keys(localStorage));
const s1 = await page.evaluate(() => localStorage.getItem('ovni1999.save.1'));
require = null;
return { keys, len: s1 && s1.length, s1 };
