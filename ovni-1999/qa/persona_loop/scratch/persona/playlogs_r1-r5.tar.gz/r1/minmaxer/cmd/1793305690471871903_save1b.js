await page.getByText('GRAVAR', { exact: true }).first().click();
await S.sleep(800);
const f = await shot('saved');
await page.keyboard.press('Escape');
await S.sleep(400);
return { f };
