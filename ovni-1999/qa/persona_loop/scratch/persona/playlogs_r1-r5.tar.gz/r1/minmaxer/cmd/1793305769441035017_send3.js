await page.locator('.geo-dlg').getByText('Skyranger-1').first().click();
await S.sleep(500);
return 1;
