await page.keyboard.press('Enter');
await S.sleep(4000);
const f = await shot('battle_start');
return { f, scene: await page.evaluate(() => OV.Scenes.top().id), dbg: await page.evaluate(() => { const d = OV.BattleUI && OV.BattleUI.debug; return d ? Object.keys(d) : null; }) };
