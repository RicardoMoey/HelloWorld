const sellN = async (id, n) => {
  const row = page.locator('[data-sell="' + id + '"]');
  for (let k = 1; k < n; k++) { await row.locator('button', { hasText: /^\+$/ }).click(); await S.sleep(60); }
  await row.locator('[data-act=sell]').click(); await S.sleep(400);
};
