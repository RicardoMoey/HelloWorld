await page.getByText('OVNI-5').first().click(); await S.sleep(600);
const t = await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg, [class*=card]')].map(p => p.innerText.slice(0, 300)).slice(0, 2));
const f = await shot('ufo5_card');
return { t, f };
