const f0 = await shot('before_save');
const btns = await page.evaluate(() => [...document.querySelectorAll('button')].filter(b => b.offsetParent).map(b => b.innerText.trim()).slice(0, 60));
return { f0, btns };
