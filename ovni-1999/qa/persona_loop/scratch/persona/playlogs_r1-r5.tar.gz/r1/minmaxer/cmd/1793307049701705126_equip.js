await page.keyboard.press('e'); await S.sleep(1200);
const f = await shot('equip_screen');
const t = await page.evaluate(() => document.body.innerText.slice(0, 2000));
return { f, sc: await page.evaluate(() => OV.Scenes.top().id), t };
