await page.keyboard.press('4');
await S.sleep(800);
const f = await shot('staff');
const t = await page.evaluate(() => document.body.innerText);
return { f, text: t.slice(t.indexOf('HANGARES'), t.indexOf('HANGARES') + 1500) };
