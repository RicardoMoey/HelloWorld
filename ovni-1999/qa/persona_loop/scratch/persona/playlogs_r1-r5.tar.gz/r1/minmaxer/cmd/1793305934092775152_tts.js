return await page.evaluate(() => ({ a: OV.BattleUI.debug.tileToScreen(4, 15, 0), b: OV.BattleUI.debug.unitScreen(1), set: OV.Game.settings.confirmMove }));
