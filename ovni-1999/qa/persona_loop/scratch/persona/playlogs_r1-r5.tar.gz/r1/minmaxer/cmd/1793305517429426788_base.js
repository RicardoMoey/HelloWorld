await page.keyboard.press('Enter');
await S.sleep(400);
await page.keyboard.press('b');
await S.sleep(1500);
const f = await shot('base');
return { f, scene: await page.evaluate(() => OV.Scenes.top().id), text: await page.evaluate(() => document.body.innerText.slice(0, 2000)) };
