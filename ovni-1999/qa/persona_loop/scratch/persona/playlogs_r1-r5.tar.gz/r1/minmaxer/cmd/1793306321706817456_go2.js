await page.keyboard.press('Enter'); await S.sleep(2000);
const t = await page.evaluate(() => document.body.innerText.slice(0, 700));
await page.keyboard.press('Enter'); await S.sleep(4000);
const f = await shot('battle2');
return { t, f, al: await page.evaluate(() => OV.Game.B.units.filter(u => u.origSide === 'alien').map(u => [u.id, u.type, u.status, u.x, u.y, u.z])), night: await page.evaluate(() => OV.Game.B.mission.night) };
