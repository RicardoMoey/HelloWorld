await page.keyboard.press('2');
const t0 = Date.now();
let last = '';
for (let i = 0; i < 120; i++) {
  await S.sleep(500);
  const st = await page.evaluate(() => { const d = document.querySelector('.geo-df, .df, [class*=dogfight]'); return { sc: OV.Scenes.top().id, txt: d ? d.innerText.slice(0, 400) : '' , pop: [...document.querySelectorAll('.geo-pop')].map(p => p.innerText.slice(0, 300)).join('|') }; });
  last = st;
  if (st.sc !== 'dogfight') break;
}
const f = await shot('df_end');
return { secs: (Date.now() - t0) / 1000, last, f };
