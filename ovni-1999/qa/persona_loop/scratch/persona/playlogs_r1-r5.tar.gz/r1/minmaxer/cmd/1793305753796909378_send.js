await page.getByText('OVNI-2').first().click();
await S.sleep(800);
const f = await shot('ufo_card');
const t = await page.evaluate(() => [...document.querySelectorAll('.geo-pop, .geo-dlg, .geo-card, [class*=card]')].map(p => p.innerText.slice(0, 600)));
return { f, t };
