await page.keyboard.press('n'); await S.sleep(1000);
const rows = page.locator('#modals').locator('button', { hasText: /iniciar/i });
const names = await page.evaluate(() => document.querySelector('#modals').innerText);
const want = /Pistola Laser/;
// find the INICIAR button following the wanted name
const ok = await page.evaluate((re) => { const r = new RegExp(re); const btns = [...document.querySelectorAll('#modals button')].filter(b => /iniciar/i.test(b.textContent)); for (const b of btns) { let p = b.parentElement; for (let i = 0; i < 4 && p; i++, p = p.parentElement) { if (r.test(p.innerText.split('\n')[0]) || (p.innerText.split('INICIAR')[0] && r.test(p.innerText.split(/iniciar/i)[0].split('\n').filter(Boolean).slice(-3).join(' ')))) { b.click(); return p.innerText.slice(0, 80); } } } return null; }, want.source);
await S.sleep(600);
await page.keyboard.press('Escape'); await S.sleep(500);
const sc = await page.evaluate(() => OV.Scenes.top().id);
if (sc === 'basescape') { await page.keyboard.press('Escape'); await S.sleep(500); }
return { ok, research: await page.evaluate(() => OV.Game.G.bases[0].research.map(r => r.topic + ':' + r.spent + '/' + r.cost + ' s' + r.scientists)), names: ok ? '' : names.slice(0, 800) };
