await page.keyboard.press('5');
const t0 = Date.now(); let pops = [];
for (let i = 0; i < 200; i++) {
  await S.sleep(300);
  const st = await page.evaluate(() => { const d = OV.Clock.date(OV.Game.G.t); const p = document.querySelector('.geo-pop, .geo-dlg'); return { d, pop: p ? p.innerText.slice(0, 200) : null }; });
  if (st.pop) { pops.push(st.pop.replace(/\n/g,' ')); await page.keyboard.press('Enter'); await S.sleep(200); await page.keyboard.press('5'); }
  if (st.d.d === 4 && st.d.h >= 5) break;
}
await page.keyboard.press('p');
return { secs: (Date.now() - t0) / 1000, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), pops };
