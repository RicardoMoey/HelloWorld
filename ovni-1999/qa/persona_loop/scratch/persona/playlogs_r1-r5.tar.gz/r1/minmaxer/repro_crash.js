const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const fs = require('fs');
const raw = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const G = OV.Save.fromJSON(raw).G;
const u = G.ufos[0], c = G.crafts.c1;
c.lon = u.lon; c.lat = u.lat; c.status = 'patrol'; c.dest = { kind: 'ufo', id: u.id }; c.patrol = true;
const m = OV.Campaign.startMission(G, { kind: 'ufo', id: u.id }, 'c1', {});
const B = OV.Battle.create(G, m);
console.log(B.units.filter(x => x.side === 'alien' || x.origSide==='alien').map(x => [x.id, x.type, x.status, !!x.crashDead, x.x, x.y]));
const g = OV.Battle.beginBattle(B); let r; const evs = [];
while (!(r = g.next()).done) { const e = r.value; if (['death','explosion','hit','fire','shoot','spotted','reaction','damage'].includes(e.t) || /death|explo|hit|shot/.test(e.t)) evs.push(JSON.stringify(e).slice(0, 220)); }
console.log(evs.slice(0, 30).join('\n'));
console.log(B.units.filter(x => x.origSide==='alien').map(x => [x.id, x.status, !!x.crashDead, x.hp]));
