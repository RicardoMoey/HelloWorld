await page.getByRole('button', { name: /^comprar$/i }).first().click(); await S.sleep(600);
const r = await page.evaluate(() => { const el = [...document.querySelectorAll('.bsc-row')].find(e => /Skyranger/.test(e.innerText)); const b = el && [...el.querySelectorAll('button')].find(b => /comprar/i.test(b.textContent)); if (b) { b.click(); return true; } return false; });
await S.sleep(600);
await page.keyboard.press('4'); await S.sleep(600);
const plus5 = page.getByRole('button', { name: /contratar \+5/i });
await plus5.first().click(); await S.sleep(300); await plus5.first().click(); await S.sleep(300);
const f = await shot('bought_hired');
return { r, f, funds: await page.evaluate(() => OV.Game.G.funds), dl: await page.evaluate(() => OV.Game.G.bases[0].deliveries.map(d => d.kind + ':' + d.itemId + ':' + d.n)) };
