const { chromium } = require('/opt/node-tools/node_modules/playwright');
const http = require('http');
const fs = require('fs');
const D = __dirname;
const GAMEPORT = process.argv[2], CTRL = +process.argv[3];
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const logs = [];
  page.on('console', (m) => { if (m.type() === 'error' || m.type()==='warning') logs.push(m.type()+': ' + m.text()); });
  page.on('pageerror', (e) => logs.push('PAGEERROR: ' + e.message + ' ' + (e.stack||'').split('\n').slice(0,3).join('|')));
  page.on('dialog', d => { logs.push('DIALOG '+d.message()); d.accept(); });
  await page.goto('http://127.0.0.1:' + GAMEPORT + '/ovni-1999/index.html?nosw=1');
  let n = 0;
  const T0 = Date.now();
  global.page = page; global.logs = logs;
  http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => body += c);
    req.on('end', async () => {
      try {
        const fn = new Function('page', 'logs', 'fs', 'D', 'shot', 'sleep', 'ev', 'return (async () => {' + body + '})()');
        const shot = async (name) => { n++; const f = D + '/shots/' + String(n).padStart(3,'0') + '_' + name + '.png'; await page.screenshot({ path: f }); return f; };
        const sleep = (ms) => page.waitForTimeout(ms);
        const ev = (f, a) => page.evaluate(f, a);
        const r = await fn(page, logs, fs, D, shot, sleep, ev);
        const out = { t: ((Date.now()-T0)/1000).toFixed(0), r, logs: logs.splice(0) };
        res.end(JSON.stringify(out, null, 1));
      } catch (e) { res.end(JSON.stringify({ err: String(e && e.stack || e).slice(0,1500), logs: logs.splice(0) })); }
    });
  }).listen(CTRL, '127.0.0.1');
  console.log('ready');
})();
