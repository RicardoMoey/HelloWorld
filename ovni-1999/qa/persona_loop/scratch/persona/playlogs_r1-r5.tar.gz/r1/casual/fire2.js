S.fire = async (alienId) => {
  await page.locator('.bs-hand[data-hand="R"]').click();
  await page.waitForTimeout(300);
  let s = await S.bs();
  if (!s.menu) return 'nomenu';
  let bi = -1, ba = -1;
  s.menu.entries.forEach((e, i) => { if (e.enabled && e.acc !== undefined && /tiro|rajada/i.test(e.label) && e.acc > ba) { ba = e.acc; bi = i; } });
  if (bi < 0) { await page.keyboard.press('Escape'); return 'nomode'; }
  const label = s.menu.entries[bi].label;
  await page.locator('.bs-menu-item').nth(bi).click();
  await page.waitForTimeout(250);
  const p = await S.panTo(S.unitPt(alienId));
  if (!p) { await page.keyboard.press('Escape'); return 'offscreen'; }
  await page.mouse.move(p.x, p.y, { steps: 3 });
  await page.waitForTimeout(200);
  s = await S.bs();
  const tg = s.target;
  if (!tg || tg.blocked) { await page.mouse.click(p.x, p.y, { button: 'right' }); await page.waitForTimeout(200); const s3 = await S.bs(); return 'blocked:' + (tg && tg.label) + ' modeAfterCancel=' + s3.mode; }
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(200);
  await S.idle(30000);
  return 'fired ' + label + ' ' + tg.label;
};
S.pickToward = (id, tx, ty, frac) => page.evaluate(([id, tx, ty, frac]) => {
  const B = OV.Game.B, m = B.map, u = OV.BUnits.findUnit(B, id);
  const plane = m.w * m.h;
  const xyz = (i) => { const z = (i / plane) | 0, r = i - z * plane; return [r % m.w, (r / m.w) | 0, z]; };
  const r = OV.Path.reachable(B, u, Math.floor(u.tu * frac), u.energy | 0);
  let best = null, bs = 1e9;
  for (const i of r.list) {
    const [x, y, z] = xyz(i);
    if (z !== u.z || B._.unitAt[i]) continue;
    const d = Math.hypot(x - tx, y - ty);
    if (d < 3) continue;
    if (d < bs) { bs = d; best = { x, y, z }; }
  }
  return best;
}, [id, tx, ty, frac]);
S.playTurn = async (opts) => {
  opts = opts || {};
  const log = [];
  const sq = await S.squad();
  for (const u of sq) {
    const ok = await S.selectByStrip(u.id);
    if (!ok) { log.push(u.name + ': select failed'); continue; }
    let moved = false;
    for (let a = 0; a < 4; a++) {
      const s = await S.bs();
      if (!s || s.ended || s.result) return log;
      if (!s.unit || s.unit.id !== u.id) break;
      if (s.visibleAliens.length) {
        const al = s.visibleAliens.map((q) => Object.assign(q, { d: Math.hypot(q.x - s.unit.x, q.y - s.unit.y) })).sort((p, q) => p.d - q.d)[0];
        const r = await S.fire(al.id);
        log.push(u.name + ' fire@' + al.id + ': ' + r);
        if (/^blocked/.test(r) && !moved) {
          const t = await S.pickToward(u.id, al.x, al.y, 0.4);
          if (t) { const lb = await S.moveTo(t); moved = true; log.push(u.name + ' reposition → ' + t.x + ',' + t.y + ' [' + lb + ']'); continue; }
        }
        if (!/^fired/.test(r)) break;
        continue;
      }
      if (moved) break;
      const t = await S.pickAdvance(u.id, opts.frac || 0.55);
      if (!t) { log.push(u.name + ': no tile'); break; }
      const lb = await S.moveTo(t);
      moved = true;
      const s2 = await S.bs();
      log.push(u.name + ' move ' + u.x + ',' + u.y + '→' + (s2.unit ? s2.unit.x + ',' + s2.unit.y : '?') + ' [' + lb + '] seen=' + (s2.visibleAliens || []).length);
    }
  }
  return log;
};
S.N = 3;
return 'ok';
