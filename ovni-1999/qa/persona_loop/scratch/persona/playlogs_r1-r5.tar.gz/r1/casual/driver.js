// persistent browser driver: POST JS body to http://127.0.0.1:PORT/ ; runs as async fn(page, ctx, S) and returns JSON
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const GAMEPORT = process.argv[2], CTRL = +process.argv[3];
const T0 = Date.now();
const S = { shots: 0, log: [], errors: [] };
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') S.errors.push(((Date.now()-T0)/1000|0) + 's ' + m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => S.errors.push(((Date.now()-T0)/1000|0) + 's PAGEERROR: ' + e.message));
  await page.goto('http://127.0.0.1:' + GAMEPORT + '/ovni-1999/index.html?nosw=1');
  S.shot = async (name) => { S.shots++; const f = __dirname + '/shots/' + String(S.shots).padStart(3, '0') + '_' + name + '.png'; await page.screenshot({ path: f }); return f; };
  S.t = () => ((Date.now() - T0) / 1000).toFixed(0) + 's';
  http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => body += c);
    req.on('end', async () => {
      try {
        const fn = new Function('page', 'ctx', 'S', 'return (async () => {' + body + '})()');
        const r = await fn(page, ctx, S);
        res.end(JSON.stringify({ t: S.t(), r }, null, 1));
      } catch (e) { res.end(JSON.stringify({ t: S.t(), err: String(e && e.stack || e) })); }
    });
  }).listen(CTRL, '127.0.0.1', () => console.log('driver ready'));
})();
