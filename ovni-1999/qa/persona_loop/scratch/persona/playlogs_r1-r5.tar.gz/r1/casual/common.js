S.state = () => page.evaluate(()=>{const c=OV.GeoUI.current()||{}; const G=OV.Game.G; return {top:OV.Scenes.top().id, date:G?OV.U.fmtDate(G.t):'', popup:c.popup, dialog:c.dialog, speed:c.speed, paused:c.paused, funds:G&&G.funds, pop: (document.querySelector('.geo-pop:not(.out)')||{}).innerText}});
S.waitEvent = async (ms) => { const end=Date.now()+ms; let s; while(Date.now()<end){ s = await S.state(); if (s.top!=='geoscape'||s.popup||s.dialog) return s; await page.waitForTimeout(500);} return s; };
return 'ok';
