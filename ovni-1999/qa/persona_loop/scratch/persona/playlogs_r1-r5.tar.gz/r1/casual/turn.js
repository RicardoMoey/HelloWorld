S.playTurn = async (opts) => {
  opts = opts || {};
  const log = [];
  const sq = await S.squad();
  for (const u of sq) {
    const ok = await S.selectByStrip(u.id);
    if (!ok) { log.push(u.name + ': select failed'); continue; }
    for (let a = 0; a < 3; a++) {
      const s = await S.bs();
      if (!s || s.ended || s.result) return log;
      if (!s.unit || s.unit.id !== u.id) break;
      if (s.visibleAliens.length) {
        const al = s.visibleAliens.map((q) => Object.assign(q, { d: Math.hypot(q.x - s.unit.x, q.y - s.unit.y) })).sort((p, q) => p.d - q.d)[0];
        const r = await S.fire(al.id);
        log.push(u.name + ' fire@' + al.id + ': ' + r);
        if (/nomode|nomenu|offscreen/.test(r)) break;
        continue;
      }
      if (a > 0) break;
      const t = await S.pickAdvance(u.id, opts.frac || 0.55);
      if (!t) { log.push(u.name + ': no tile'); break; }
      const lb = await S.moveTo(t);
      const s2 = await S.bs();
      log.push(u.name + ' move ' + u.x + ',' + u.y + '→' + (s2.unit ? s2.unit.x + ',' + s2.unit.y : '?') + ' [' + lb + '] seen=' + (s2.visibleAliens || []).length);
    }
  }
  return log;
};
return 'ok';
