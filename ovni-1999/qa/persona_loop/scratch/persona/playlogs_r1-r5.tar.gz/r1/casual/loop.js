const out = [];
for (let t = 0; t < (S.N || 3); t++) {
  const s0 = await S.bs();
  if (!s0 || s0.ended || s0.result) { out.push('ended ' + JSON.stringify(s0 && s0.result)); break; }
  const T0 = Date.now();
  const log = await S.playTurn({ frac: S.frac || 0.55 });
  out.push('--- turn ' + s0.turn + ' (' + ((Date.now() - T0) / 1000 | 0) + 's)');
  out.push(...log);
  out.push('shot ' + await S.shot('turn' + s0.turn + '_end'));
  const s1 = await S.bs();
  if (!s1 || s1.ended || s1.result) { out.push('ended ' + JSON.stringify(s1 && s1.result)); break; }
  const r = await S.endTurn();
  const s2 = await S.bs();
  const toasts = await page.evaluate(() => document.getElementById('toasts').innerText.replace(/\s+/g, ' '));
  const sq = await S.squad();
  out.push('alien turn ' + r + 'ms; squad ' + sq.length + ' hp=' + sq.map((q) => q.hp).join(',') + ' seen=' + (s2 ? s2.visibleAliens.length : '-') + ' toasts=' + toasts);
  out.push('shot ' + await S.shot('turn' + (s2 ? s2.turn : 'x') + '_start'));
}
out.push('errors ' + JSON.stringify(S.errors));
return out;
