const log=[]; const t0=Date.now(); let s;
for (let i=0;i<14;i++){
  s = await S.state();
  if (s.top==='geoscape' && !s.popup && !s.dialog) { await page.locator('.geo-speeds .geo-sp').nth(S.spd||4).click(); }
  s = await S.waitEvent(60000);
  log.push(((Date.now()-t0)/1000|0)+'s '+s.date+' '+s.popup+' '+s.dialog+' | '+(s.pop||'').replace(/\s+/g,' ').slice(0,260));
  if (s.top!=='geoscape' || !s.popup) break;
  if ((S.stopOn||['ufoDetected']).includes(s.popup)) break;
  await S.shot('pop_'+s.popup);
  const ok = page.locator('.geo-pop:not(.out) .geo-pop-a button', {hasText:/^OK/});
  if (await ok.count()) await ok.click(); else await page.keyboard.press('Enter');
  await page.waitForTimeout(400);
}
s.shot = await S.shot('geo_stop');
return {log, s};
