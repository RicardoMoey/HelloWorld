const log=[]; const t0=Date.now(); let s;
const popBtn = async (re) => { const b = page.locator('.geo-pop:not(.out) .geo-pop-a button', {hasText:re}); if (await b.count()) { await b.first().click(); await page.waitForTimeout(400); return true; } return false; };
for (let i=0;i<(S.maxEv||25);i++){
  s = await S.state();
  if (s.top==='geoscape' && !s.popup && !s.dialog) { await page.locator('.geo-speeds .geo-sp').nth(S.spd||4).click(); }
  s = await S.waitEvent(90000);
  const line = ((Date.now()-t0)/1000|0)+'s '+s.date+' ['+s.top+'] '+s.popup+' '+s.dialog+' | '+(s.pop||'').replace(/\s+/g,' ').slice(0,200);
  log.push(line);
  if (s.top==='dogfight') {
    let a;
    for (let k=0;k<240;k++){ a = await page.evaluate(()=>{const x=OV.DogfightUI.active()[0]; return {top:OV.Scenes.top().id, a:x||null}}); if (a.top!=='dogfight') break; if (a.a&&a.a.over){ log.push('  dogfight: '+a.a.outcome); await S.shot('df_'+a.a.outcome); await page.locator('.df-cont').first().click().catch(()=>page.keyboard.press('Enter')); await page.waitForTimeout(800); break;} await page.waitForTimeout(500);} 
    continue;
  }
  if (s.top!=='geoscape') break;
  if (!s.popup) { if (s.dialog) { log.push(' dialog open '+s.dialog); break; } continue; }
  if ((S.stopOn||[]).includes(s.popup)) break;
  if (s.popup==='researchDone') {
    if (await popBtn(/Novo projeto/)) { await page.waitForTimeout(800); const opts = await page.evaluate(()=>[...document.querySelectorAll('.bsc-sheet [data-start]')].map(n=>n.dataset.start)); const pick = (S.prefRes||[]).find(p=>opts.includes(p)) || opts[0]; log.push('  research → '+pick+' of '+opts.join(',')); if (pick) await page.locator('.bsc-sheet [data-start="'+pick+'"]').click(); await page.waitForTimeout(400); await page.keyboard.press('Escape'); await page.waitForTimeout(900); }
    continue;
  }
  if (s.popup==='deliveryArrived' && /cientistas/.test(s.pop||'')) {
    await popBtn(/Ir para a base/); await page.waitForTimeout(800);
    await page.locator('.bsc-tab').nth(1).click(); await page.waitForTimeout(400);
    const all = page.locator('button', {hasText:/^Todos$/i}); if (await all.count()) await all.first().click();
    await page.waitForTimeout(300); await page.keyboard.press('Escape'); await page.waitForTimeout(900); log.push('  assigned scientists'); continue;
  }
  if (s.popup==='ufoDetected' || s.popup==='ufoLanded' || s.popup==='ufoCrashed') {
    if (/Em voo/.test(s.pop||'') && await page.locator('.geo-pop:not(.out) .geo-pop-a button', {hasText:'Intercetar'}).count()) {
      await popBtn('Intercetar'); await page.waitForTimeout(500);
      const row = page.locator('.geo-int .geo-row:not(:disabled)', {hasText:/Intercetor/}); 
      if (await row.count()) { await row.first().click(); log.push('  intercept launched'); } else { await page.keyboard.press('Escape'); log.push('  no interceptor'); }
      await page.waitForTimeout(500); continue;
    }
    if (S.sendTeam && await page.locator('.geo-pop:not(.out) .geo-pop-a button', {hasText:'Enviar equipa'}).count()) {
      await popBtn('Enviar equipa'); await page.waitForTimeout(500);
      const row = page.locator('.geo-int .geo-row:not(:disabled)', {hasText:/Skyranger/});
      if (await row.count()) { await row.first().click(); log.push('  skyranger sent'); } else { await S.shot('no_skyranger'); await page.keyboard.press('Escape'); log.push('  skyranger not available'); }
      await page.waitForTimeout(500); continue;
    }
  }
  if (s.popup==='craftArrived') break;
  await S.shot('pop_'+s.popup);
  if (!(await popBtn(/^OK/))) await page.keyboard.press('Enter');
}
s = await S.state();
s.shot = await S.shot('geo2_stop');
return {log, s};
