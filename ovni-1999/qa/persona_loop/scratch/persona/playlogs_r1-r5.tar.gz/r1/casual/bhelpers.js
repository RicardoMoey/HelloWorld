const W = 1440, H = 900;
S.bs = () => page.evaluate(() => OV.BattleUI.debug.state());
S.idle = async (ms) => { try { await page.waitForFunction(() => { const s = OV.BattleUI.debug.state(); return !s || (!s.playing); }, null, { timeout: ms || 30000, polling: 150 }); } catch (e) { return false; } return true; };
// pan with two-finger scroll until screen point of tile is inside safe rect
S.panTo = async (getPt) => {
  for (let it = 0; it < 25; it++) {
    const p = await getPt();
    if (!p) return null;
    const safe = p.x > 230 && p.x < W - 200 && p.y > 90 && p.y < H - 170;
    if (safe) return p;
    const tx = W * 0.5, ty = H * 0.42;
    const dx = Math.max(-60, Math.min(60, (p.x - tx) / 4)), dy = Math.max(-60, Math.min(60, (p.y - ty) / 4));
    await page.mouse.move(700, 400);
    for (let k = 0; k < 4; k++) { await page.mouse.wheel(dx, dy); await page.waitForTimeout(16); }
    await page.waitForTimeout(120);
  }
  return await getPt();
};
S.tilePt = (x, y, z) => () => page.evaluate(([x, y, z]) => OV.BattleUI.debug.tileToScreen(x, y, z), [x, y, z]);
S.unitPt = (id) => () => page.evaluate((id) => OV.BattleUI.debug.unitScreen(id), id);
S.squad = () => page.evaluate(() => OV.Game.B.units.filter((u) => u.side === 'xcom' && u.onMap && u.x >= 0 && u.status === 'ok').map((u) => ({ id: u.id, name: u.name, x: u.x, y: u.y, z: u.z, tu: u.tu, hp: u.hp })));
S.selectByStrip = async (id) => {
  const idx = await page.evaluate((id) => { const sq = OV.Game.B.units.filter((u) => u.side === 'xcom' && (u.origSide === 'xcom' || u.side === 'xcom')); return sq.findIndex((u) => u.id === id); }, id);
  const rows = page.locator('.bs-squad > *');
  const n = await rows.count();
  if (n && idx >= 0 && idx < n) { await rows.nth(idx).click(); await page.waitForTimeout(250); }
  const s = await S.bs();
  return s.selectedId === id;
};
// Sofia-like destination: a reachable tile "a few steps toward the unexplored/UFO" costing <= frac of TU
S.pickAdvance = (id, frac) => page.evaluate(([id, frac]) => {
  const B = OV.Game.B, m = B.map, u = OV.BUnits.findUnit(B, id);
  const plane = m.w * m.h;
  const xyz = (i) => { const z = (i / plane) | 0, r = i - z * plane; return [r % m.w, (r / m.w) | 0, z]; };
  const R = B.ufo || { x: m.w >> 1, y: m.h >> 1, w: 1, h: 1 };
  const gx = R.x + R.w / 2, gy = R.y + R.h / 2;
  const r = OV.Path.reachable(B, u, Math.floor(u.tu * frac), u.energy | 0);
  const mates = B.units.filter((q) => q.side === 'xcom' && q.onMap && q.status === 'ok' && q.id !== u.id);
  let best = null, bs = 1e9;
  const d0 = Math.hypot(u.x - gx, u.y - gy);
  for (const i of r.list) {
    const [x, y, z] = xyz(i);
    if (z !== u.z) continue;
    if (B._.unitAt[i]) continue;
    let near = 0; for (const q of mates) if (Math.max(Math.abs(q.x - x), Math.abs(q.y - y)) <= 1) near++;
    const d = Math.hypot(x - gx, y - gy);
    const sc = d + near * 3 + Math.random() * 2;
    if (sc < bs) { bs = sc; best = { x, y, z, cost: r.cost[i], d, d0 }; }
  }
  return best;
}, [id, frac]);
S.moveTo = async (t) => {
  const p = await S.panTo(S.tilePt(t.x, t.y, t.z));
  if (!p) return 'offscreen';
  await page.mouse.move(p.x, p.y, { steps: 3 });
  await page.waitForTimeout(120);
  let s = await S.bs();
  const label = s.pathLabel;
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(150);
  s = await S.bs();
  if (!s.playing && s.lock >= 0) { await page.mouse.click(p.x, p.y); await page.waitForTimeout(150); }
  await S.idle(60000);
  return label;
};
S.fire = async (alienId) => {
  // click right-hand slot, pick best-accuracy enabled fire mode, click alien
  const before = await S.bs();
  await page.locator('.bs-hand[data-hand="R"]').click();
  await page.waitForTimeout(300);
  let s = await S.bs();
  if (!s.menu) return 'nomenu';
  let bi = -1, ba = -1;
  s.menu.entries.forEach((e, i) => { if (e.enabled && e.acc !== undefined && /tiro|rajada/i.test(e.label) && e.acc > ba) { ba = e.acc; bi = i; } });
  if (bi < 0) { await page.keyboard.press('Escape'); return 'nomode:' + JSON.stringify(s.menu.entries); }
  const label = s.menu.entries[bi].label;
  await page.locator('.bs-menu-item').nth(bi).click().catch(async () => { await page.keyboard.press(String(bi + 1)); });
  await page.waitForTimeout(250);
  const p = await S.panTo(S.unitPt(alienId));
  if (!p) { await page.keyboard.press('Escape'); return 'alien offscreen'; }
  await page.mouse.move(p.x, p.y, { steps: 3 });
  await page.waitForTimeout(200);
  s = await S.bs();
  const tg = s.target;
  await page.mouse.click(p.x, p.y);
  await page.waitForTimeout(200);
  await S.idle(30000);
  return label + ' ' + JSON.stringify(tg);
};
S.endTurn = async () => {
  await page.locator('.bs-end').click();
  await page.waitForTimeout(500);
  const m = page.locator('#modals .modal .btn.primary');
  if (await m.count()) { await m.first().click(); await page.waitForTimeout(300); }
  const t0 = Date.now();
  try {
    await page.waitForFunction(() => { const s = OV.BattleUI.debug.state(); return !s || s.ended || s.result || (s.side === 'xcom' && !s.playing && s.phase === 'play'); }, null, { timeout: 120000, polling: 250 });
  } catch (e) { return 'stuck ' + (Date.now() - t0); }
  return Date.now() - t0;
};
return 'ok';
