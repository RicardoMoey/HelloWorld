// move soldiers until someone sees an alien; stop there (don't fire)
const log=[];
for (let t=0;t<6;t++){
  const sq = await S.squad();
  for (const u of sq) {
    await S.selectByStrip(u.id);
    const s = await S.bs();
    if (s.visibleAliens.length) return {log, seenBy:u.name, aliens:s.visibleAliens, shot: await S.shot('seen')};
    const tt = await S.pickAdvance(u.id, 0.5);
    if (tt) { await S.moveTo(tt); }
    const s2 = await S.bs();
    if (s2.visibleAliens.length) return {log, seenBy:u.name, aliens:s2.visibleAliens, unit:s2.unit, shot: await S.shot('seen')};
  }
  log.push('end turn '+ await S.endTurn());
  const s3 = await S.bs(); if (s3.result) return {log, result:s3.result};
}
return {log};
