const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const D = OV.Data;
for (const [k,c] of Object.entries(D.crafts)) console.log('craft',k,'buy',c.buy,'cost',c.cost,'rent',c.rent,'sell',c.sell, 'score',c.score);
const out=[];
for (const [k,m] of Object.entries(D.manufacture)) {
  const it = D.items[k] || D.crafts[k] || {};
  let mat=0; for (const [mk,n] of Object.entries(m.materials||m.mats||{})) mat += n*((D.items[mk]||{}).sell||0);
  const sell = it.sell || 0;
  out.push([k, m.hours, m.cost, sell, mat, ((sell-m.cost-mat)/m.hours).toFixed(0), JSON.stringify(m.materials||m.mats||{}), m.requires]);
}
out.sort((a,b)=>b[5]-a[5]); console.table(out);
console.log('staff', JSON.stringify(D.staff||D.personnel||Object.keys(D).filter(k=>/staff|hire|salar/i.test(k))));
console.log(Object.keys(D));
