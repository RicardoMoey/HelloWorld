const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const G = OV.Campaign.newCampaign({ seed: 2024, difficulty: 1 });
const b = G.bases[0]; const sky = Object.values(G.crafts).find(c => c.type === 'skyranger');
console.log('stores', JSON.stringify(b.stores));
console.log('craft equipment', JSON.stringify(sky.equipment));
for (const id of sky.soldiers) { const s = OV.Campaign.findSoldier(G, id); console.log(s.name.padEnd(22), 'str', s.stats.str, JSON.stringify(s.loadout)); }
