S.pick = async (uid, tx, ty) => page.evaluate(([uid,tx,ty])=>{const B=OV.Game.B; const u=B.units.find(u=>u.id===uid); let best=null; for(let dy=-3;dy<=3;dy++) for(let dx=-3;dx<=3;dx++){const x=tx+dx,y=ty+dy; if(x<0||y<0||x>=B.map.w||y>=B.map.h) continue; if(B.units.some(o=>o.hp>0&&o.x===x&&o.y===y)) continue; const wp=OV.Act.walkPreview(B,u,y*B.map.w+x,{reserveMode:B.reserve}); if(!wp||!wp.tiles.length||wp.marks.some(m=>m>0)) continue; const d=Math.abs(dx)+Math.abs(dy); if(!best||d<best.d) best={x,y,d};} return best? [best.x,best.y]:null},[uid,tx,ty]);
S.advance = async (dxStep) => { const out=[]; const seen=new Set(); for(let n=0;n<12;n++){ let s=await S.st(); if(!s||s.ended||s.result||s.side!=='xcom') break; const u=s.unit; if(!u||seen.has(u.id)) break; seen.add(u.id);
  for(let k=0;k<2;k++){ if(!(await S.tryShoot(out))) break; }
  s=await S.st(); if(s.ended||s.result) break;
  if(s.unit && s.unit.tu>24 && !s.visibleAliens.length){ const t=await S.pick(u.id, u.x-dxStep, u.y + ((u.id%3)-1)*2); if(t){ const info=await S.moveKb(t[0],t[1]); out.push('u'+u.id+' mv '+JSON.stringify(info).slice(0,160)); } }
  for(let k=0;k<2;k++){ if(!(await S.tryShoot(out))) break; }
  s=await S.st(); if(s.ended||s.result) break;
  if(s.unit && s.unit.tu>=8 && !s.unit.kneel){ await page.keyboard.press('k'); await sleep(300); await S.waitIdle(20000); }
  await page.keyboard.press('Space'); await sleep(400); }
  return out; };
return 'plan ok';
