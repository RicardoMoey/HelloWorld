S.hunt = async () => { const out=[]; const seen=new Set(); for(let n=0;n<12;n++){ let s=await S.st(); if(!s||s.ended||s.result||s.side!=='xcom') break; const u=s.unit; if(!u||seen.has(u.id)) break; seen.add(u.id);
  for(let k=0;k<2;k++){ if(!(await S.tryShoot(out))) break; }
  s=await S.st(); if(s.ended||s.result) break;
  const al=await page.evaluate(()=>OV.Game.B.units.filter(a=>a.side!=='xcom'&&a.hp>0).map(a=>[a.x,a.y]));
  if(al.length && s.unit && s.unit.tu>20 && !s.visibleAliens.length){ const a=al[0]; const dx=Math.sign(a[0]-u.x)*Math.min(5,Math.abs(a[0]-u.x)), dy=Math.sign(a[1]-u.y)*Math.min(5,Math.abs(a[1]-u.y)); const t=await S.pick(u.id,u.x+dx,u.y+dy); if(t){ const info=await S.moveKb(t[0],t[1]); out.push('u'+u.id+' -> '+info.after); } }
  for(let k=0;k<2;k++){ if(!(await S.tryShoot(out))) break; }
  s=await S.st(); if(s.ended||s.result) break;
  await page.keyboard.press('Escape'); await sleep(150); await page.keyboard.press('Space'); await sleep(450); }
  return out; };
return 'hunt ok';
