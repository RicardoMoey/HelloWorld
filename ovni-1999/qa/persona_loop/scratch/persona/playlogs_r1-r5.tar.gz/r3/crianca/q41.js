await page.locator('text=OVNI-11').last().click(); await sleep(700);
await shot('ufo11_sel');
const t0 = await txt(2500);
const b = page.locator("button:visible:has-text('Enviar equipa')");
const n = await b.count(); if (n) { await b.first().click(); await sleep(800); }
await shot('send_dialog_2soldiers');
const dt = await page.evaluate(()=>[...document.querySelectorAll('.geo-dlg, [role=dialog]')].map(e=>e.innerText).join('|').replace(/\s+/g,' ').slice(0,900));
return {n, dt};
