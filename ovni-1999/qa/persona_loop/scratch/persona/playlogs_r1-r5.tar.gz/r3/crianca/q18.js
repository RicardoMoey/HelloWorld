await page.keyboard.press('n'); await sleep(800);
await shot('newproj');
const t = await txt(3000);
return {t};
