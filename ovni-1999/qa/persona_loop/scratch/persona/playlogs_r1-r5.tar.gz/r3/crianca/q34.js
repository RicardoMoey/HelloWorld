await page.locator('text=Lança-Foguetes').first().click(); await sleep(300);
await page.mouse.click(398,260); await sleep(500);
await shot('equip_rl_left');
// find small rocket
const rk = page.locator('text=Foguete Pequeno').first();
const has = await rk.count();
if (has) { await rk.scrollIntoViewIfNeeded(); await rk.click(); await sleep(300); await page.mouse.click(398,260); await sleep(500); }
await shot('equip_rl_loaded');
const t = await txt(3000);
return {has, t: t.slice(t.indexOf('EQUIPAR\nHenry'), t.indexOf('EQUIPAR\nHenry')+700), toasts: await toast()};
