const f0 = await page.evaluate(()=>OV.Game.G.funds);
await page.locator("button:visible:has-text('CONTRATAR +5')").first().dblclick(); await sleep(700);
const f1 = await page.evaluate(()=>OV.Game.G.funds);
await shot('hire_dbl');
const t = await txt(5000);
return {f0,f1, n:(f0-f1)/40000, t: t.slice(t.indexOf('ENCOMENDAS'), t.indexOf('ENCOMENDAS')+300), toasts: await toast()};
