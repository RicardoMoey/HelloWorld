await shot('c4_deb');
await page.keyboard.press('Enter'); await sleep(1500);
let g = await gcur(); const pops=[];
for (let i=0;i<6 && g.popup;i++){ pops.push(g.popup+': '+(await popTxt()).slice(0,200)); await page.keyboard.press('Enter'); await sleep(700); g=await gcur(); }
await page.keyboard.press('b'); await sleep(1000);
await page.keyboard.press('6'); await sleep(800);
await shot('naves_tab2');
const t = await txt(5000);
return {pops, t: t.slice(t.indexOf('Naves'), t.indexOf('Naves')+1200)};
