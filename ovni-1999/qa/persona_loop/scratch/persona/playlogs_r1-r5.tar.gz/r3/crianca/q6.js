await sqClick(1); const s=await st();
const hands = await page.evaluate((id)=>{const B=OV.Game.B; const u=OV.BUnits.findUnit(B,id); return ['R','L'].map(h=>{const it=OV.BUnits.item(B,u,h); return it? (it.type+':'+(it.ammo?it.ammo.type+'/'+it.ammo.rounds:'-')):null;});}, s.unit.id);
const xs = (await units()).filter(u=>u.side==='xcom' && u.st==='ok').map(u=>[u.name,u.x,u.y,u.z]);
return {u:s.unit, name: (await units()).find(u=>u.id===s.unit.id).name, hands, xs, turn:s.turn};
