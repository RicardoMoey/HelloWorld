await page.keyboard.press('8'); await sleep(800);
await shot('market');
const t = await txt(4000);
return {t: t.slice(t.indexOf('Mercado'), t.indexOf('Mercado')+2500)};
