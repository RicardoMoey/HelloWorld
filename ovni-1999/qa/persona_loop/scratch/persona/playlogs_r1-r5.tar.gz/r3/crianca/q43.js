await page.locator(".geo-dlg button, [role=dialog] button").filter({hasText:'Skyranger-1'}).first().click(); await sleep(800);
const r = await geoStep(200000, {});
if (!r.battle) return r;
await sleep(1200);
const b = await playTurns3(12,'c7');
const out = {ev:r.ev, b: b.map(x=>({t:x.turn,c:x.c,dl:x.dl, scene:x.scene})), st: await stack()};
if (out.st.slice(-1)[0]!=="battlescape") { await shot("c7_deb"); out.deb = (await txt(900)); }
return out;
