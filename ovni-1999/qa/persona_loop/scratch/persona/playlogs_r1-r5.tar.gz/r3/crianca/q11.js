log('QB alien base month4');
await page.dblclick("button:has-text('COMEÇAR')"); await sleep(1200);
const f0=await shot('base_brief');
const bt = await txt(2500);
await page.dblclick("button:has-text('INICIAR MISSÃO')");
const t0=Date.now(); for(let i=0;i<80;i++){ const ok = await page.evaluate(()=>!!(OV.BattleUI && OV.BattleUI.scene && OV.BattleUI.debug.state())); if (ok) break; await sleep(250);} 
const load=Date.now()-t0; await sleep(1500);
await shot('base_start');
const hands = await page.evaluate(()=>{const B=OV.Game.B; return B.units.filter(u=>u.side==='xcom').map(u=>u.name+': '+['R','L'].map(h=>{const it=OV.BUnits.item(B,u,h); return it? (it.type+':'+(it.ammo?it.ammo.rounds:'-')):'-';}).join(','));});
return {bt: bt.slice(0,900), load, hands, m: await mapInfo()};
