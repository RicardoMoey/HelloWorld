const r = await page.evaluate(()=>{ const G=OV.Game.G; const sol=Object.values(G.soldiers); return {n:sol.length, sample: JSON.stringify(sol[sol.length-1]).slice(0,900), lo: sol.map(s=>s.name+':'+JSON.stringify(s.loadout||s.equip||'').slice(0,120)), stores: G.bases[0].stores.rocket_launcher}; });
return r;
