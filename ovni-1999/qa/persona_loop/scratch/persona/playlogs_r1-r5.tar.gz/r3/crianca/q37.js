await page.keyboard.press('Enter'); await sleep(1200);
const r = await geoStep(450000, {});
return r;
