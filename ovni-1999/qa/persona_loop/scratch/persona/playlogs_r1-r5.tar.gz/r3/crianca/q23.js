await page.keyboard.press('b'); await sleep(1000);
await page.keyboard.press('6'); await sleep(800);
await shot('naves_tab');
const t = await txt(5000);
return t.slice(t.indexOf('HANGARES'));
