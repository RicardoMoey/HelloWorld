await page.keyboard.press('Escape'); await sleep(600);
const ev=[]; const t0=Date.now();
while (Date.now()-t0<60000) { const home = await page.evaluate(()=>{const c=Object.values(OV.Game.G.crafts||{}).find(c=>/sky/i.test(c.type)); return c && c.status;}); if (home && !/returning|out/.test(home)) { ev.push('sky '+home); break; } const r = await geoStep(5000, {noMissions:true}); ev.push(...r.ev); }
await page.keyboard.press('p'); await sleep(300);
await page.keyboard.press('b'); await sleep(1000);
await page.keyboard.press('6'); await sleep(800);
await page.keyboard.press('e'); await sleep(1200);
await shot('home_equip');
return {ev, st: await stack(), t: (await txt(3000)).slice(0,1500)};
