const r = await geoStep(300000, {});
if (!r.battle) return r;
await sleep(1500); await shot('c4_start');
const b = await playTurns3(8,'c4');
return {ev:r.ev, b, st: await stack()};
