await page.keyboard.press('4'); await sleep(800);
await shot('pessoal');
const t = await txt(5000);
return t.slice(t.indexOf('HANGARES'));
