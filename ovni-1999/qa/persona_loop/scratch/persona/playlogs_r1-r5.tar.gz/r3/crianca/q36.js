await page.keyboard.press('Enter'); await sleep(1500);
const r = await geoStep(400000, {noMissions:true, stopAtMonth:true});
return r;
