for (let i=0;i<30;i++){ const r = await page.evaluate(()=>{const t=document.body.innerText; const m=t.match(/RAÇA PROVÁVEL\n([^\n]+)/); return m&&m[1];}); if (/Serpente/i.test(r||'')) break; await page.click("button:has-text('ALEATÓRIA')"); await sleep(200); }
await shot('qb_snake');
await page.dblclick("button:has-text('COMEÇAR')"); await sleep(1200);
await page.dblclick("button:has-text('INICIAR MISSÃO')");
for(let i=0;i<80;i++){ const ok = await page.evaluate(()=>!!(OV.BattleUI && OV.BattleUI.scene && OV.BattleUI.debug.state())); if (ok) break; await sleep(250);} 
await sleep(1500);
const al = await page.evaluate(()=>OV.Game.B.units.filter(u=>u.side==='alien').map(u=>u.type));
log('QB terror snakemen month3 '+al.join(','));
const b = await playTurns3(6,'snk');
return {al, b: b.map(x=>({t:x.turn,c:x.c,dl:x.dl,toasts:x.toasts}))};
