const n = await page.locator('.bs-squad .bs-sq').count();
const s = await st();
return {n, keys:Object.keys(s), unit:s.unit, mode:s.mode, aliens: await page.evaluate(()=>OV.Game.B.units.filter(u=>u.side==='alien').map(u=>[u.x,u.y,u.z,u.type||u.race])), map: await mapInfo(), goal: await battleGoal()};
