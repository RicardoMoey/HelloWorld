await page.keyboard.press('e'); await sleep(1200);
await shot('equip_screen');
return {st: await stack(), t: (await txt(4000))};
