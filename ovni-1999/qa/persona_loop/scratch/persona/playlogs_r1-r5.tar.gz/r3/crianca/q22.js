await page.keyboard.press('Enter'); await sleep(1200);
let g = await gcur(); const pops=[];
for (let i=0;i<6 && g.popup;i++){ pops.push(g.popup+': '+(await popTxt()).slice(0,200)); await shot('pop_'+g.popup); await page.keyboard.press('Enter'); await sleep(700); g=await gcur(); }
await shot('geo_after_c2');
return {pops, g, st: await stack()};
