log('mtl victory; dblclick JOGAR DE NOVO');
await page.dblclick("button:has-text('JOGAR DE NOVO')"); 
const seen=[]; for(let i=0;i<12;i++){ seen.push((await stack()).join('>')); await sleep(250); }
await shot('replay');
return {seen, t: await txt(400)};
