await page.locator("button:visible:has-text('REPETIR A MISSÃO')").click(); await sleep(1500);
await shot('repeat_click');
const s1 = await stack(); const t1 = await txt(1500);
return {s1, t1};
