await page.locator("button:visible:has-text('INICIAR')").first().dblclick(); await sleep(800);
await shot('after_start_research');
const r = await page.evaluate(()=>{const G=OV.Game.G; const b=G.bases[0]; return JSON.stringify(b.research);});
return {r, t: (await txt(3000)).slice(-900)};
