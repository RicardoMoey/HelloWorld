await page.keyboard.press('2'); await sleep(800);
await shot('research_tab');
return {t: await txt(3000)};
