const seeds=[];
const getSeed = () => page.evaluate(()=>[...document.querySelectorAll("input")].map(i=>i.value)[1]);
seeds.push(await getSeed());
for (let i=0;i<2;i++){ await page.keyboard.press('Escape'); await sleep(500); await page.click("text=BATALHA RÁPIDA"); await sleep(600); seeds.push(await getSeed()); }
// reload page and open again
await page.reload(); await sleep(1500); await page.click("text=BATALHA RÁPIDA"); await sleep(600); seeds.push(await getSeed());
return seeds;
