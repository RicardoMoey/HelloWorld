await page.keyboard.press('Enter'); await sleep(1500);
const ff = []; 
return {g: await gcur(), st: await stack()};
