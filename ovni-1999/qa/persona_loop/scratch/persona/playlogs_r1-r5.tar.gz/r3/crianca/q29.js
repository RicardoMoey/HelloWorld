await page.keyboard.press('Escape'); await sleep(800);
let s = await stack(); 
if (s.slice(-1)[0]==='cbriefing') { await page.keyboard.press('Enter'); }
for(let i=0;i<60;i++){ const ok = await page.evaluate(()=>!!(OV.BattleUI && OV.BattleUI.scene && OV.BattleUI.debug.state())); if (ok) break; await sleep(250);} 
await sleep(1500); await shot('c3_start');
log('c3 crashed small scout battle');
const r=await playTurns3(7,"c3"); return {r, errs, st: await stack()};
