const t0=Date.now();
await page.dblclick("button:has-text('INICIAR MISSÃO')");
let w=0; for(let i=0;i<80;i++){ const s=(await stack()).slice(-1)[0]; if (s==='battlescape') { const ok = await page.evaluate(()=>!!(OV.BattleUI.scene && OV.BattleUI.debug.state())); if (ok) break;} await sleep(250);} 
const load=Date.now()-t0;
await sleep(1500);
const f=await shot('battle_start');
return {load, stack: await stack(), t: await txt(1500)};
