await page.locator("button:visible:has-text('EMBARCAR 4 E EQUIPAR')").click(); await sleep(900);
await shot('after_board4');
const dt = await page.evaluate(()=>[...document.querySelectorAll('.geo-dlg, [role=dialog]')].map(e=>e.innerText).join('|').replace(/\s+/g,' ').slice(0,700));
const lo = await page.evaluate(()=>{const c=Object.values(OV.Game.G.crafts).find(c=>/sky/i.test(c.type)); return c.soldiers.map(id=>{const s=OV.Game.G.soldiers[id]; return s.name+': '+JSON.stringify(s.loadout);});});
return {dt, lo, toasts: await toast()};
