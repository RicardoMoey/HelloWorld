const t0=Date.now();
await page.dblclick("button:has-text('FUNDAR BASE')"); await sleep(2500);
await shot('geo_first');
const r = {st: await stack(), t: await txt(2500), g: await gcur(), ms: Date.now()-t0};
const btns = await page.evaluate(()=>[...document.querySelectorAll('.geo-acts .btn, .geo-acts button')].map(b=>({t:b.innerText.replace(/\s+/g,' '), sw:b.scrollWidth, cw:b.clientWidth, trunc: [...b.querySelectorAll('*')].some(e=>e.scrollWidth>e.clientWidth+1)})));
r.btns=btns; return r;
