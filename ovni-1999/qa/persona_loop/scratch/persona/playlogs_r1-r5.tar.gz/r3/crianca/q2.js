await page.click("text=Local de Terror"); await sleep(300);
const f0=await shot('qb_terror');
const sum = await page.evaluate(()=>document.querySelector('.qb-sum, [class*=summary], [class*=resumo]')?.innerText);
const t0=Date.now();
await page.dblclick("button:has-text('COMEÇAR')"); 
const seen=[]; for(let i=0;i<20;i++){ seen.push((Date.now()-t0)+':'+(await stack()).join('>')); await sleep(250); }
const f=await shot('after_dbl');
return {seen, f, f0, t: await txt(1200)};
