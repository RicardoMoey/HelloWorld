await page.keyboard.press('Escape'); await sleep(600);
const opts={noMissions:true}; 
const t0=Date.now(); const ev=[];
while (Date.now()-t0<90000) { const d = await page.evaluate(()=>OV.Game.G.t); if (d > 861740 + 50*3600) break; const r = await geoStep(8000, opts); ev.push(...r.ev); if (r.battle) break; }
await page.keyboard.press('p'); await sleep(300);
return {ev, g: await gcur()};
