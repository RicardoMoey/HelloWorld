await page.keyboard.press('Escape'); await sleep(600);
await page.keyboard.press('Escape'); await sleep(800);
const out=[]; const t0=Date.now();
while (Date.now()-t0 < 520000) {
  const r = await geoStep(Math.max(10000, 520000-(Date.now()-t0)), {});
  out.push(...r.ev);
  if (!r.battle) break;
  await sleep(1500); await shot('cx_start');
  const b = await playTurns3(12,'cx');
  out.push('BATTLE: '+JSON.stringify(b.map(x=>({t:x.turn,c:x.c,ff:x.ff,dl:x.dl}))).slice(0,1500));
  break;
}
return {out, st: await stack()};
