await page.keyboard.press('Escape'); await sleep(500);
await page.click("text=Base Alienígena"); await sleep(250);
await page.click(".qb-month button:has-text('4'), button:text-is('4')").catch(e=>log('month click fail '+e.message));
await sleep(250);
await page.click("text=Noite"); await sleep(250);
const f=await shot('qb_base');
return {st: await stack(), t: await txt(2500)};
