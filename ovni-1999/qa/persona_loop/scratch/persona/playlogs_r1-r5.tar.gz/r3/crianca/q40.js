await page.locator('text=Skyranger-1').last().click(); await sleep(600);
await shot('sky_sel');
const b = page.locator("button:visible:has-text('Regressar à base')");
const n = await b.count(); if (n) { await b.first().click(); await sleep(600); }
// wait for it to come home with time
await page.keyboard.press('5'); 
for (let i=0;i<60;i++){ const s = await page.evaluate(()=>{const c=Object.values(OV.Game.G.crafts).find(c=>/sky/i.test(c.type)); return c.status;}); const g=await gcur(); if (g.popup) { await page.keyboard.press('Escape'); await sleep(300);} if (!/returning|patrol|out/.test(s)) break; await sleep(500); }
await page.keyboard.press('p'); await sleep(300);
const sky = await page.evaluate(()=>{const c=Object.values(OV.Game.G.crafts).find(c=>/sky/i.test(c.type)); return c && {st:c.status, n:(c.soldiers||[]).length};});
return {n, sky, g: await gcur()};
