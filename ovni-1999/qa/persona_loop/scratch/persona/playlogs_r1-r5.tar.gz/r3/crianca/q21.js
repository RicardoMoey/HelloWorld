const row = page.locator('.bs-mk-row, [class*=market] [class*=row], .base-mk-row').filter({hasText:'Lança-Foguetes'}).first();
let rowsel = await row.count();
let R = row;
if (!rowsel) { R = page.locator('div').filter({hasText:/^Lança-Foguetes/}).filter({has: page.locator('button:has-text("COMPRAR")')}).last(); }
const cls = await R.evaluate(e=>e.className).catch(e=>'ERR '+e.message);
await R.scrollIntoViewIfNeeded();
await R.locator('button:has-text("+10")').click(); await sleep(200);
const q1 = await R.innerText();
await R.locator('button:has-text("COMPRAR")').dblclick(); await sleep(600);
const q2 = await R.innerText();
await shot('market_buy');
const orders = await page.evaluate(()=>JSON.stringify(OV.Game.G.bases[0].transfers||OV.Game.G.transfers||OV.Game.G.bases[0].orders||null));
const funds = await page.evaluate(()=>OV.Game.G.funds);
return {cls, q1, q2, orders: orders && orders.slice(0,800), funds, toasts: await toast()};
