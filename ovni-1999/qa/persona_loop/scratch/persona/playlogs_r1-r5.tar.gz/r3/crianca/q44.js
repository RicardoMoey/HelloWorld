await page.keyboard.press('Enter'); await sleep(1200);
await page.reload(); await sleep(2000);
await page.click("text=BATALHA RÁPIDA"); await sleep(700);
await page.click("text=Local de Terror"); await sleep(250);
await page.locator("button:visible", {hasText: /^3$/}).first().click(); await sleep(250);
const races=[];
for (let i=0;i<25;i++){ const r = await page.evaluate(()=>{const t=document.body.innerText; const m=t.match(/RAÇA PROVÁVEL\n([^\n]+)/); return m&&m[1];}); races.push(r); if (/Cris/i.test(r||'')) break; await page.click("button:has-text('ALEATÓRIA')"); await sleep(200); }
await shot('qb_chrys');
return races;
