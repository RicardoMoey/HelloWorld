await page.keyboard.press('1'); await sleep(200);
await page.dblclick("button:has-text('ESCOLHER LOCAL')"); await sleep(1500);
await shot('pickloc');
return {st: await stack(), t: await txt(1500)};
