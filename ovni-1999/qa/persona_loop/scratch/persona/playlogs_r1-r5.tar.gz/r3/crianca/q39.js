await page.locator("button:visible:has-text('CANCELAR')").click(); await sleep(1200);
await shot('after_cancel');
return {s: await stack(), g: await gcur(), pop: await popTxt(), sky: await page.evaluate(()=>{const c=Object.values(OV.Game.G.crafts).find(c=>/sky/i.test(c.type)); return c && {st:c.status, n:(c.soldiers||[]).length};})};
