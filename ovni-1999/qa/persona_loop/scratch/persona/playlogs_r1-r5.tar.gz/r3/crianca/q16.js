await page.keyboard.press('Enter'); await sleep(500);
await page.click(".geo-acts button:has-text('Bases')"); await sleep(1200);
await shot('base_screen');
return {st: await stack(), t: await txt(2500)};
