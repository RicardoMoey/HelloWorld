await page.locator("button:visible:has-text('CONTINUAR')").click(); await sleep(600);
let s=await stack(); if (s.slice(-1)[0]!=='menu') { await page.keyboard.press('Escape'); await sleep(500); }
await page.click("text=NOVA CAMPANHA"); await sleep(800);
await shot('newcamp');
return {st: await stack(), t: await txt(2000)};
