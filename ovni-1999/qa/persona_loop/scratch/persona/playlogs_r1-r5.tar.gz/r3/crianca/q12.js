await page.locator('.bs-top button').last().click().catch(async()=>{ await page.mouse.click(472,26); });
await sleep(600);
const f=await shot('msglog');
const t = await page.evaluate(()=>{const n=[...document.querySelectorAll('[class*=log]')].map(e=>e.innerText).filter(Boolean); return n.join('\n----\n').slice(0,3000);});
await page.keyboard.press('Escape'); await sleep(300);
return t;
