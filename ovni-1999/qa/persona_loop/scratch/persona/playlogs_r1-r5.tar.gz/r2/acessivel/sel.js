S.selectTab = async (id) => { for (let i = 0; i < 12; i++) { const s = await S.st(); if (s.unit && s.unit.id === id) return true; await page.keyboard.press('Tab'); await sleep(250); } return false; };
S.goKb = async (id, x, y) => {
  if (!(await S.selectTab(id))) return 'nosel ' + id;
  await S.cursorTo(x, y); await sleep(200);
  const s = await S.st();
  const r = { id, label: s.pathLabel, last: s.pathStates && s.pathStates.slice(-1)[0] };
  if (s.pathSteps > 0) { await page.keyboard.press('Enter'); await sleep(250); await S.waitIdle(60000); }
  const s2 = await S.st(); r.at = s2.unit && [s2.unit.x, s2.unit.y, s2.unit.tu]; r.vis = s2.visibleAliens.map(a => [a.id, a.x, a.y]);
  return r;
};
return 'sel';
