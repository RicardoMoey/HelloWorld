S.cursorTo = async (tx, ty) => {
  let c = await S.cur();
  if (!c) { await page.keyboard.press('ArrowUp'); await sleep(120); c = await S.cur(); }
  const K = { up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight' };
  let last = null;
  for (let i = 0; i < 150 && c && (c.x !== tx || c.y !== ty); i++) {
    const dir = await page.evaluate(([tx, ty, last]) => {
      const B = OV.Game.B, st = OV.BattleUI.debug.state().kcur;
      const anchor = st.anchor || null;
      let best = null, bd = 1e9;
      for (const d of ['up', 'down', 'left', 'right']) {
        // look ahead two presses of the same key
        let r = OV.BattleUI.model.kbStep(B.map, st.x, st.y, d, anchor);
        const d1 = Math.abs(r.x - tx) + Math.abs(r.y - ty);
        let r2 = OV.BattleUI.model.kbStep(B.map, r.x, r.y, d, r.anchor);
        const d2 = Math.abs(r2.x - tx) + Math.abs(r2.y - ty);
        const score = Math.min(d1, d2 - 0.5) + (d === last ? -0.1 : 0);
        if (score < bd) { bd = score; best = d; }
      }
      return best;
    }, [tx, ty, last]);
    await page.keyboard.press(K[dir]); S.presses++; last = dir; await sleep(50);
    c = await S.cur();
  }
  return c;
};
return 'kb2';
