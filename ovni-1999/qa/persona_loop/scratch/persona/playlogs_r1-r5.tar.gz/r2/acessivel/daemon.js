// Persistent Playwright driver; accepts POST bodies of JS (async fn body with page, cdp, ctx, S) and returns result.
const { chromium } = require('/opt/node-tools/node_modules/playwright');
const http = require('http');
const fs = require('fs');
const DIR = __dirname;
const GAMEPORT = process.argv[2];
const T0 = Date.now();
const S = { log: [], errors: [], shot: 0 };
function log(m){ const l = ((Date.now()-T0)/1000).toFixed(1)+'s '+m; S.log.push(l); fs.appendFileSync(DIR+'/log.txt', l+'\n'); }
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1024, height: 560 }, deviceScaleFactor: 2.5, hasTouch: false });
  const page = await ctx.newPage();
  const cdp = await ctx.newCDPSession(page);
  await cdp.send('Emulation.setEmulatedVisionDeficiency', { type: 'deuteranopia' });
  page.on('pageerror', e => { S.errors.push('pageerror: '+e.message); log('PAGEERROR '+e.message); });
  page.on('console', m => { if (m.type()==='error') { S.errors.push('console: '+m.text()); log('CONSOLEERR '+m.text()); } });
  await page.goto('http://127.0.0.1:'+GAMEPORT+'/ovni-1999/index.html?nosw=1');
  log('loaded');
  const shot = async (name) => { const p = DIR+'/shots/'+String(++S.shot).padStart(3,'0')+'-'+name+'.png'; await page.screenshot({ path: p }); return p; };
  const focus = () => page.evaluate(() => { const a = document.activeElement; if (!a) return null; const r = a.getBoundingClientRect(); const cs = getComputedStyle(a); return { tag: a.tagName, id: a.id, cls: a.className && a.className.baseVal === undefined ? a.className : '', text: (a.innerText||a.value||'').slice(0,60).replace(/\n/g,' | '), aria: a.getAttribute('aria-label'), role: a.getAttribute('role'), rect: [Math.round(r.x),Math.round(r.y),Math.round(r.width),Math.round(r.height)], outline: cs.outlineStyle+' '+cs.outlineWidth+' '+cs.outlineColor, boxShadow: cs.boxShadow }; });
  const srv = http.createServer((req, res) => {
    let body = ''; req.on('data', d => body += d); req.on('end', async () => {
      try {
        const fn = new Function('page','cdp','ctx','S','log','shot','focus','sleep', 'return (async()=>{'+body+'})()');
        const r = await fn(page, cdp, ctx, S, log, shot, focus, ms => new Promise(r => setTimeout(r, ms)));
        res.end(JSON.stringify(r === undefined ? null : r, null, 1));
      } catch (e) { res.end('ERR '+(e && e.stack || e)); }
    });
  });
  srv.listen(+process.argv[3], '127.0.0.1', () => log('daemon ready'));
})();
