S.tryShoot = async (log2) => {
  let s = await S.st();
  if (!s.visibleAliens.length || !s.unit) return false;
  await page.keyboard.press('e'); await sleep(300);
  s = await S.st();
  if (!s.menu) { log2.push('no menu'); return false; }
  const ents = s.menu.entries.map(e => (e.label||e.key||'') + (e.enabled ? '' : '(x)'));
  // prefer aimed if enabled else snap
  let idx = s.menu.entries.findIndex(e => e.enabled && /apont/i.test(e.label||''));
  if (idx < 0) idx = s.menu.entries.findIndex(e => e.enabled);
  if (idx < 0) { await page.keyboard.press('Escape'); await sleep(150); log2.push('menu disabled '+ents.join('|')); return false; }
  await page.keyboard.press(String(idx + 1)); await sleep(300);
  await page.keyboard.press('Tab'); await sleep(300);
  s = await S.st();
  const t = s.target;
  log2.push('aim '+JSON.stringify({ents, mode:s.mode, kcur:s.kcur, target: t && {hit:t.hitPct, blocked:t.blocked, label:t.label}}));
  if (!t || t.blocked) { await page.keyboard.press('Escape'); await sleep(200); return false; }
  await page.keyboard.press('Enter'); await sleep(300);
  s = await S.st();
  if (s.mode === 'target' && !s.playing) { await page.keyboard.press('Enter'); await sleep(200); }
  await S.waitIdle(60000);
  return true;
};
S.playTurn = async (plan) => {
  const out = [];
  const seen = new Set();
  for (let n = 0; n < 12; n++) {
    let s = await S.st();
    if (!s || s.ended || s.result || s.side !== 'xcom') break;
    const u = s.unit; if (!u) break; if (seen.has(u.id)) { await page.keyboard.press("Tab"); await sleep(300); const s9=await S.st(); if(!s9.unit||seen.has(s9.unit.id)) break; continue; } seen.add(u.id);
    for (let k = 0; k < 2; k++) { if (!(await S.tryShoot(out))) break; }
    s = await S.st(); if (s.ended || s.result) break;
    const tgt = plan(u, s);
    if (tgt && s.unit && s.unit.tu > 20) {
      await S.cursorTo(tgt[0], tgt[1]); await sleep(150);
      const sp = await S.st();
      const last = sp.pathStates && sp.pathStates[sp.pathStates.length-1];
      if (sp.pathSteps > 0 && last !== 'far' && last !== 'no' && !/insuf|bloq/i.test(sp.pathLabel||'')) {
        await page.keyboard.press('Enter'); await sleep(250);
        await S.waitIdle(60000);
      } else out.push('u'+u.id+' skip '+sp.pathLabel+' '+last);
      for (let k = 0; k < 2; k++) { if (!(await S.tryShoot(out))) break; }
    }
    s = await S.st();
    out.push('u'+u.id+' -> '+(s.unit? [s.unit.x,s.unit.y,s.unit.tu].join(','):'?')+' vis='+s.visibleAliens.length);
    if (s.ended || s.result) break;
    await page.keyboard.press('Space'); await sleep(350); // Feito -> next
  }
  return out;
};
S.endTurn = async () => {
  await page.keyboard.press('Backspace'); await sleep(500);
  const m = await page.evaluate(() => { const d = document.querySelector('[role=dialog],[role=alertdialog]'); return d ? d.innerText.slice(0, 200) : null; });
  if (m !== null) { await page.keyboard.press('Enter'); await sleep(400); }
  const t0 = Date.now();
  // speed up alien turn with Space presses
  let s;
  while (Date.now() - t0 < 120000) { s = await S.st(); if (!s || s.ended || s.result) break; if (s.side === 'xcom' && !s.playing && s.phase !== 'alien') break; await page.keyboard.press('Space'); await sleep(400); }
  return { confirm: m, secs: (Date.now() - t0) / 1000, s: s && { turn: s.turn, side: s.side, result: s.result, report: s.report } };
};
return 'turn ok';
