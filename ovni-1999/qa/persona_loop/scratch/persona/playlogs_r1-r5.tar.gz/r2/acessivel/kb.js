S.presses = 0;
S.cur = async () => (await S.st()).kcur;
S.cursorTo = async (tx, ty) => {
  let c = await S.cur();
  if (!c) { await page.keyboard.press('ArrowUp'); await sleep(120); c = await S.cur(); }
  for (let i = 0; i < 120 && c && (c.x !== tx || c.y !== ty); i++) {
    const dx = Math.sign(tx - c.x), dy = Math.sign(ty - c.y);
    let k;
    if (dx < 0 && dy < 0) k = 'ArrowUp'; else if (dx > 0 && dy < 0) k = 'ArrowRight';
    else if (dx > 0 && dy > 0) k = 'ArrowDown'; else if (dx < 0 && dy > 0) k = 'ArrowLeft';
    else if (dx === 0) k = (i % 2) ? (dy < 0 ? 'ArrowUp' : 'ArrowDown') : (dy < 0 ? 'ArrowRight' : 'ArrowLeft');
    else k = (i % 2) ? (dx < 0 ? 'ArrowUp' : 'ArrowDown') : (dx < 0 ? 'ArrowLeft' : 'ArrowRight');
    await page.keyboard.press(k); S.presses++; await sleep(60);
    c = await S.cur();
  }
  return c;
};
S.moveKb = async (tx, ty) => {
  await S.cursorTo(tx, ty);
  await sleep(150);
  const s = await S.st();
  const info = { kcur: s.kcur, steps: s.pathSteps, label: s.pathLabel, states: s.pathStates && s.pathStates.slice(-1)[0] };
  await page.keyboard.press('Enter'); S.presses++; await sleep(250);
  let s2 = await S.st();
  if (s2.lock >= 0 || (s2.unit && s.unit && s2.unit.tu === s.unit.tu && !s2.playing)) { await page.keyboard.press('Enter'); S.presses++; info.second = true; }
  await S.waitIdle(60000);
  const s3 = await S.st();
  info.after = s3.unit && [s3.unit.x, s3.unit.y, s3.unit.tu];
  return info;
};
return 'kb ok';
