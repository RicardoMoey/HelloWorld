S.knownNear = (ux, uy, tx, ty, maxStep) => page.evaluate(([ux, uy, tx, ty, maxStep]) => {
  const B = OV.Game.B, m = B.map; let best = null, bd = 1e9;
  for (let y = 0; y < m.h; y++) for (let x = 0; x < m.w; x++) {
    const i = x + y * m.w; if (!(m.disc[i] & 1)) continue;
    if (Math.max(Math.abs(x - ux), Math.abs(y - uy)) > maxStep) continue;
    if (B.units.some(u => u.x === x && u.y === y && u.z === 0 && u.status !== 'dead')) continue;
    const d = Math.hypot(x - tx, y - ty); if (d < bd) { bd = d; best = [x, y]; }
  }
  return best;
}, [ux, uy, tx, ty, maxStep]);
S.advance = async (id, tx, ty, step) => {
  if (!(await S.selectTab(id))) return 'nosel ' + id;
  const s = await S.st(); const u = s.unit;
  for (let st = step; st >= 2; st--) {
    const t = await S.knownNear(u.x, u.y, tx, ty, st); if (!t) continue;
    await S.cursorTo(t[0], t[1]); await sleep(200);
    const p = await S.st(); const last = p.pathStates && p.pathStates.slice(-1)[0];
    if (p.pathSteps > 0 && last === 'ok') { await page.keyboard.press('Enter'); await sleep(250); await S.waitIdle(60000); const s2 = await S.st(); return { id, to: t, at: s2.unit && [s2.unit.x, s2.unit.y, s2.unit.tu], vis: s2.visibleAliens.map(a => [a.id, a.x, a.y]) }; }
  }
  return { id, stuck: true };
};
return 'near';
