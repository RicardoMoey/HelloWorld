S.geoRun = async (maxMs, handler) => {
  const out = []; const t0 = Date.now();
  await page.keyboard.press('5');
  while (Date.now() - t0 < maxMs) {
    await sleep(700);
    const d = await page.evaluate(() => { const d = document.querySelector('[role=dialog],[role=alertdialog]'); return d ? d.innerText.slice(0, 400) : null; });
    if (d) {
      const f = await focus();
      const date = await page.evaluate(() => document.body.innerText.match(/GEOSCAPE\n([^\n]+)/)?.[1]);
      out.push(date + ' ' + d.replace(/\n/g, ' / ').slice(0, 220) + ' || focus=' + (f.aria || f.text).slice(0, 30));
      const act = handler ? handler(d) : 'Enter';
      if (act === 'stop') { await shot('geo-stop'); break; }
      for (const k of act.split(',')) { await page.keyboard.press(k); await sleep(400); }
      await page.keyboard.press('5'); await sleep(200);
    }
    const sc = await page.evaluate(() => document.body.className);
    if (/in-battle/.test(sc)) { out.push('battle!'); break; }
  }
  return out;
};
return 'geo';
