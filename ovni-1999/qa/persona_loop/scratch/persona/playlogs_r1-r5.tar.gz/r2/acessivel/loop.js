S.endTurn2 = async () => {
  const n0 = (await S.st()).turn;
  await page.keyboard.press('Backspace'); await sleep(700);
  const m = await page.evaluate(() => { const d = document.querySelector('[role=dialog],[role=alertdialog]'); return d ? d.innerText.slice(0, 200) : null; });
  if (m !== null) { await page.keyboard.press('Enter'); await sleep(400); }
  const t0 = Date.now(); let s;
  while (Date.now() - t0 < 150000) { s = await S.st(); if (!s || s.ended || s.result) break; if (s.side === 'xcom' && !s.playing && s.turn > n0) break; if (s.playing && s.side !== 'xcom') { await page.keyboard.press('Space'); } await sleep(300); }
  return { secs: (Date.now() - t0) / 1000, turn: s && s.turn, result: s && s.result };
};
return 'loop2';
