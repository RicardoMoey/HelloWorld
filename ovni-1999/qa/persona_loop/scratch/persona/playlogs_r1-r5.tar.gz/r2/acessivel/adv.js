S.advTurn = async (tx, ty, step) => {
  const ids = await page.evaluate(() => OV.Game.B.units.filter(u => u.side === 'xcom' && u.status === 'ok' && u.x >= 0).map(u => u.id));
  const out = [];
  for (const id of ids) {
    const s = await S.st(); if (s.ended || s.result) break;
    if (s.visibleAliens.length) { out.push('CONTACT'); break; }
    const k = id % 5 - 2;
    const r = await S.advance(id, tx + k * 2, ty + (id % 2) * 2, step);
    out.push(JSON.stringify(r));
  }
  return out;
};
return 'adv';
