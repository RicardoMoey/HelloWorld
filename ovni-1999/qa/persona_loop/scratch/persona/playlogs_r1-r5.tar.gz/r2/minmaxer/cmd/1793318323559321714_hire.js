const btns = page.locator('button', { hasText: 'CONTRATAR +10' });
const n = await btns.count();
await btns.nth(0).click(); await S.sleep(500);
const m1 = await page.evaluate(() => document.querySelector('#modals') ? document.querySelector('#modals').innerText : '');
if (m1.trim()) { await shot('hire_confirm'); await page.keyboard.press('Enter'); await S.sleep(400); }
await page.locator('button', { hasText: 'CONTRATAR +10' }).nth(0).click(); await S.sleep(500);
const m2 = await page.evaluate(() => document.querySelector('#modals') ? document.querySelector('#modals').innerText : '');
if (m2.trim()) { await page.keyboard.press('Enter'); await S.sleep(400); }
const f = await shot('hired');
return { n, m1, m2, f, funds: await page.evaluate(()=>OV.Game.G.funds), dl: await page.evaluate(()=>JSON.stringify(OV.Game.G.bases[0].deliveries)) };
