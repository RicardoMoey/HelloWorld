await page.keyboard.press('3'); await S.sleep(300);
await page.getByText('ESCOLHER LOCAL').click();
await S.sleep(1200);
const f = await shot('step2');
return { f, txt: await page.evaluate(() => document.body.innerText.slice(0, 1500)) };
