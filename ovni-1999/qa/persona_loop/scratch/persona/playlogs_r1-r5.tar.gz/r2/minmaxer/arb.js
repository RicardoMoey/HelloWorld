const OV = require('/home/user/HelloWorld/ovni-1999/tools/load')({ finalize: true });
const D = OV.Data;
// buy<sell arbitrage
const rows=[];
for (const [k,it] of Object.entries(D.items)) {
  if (it.buy!=null && it.sell!=null && it.sell>=it.buy) rows.push(['ARB',k,it.buy,it.sell]);
}
console.log(rows);
// manufacture table
const out=[];
for (const [k,m] of Object.entries(D.manufacture)) {
  const it = D.items[k] || (D.crafts&&D.crafts[k]) || {};
  let mat=0, matBuy=0; for (const [mk,n] of Object.entries(m.materials||m.mats||{})) { mat += n*((D.items[mk]||{}).sell||0); matBuy+= n*((D.items[mk]||{}).buy||Infinity);}
  const sell = it.sell || m.sell || 0;
  const prof = sell - m.cost - mat;
  out.push([k, m.hours, m.cost, m.costOrig, sell, mat, (prof/m.hours).toFixed(0), 'buyMat', matBuy, m.requires]);
}
out.sort((a,b)=>b[6]-a[6]); console.table(out.slice(0,40));
console.log(Object.keys(D.manufacture[Object.keys(D.manufacture)[0]]));
