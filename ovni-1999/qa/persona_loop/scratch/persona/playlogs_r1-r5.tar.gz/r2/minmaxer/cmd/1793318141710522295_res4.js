await page.locator('#modals button', { hasText: 'INICIAR' }).first().click(); await S.sleep(900);
const f = await shot('laser_started');
const t = await page.evaluate(() => document.body.innerText.slice(300, 2500));
const g = await page.evaluate(() => JSON.stringify(OV.Game.G.bases[0].research));
return { f, t, g };
