await page.keyboard.press('4'); await S.sleep(1000);
const f = await shot('pessoal');
return { f, t: await page.evaluate(() => document.body.innerText.slice(420, 2500)), up: await page.evaluate(()=>JSON.stringify(OV.Economy.upkeep(OV.Game.G))+' income '+OV.Economy.income(OV.Game.G)) };
