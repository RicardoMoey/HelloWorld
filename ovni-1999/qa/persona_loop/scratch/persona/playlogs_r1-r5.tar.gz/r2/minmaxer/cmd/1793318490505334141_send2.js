await page.getByText('Skyranger-1').last().click(); await S.sleep(800);
await shot('sky_sent');
return { t: await page.evaluate(()=>document.body.innerText.slice(-600)) };
