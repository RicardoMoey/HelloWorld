const st = () => page.evaluate(() => OV.BattleUI.debug.state());
const B = () => page.evaluate(() => 1);
const idle = async (ms = 60000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const s = await st(); if (!s.playing && (s.side === 'xcom' || s.phase === 'over' || s.ended)) return (Date.now() - t0); await S.sleep(150); } return -1; };
const units = () => page.evaluate(() => OV.Game.B.units.filter(u => u.onMap && u.x >= 0).map(u => ({ id: u.id, side: u.side, type: u.type, x: u.x, y: u.y, z: u.z, tu: u.tu, hp: u.hp, st: u.status, kneel: !!u.kneel, vis: u.side !== 'alien' ? true : OV.LOS.isVisibleTo(OV.Game.B, 'xcom', u) })));
const selectU = async (id) => { const p = await page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), id); await page.mouse.click(p.x, p.y); await S.sleep(150); return p; };
const centre = async (x, y, z) => page.evaluate(([a, b, c]) => OV.BattleUI.debug.centre && OV.BattleUI.debug.centre(a, b, c), [x, y, z]);
const tp = (x, y, z) => page.evaluate(([a, b, c]) => OV.BattleUI.debug.tileToScreen(a, b, c), [x, y, z]);
async function moveTo(x, y, z = 0) {
  let p = await tp(x, y, z);
  if (!p || p.x < 200 || p.x > 1240 || p.y < 60 || p.y > 760) { await centre(x, y, z); await S.sleep(400); p = await tp(x, y, z); }
  await page.mouse.move(p.x, p.y, { steps: 3 }); await S.sleep(120);
  let s = await st();
  const lab = s.pathLabel;
  await page.mouse.click(p.x, p.y); await S.sleep(100);
  s = await st();
  if (!s.playing && s.lock >= 0) { await page.mouse.click(p.x, p.y); await S.sleep(80); }
  await idle();
  return lab;
}
async function aimAt(hand, modeWord, targetId) {
  await page.keyboard.press(hand === 'L' ? 'q' : 'e'); await S.sleep(150);
  const m = (await st()).menu;
  if (!m || !m.entries) return { err: 'nomenu' };
  const k = m.entries.findIndex(e => e.label.toLowerCase().startsWith(modeWord));
  if (k < 0 || !m.entries[k].enabled) { await page.keyboard.press('Escape'); return { err: 'mode', entries: m.entries }; }
  await page.keyboard.press(String(k + 1)); await S.sleep(120);
  const p = await page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), targetId);
  await page.mouse.move(p.x, p.y, { steps: 2 }); await S.sleep(150);
  return { p, target: (await st()).target, entries: m.entries };
}
async function fire(p) { await page.mouse.click(p.x, p.y); await S.sleep(200); await idle(); }
async function endTurn() { await page.keyboard.press('Backspace'); await S.sleep(400); const mo = await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText : ''; }); if (mo.trim()) { await page.keyboard.press('Enter'); await S.sleep(300); } const t0 = Date.now(); await S.sleep(500); for (let i = 0; i < 600; i++) { const s = await st(); if (s.side === 'xcom' && !s.playing) break; if (s.phase === 'over' || s.ended) break; if (i % 4 === 0) await page.keyboard.press('Space'); await S.sleep(200); } return (Date.now() - t0) / 1000; }
async function tryShots(id) {
  const out = [];
  for (let k = 0; k < 3; k++) {
    const vis = (await units()).filter(u => u.side === 'alien' && u.st === 'ok' && u.vis);
    const me = (await units()).find(u => u.id === id);
    if (!vis.length || !me || me.st !== 'ok') break;
    vis.sort((a, b) => Math.hypot(a.x - me.x, a.y - me.y) - Math.hypot(b.x - me.x, b.y - me.y));
    let shotDone = false;
    for (const al of vis) {
      for (const mode of ['tiro apontado', 'tiro rápido', 'rajada']) {
        await selectU(id);
        const hand = await page.evaluate((i) => { const u = OV.BUnits.findUnit(OV.Game.B, i); return u.items.R !== null ? 'R' : 'L'; }, id);
        const a = await aimAt(hand, mode, al.id);
        if (a.err) continue;
        if (!a.target || a.target.blocked || (a.target.hitPct || 0) < 15 || (a.target.sub && /aliado|Risco/.test(a.target.sub))) { await page.keyboard.press('Escape'); await S.sleep(80); if (a.target && a.target.blocked) break; continue; }
        await fire(a.p);
        const al2 = (await units()).find(u => u.id === al.id);
        out.push(id + ' ' + mode + ' ' + a.target.label + ' -> ' + (al2 ? al2.hp + al2.st : 'gone'));
        shotDone = true; break;
      }
      if (shotDone) break;
    }
    if (!shotDone) break;
  }
  return out;
}
async function towards(id, tx, ty, maxStep, spread) {
  const me = (await units()).find(u => u.id === id);
  if (!me || me.st !== 'ok') return null;
  const d = Math.hypot(tx - me.x, ty - me.y);
  if (d < 2) return null;
  const k = Math.min(maxStep, d - 1) / d;
  let x = Math.round(me.x + (tx - me.x) * k + (spread || 0)), y = Math.round(me.y + (ty - me.y) * k);
  const W = await page.evaluate(() => [OV.Game.B.map.w, OV.Game.B.map.h]);
  x = Math.max(0, Math.min(W[0] - 1, x)); y = Math.max(0, Math.min(W[1] - 1, y));
  await selectU(id);
  for (const [dx, dy] of [[0,0],[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[2,0],[-2,0]]) {
    const r = await moveTo(x + dx, y + dy, 0);
    const me2 = (await units()).find(u => u.id === id);
    if (!me2 || me2.x !== me.x || me2.y !== me.y) return r + ' -> ' + (me2 ? me2.x + ',' + me2.y + ' tu' + me2.tu + ' ' + me2.st : 'gone');
  }
  return 'stuck';
}
// advance time at speed SPEED, auto-dismiss benign popups, stop on others or after MAXS seconds
const SPEED = '3', MAXS = 90, BENIGN = /CHEGARAM ENCOMENDAS|INSTALAÇÃO CONCLUÍDA|FABRICO CONCLU|GRAVA/i;
const t0 = Date.now(); const seen = [];
await page.keyboard.press(SPEED);
while ((Date.now() - t0) / 1000 < MAXS) {
  await S.sleep(400);
  const pop = await page.evaluate(() => { const p = document.querySelector('.geo-pop, .geo-dlg'); return p ? p.innerText.slice(0, 900) : null; });
  if (pop) {
    seen.push(pop.slice(0, 120).replace(/\n/g, ' '));
    if (BENIGN.test(pop)) { await page.keyboard.press('Enter'); await S.sleep(300); await page.keyboard.press(SPEED); continue; }
    const f = await shot('pop');
    return { secs: (Date.now() - t0) / 1000, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), funds: await page.evaluate(() => OV.Game.G.funds), pop, f, seen };
  }
  const sc = await page.evaluate(() => OV.Scenes.top().id);
  if (sc !== 'geoscape') return { scene: sc, f: await shot('scene_' + sc), seen };
}
return { timeout: true, date: await page.evaluate(() => OV.U.fmtDate(OV.Game.G.t)), seen };
