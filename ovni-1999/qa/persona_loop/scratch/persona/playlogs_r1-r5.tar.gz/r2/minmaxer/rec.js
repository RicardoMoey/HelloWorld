const sim = require('/home/user/HelloWorld/ovni-1999/tools/sim.js');
const OV = globalThis.OV;
const ufo = process.argv[2] || 'small_scout';
let tot = { ps: 0, nav: 0, el: 0, win: 0, n: 0 }; const per = [];
for (let s = 1; s <= 16; s++) {
  const r = sim.runBattle({ ufo, diff: 1, month: 0, seed: s, check: false });
  if (r.outcome !== 'win') continue;
  const d = OV.Battle.debrief(r.B, { researched: [] });
  tot.win++; tot.ps += d.recovered.ufo_power_source | 0; tot.nav += d.recovered.ufo_navigation | 0; tot.el += d.recovered.elerium_115 | 0;
  per.push([s, d.recovered.ufo_power_source | 0, d.recovered.ufo_navigation | 0, d.recovered.elerium_115 | 0, (r.B.specials.POWER_SOURCE||[]).length, (r.B.specials.NAVIGATION||[]).length]);
}
console.log(ufo, JSON.stringify(tot)); console.log(JSON.stringify(per));
