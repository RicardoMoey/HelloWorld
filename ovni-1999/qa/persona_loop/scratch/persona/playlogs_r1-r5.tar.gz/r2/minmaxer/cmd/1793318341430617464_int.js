await page.keyboard.press('i'); await S.sleep(1000);
const f = await shot('intercept_dlg');
return { f, t: await page.evaluate(() => { const m=document.querySelector('#modals, .geo-dlg'); return document.body.innerText.slice(-1800); }) };
