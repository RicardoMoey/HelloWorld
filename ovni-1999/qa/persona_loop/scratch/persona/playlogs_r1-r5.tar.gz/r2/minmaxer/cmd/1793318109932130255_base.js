await page.keyboard.press('Enter'); await S.sleep(500);
await page.keyboard.press('b'); await S.sleep(1500);
const f = await shot('base');
return { f, txt: await page.evaluate(() => document.body.innerText.slice(0, 2500)) };
