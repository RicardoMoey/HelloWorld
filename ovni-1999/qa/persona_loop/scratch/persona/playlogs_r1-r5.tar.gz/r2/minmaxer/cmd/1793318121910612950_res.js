await page.keyboard.press('2'); await S.sleep(1200);
const f = await shot('research');
return { f, txt: await page.evaluate(() => document.querySelector('.bs-main, main, #app').innerText.slice(0, 2500)) };
