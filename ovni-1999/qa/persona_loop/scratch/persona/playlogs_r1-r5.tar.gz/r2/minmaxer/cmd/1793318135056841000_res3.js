await page.keyboard.press('n'); await S.sleep(900);
const f = await shot('newproj');
const t = await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText.slice(0, 2000) : ''; });
return { f, t };
