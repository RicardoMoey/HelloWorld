await S.sleep(1500);
let sc = await page.evaluate(()=>OV.Scenes.top().id);
if (sc === 'dogfight') { await page.keyboard.press('Escape'); await S.sleep(1000); }
const f = await shot('after_df');
return { sc: await page.evaluate(()=>OV.Scenes.top().id), f, pop: await page.evaluate(() => { const p = document.querySelector('.geo-pop, .geo-dlg'); return p ? p.innerText : null; }) };
