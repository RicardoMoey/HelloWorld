await page.keyboard.press('q'); await S.sleep(500);
await page.keyboard.press('4'); await S.sleep(300);
await shot('df_running');
const t0 = Date.now(); let txt='';
for (let i=0;i<180;i++) { await S.sleep(500); txt = await page.evaluate(()=>{const d=document.querySelector('[class*=df]'); return document.body.innerText;}); if (/ABATID|DESPENH|DESTRU|FUGIU|ESCAPOU|perdeu o contacto/i.test(txt)) break; if (await page.evaluate(()=>OV.Scenes.top().id)!=='dogfight') break; }
const f = await shot('df_end2');
return { secs: (Date.now()-t0)/1000, f, scene: await page.evaluate(()=>OV.Scenes.top().id), t: txt.slice(-1500) };
