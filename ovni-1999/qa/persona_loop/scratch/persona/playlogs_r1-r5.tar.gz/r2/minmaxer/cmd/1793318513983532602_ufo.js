return await page.evaluate(()=>{const G=OV.Game.G; const u=G.ufos.find(x=>x.id==='u1'); return JSON.stringify({lat:u.lat,lon:u.lon, ufo:u}).slice(0,900);});
