await page.keyboard.press('e'); await S.sleep(1000);
const f = await shot('send_dlg');
return { f, t: await page.evaluate(()=>document.body.innerText.slice(-1500)) };
