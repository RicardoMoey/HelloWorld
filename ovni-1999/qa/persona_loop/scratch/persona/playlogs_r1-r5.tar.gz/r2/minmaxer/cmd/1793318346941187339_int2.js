await page.getByText('Intercetor-1').first().click(); await S.sleep(800);
const f = await shot('after_pick');
const pop = await page.evaluate(() => document.body.innerText.slice(-1200));
return { f, pop };
