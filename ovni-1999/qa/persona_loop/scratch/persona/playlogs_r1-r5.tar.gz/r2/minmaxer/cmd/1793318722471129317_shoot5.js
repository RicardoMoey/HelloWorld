const st = () => page.evaluate(() => OV.BattleUI.debug.state());
const B = () => page.evaluate(() => 1);
const idle = async (ms = 60000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { const s = await st(); if (!s.playing && (s.side === 'xcom' || s.phase === 'over' || s.ended)) return (Date.now() - t0); await S.sleep(150); } return -1; };
const units = () => page.evaluate(() => OV.Game.B.units.filter(u => u.onMap && u.x >= 0).map(u => ({ id: u.id, side: u.side, type: u.type, x: u.x, y: u.y, z: u.z, tu: u.tu, hp: u.hp, st: u.status, kneel: !!u.kneel, vis: u.side !== 'alien' ? true : OV.LOS.isVisibleTo(OV.Game.B, 'xcom', u) })));
const selectU = async (id) => { const p = await page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), id); await page.mouse.click(p.x, p.y); await S.sleep(150); return p; };
const centre = async (x, y, z) => page.evaluate(([a, b, c]) => OV.BattleUI.debug.centre && OV.BattleUI.debug.centre(a, b, c), [x, y, z]);
const tp = (x, y, z) => page.evaluate(([a, b, c]) => OV.BattleUI.debug.tileToScreen(a, b, c), [x, y, z]);
async function moveTo(x, y, z = 0) {
  let p = await tp(x, y, z);
  if (!p || p.x < 200 || p.x > 1240 || p.y < 60 || p.y > 760) { await centre(x, y, z); await S.sleep(400); p = await tp(x, y, z); }
  await page.mouse.move(p.x, p.y, { steps: 3 }); await S.sleep(120);
  let s = await st();
  const lab = s.pathLabel;
  await page.mouse.click(p.x, p.y); await S.sleep(100);
  s = await st();
  if (!s.playing && s.lock >= 0) { await page.mouse.click(p.x, p.y); await S.sleep(80); }
  await idle();
  return lab;
}
async function aimAt(hand, modeWord, targetId) {
  await page.keyboard.press(hand === 'L' ? 'q' : 'e'); await S.sleep(150);
  const m = (await st()).menu;
  if (!m || !m.entries) return { err: 'nomenu' };
  const k = m.entries.findIndex(e => e.label.toLowerCase().startsWith(modeWord));
  if (k < 0 || !m.entries[k].enabled) { await page.keyboard.press('Escape'); return { err: 'mode', entries: m.entries }; }
  await page.keyboard.press(String(k + 1)); await S.sleep(120);
  const p = await page.evaluate((i) => OV.BattleUI.debug.unitScreen(i), targetId);
  await page.mouse.move(p.x, p.y, { steps: 2 }); await S.sleep(150);
  return { p, target: (await st()).target, entries: m.entries };
}
async function fire(p) { await page.mouse.click(p.x, p.y); await S.sleep(200); await idle(); }
async function endTurn() { await page.keyboard.press('Backspace'); await S.sleep(400); const mo = await page.evaluate(() => { const m = document.querySelector('#modals'); return m ? m.innerText : ''; }); if (mo.trim()) { await page.keyboard.press('Enter'); await S.sleep(300); } const t0 = Date.now(); await S.sleep(500); for (let i = 0; i < 600; i++) { const s = await st(); if (s.side === 'xcom' && !s.playing) break; if (s.phase === 'over' || s.ended) break; if (i % 4 === 0) await page.keyboard.press('Space'); await S.sleep(200); } return (Date.now() - t0) / 1000; }
await page.keyboard.press('k'); await S.sleep(300); await idle();
const a = await aimAt('R', 'tiro apontado', 53);
await shot('aim5');
if (a.err) return a;
const tg = a.target;
await fire(a.p);
const us = await units();
return { tg, alien: us.find(u=>u.id===53), me: us.find(u=>u.id===5), log: await page.evaluate(()=>JSON.stringify(OV.BattleUI.debug.log().slice(-4))) };
