await page.mouse.click(690, 245); await S.sleep(800);
const txt1 = await page.evaluate(() => document.querySelector('.cp-side, aside, .nc-side') ? 'x' : document.body.innerText.slice(200, 700));
await shot('germany');
await page.getByText('FUNDAR BASE').click();
await S.sleep(2500);
const f = await shot('geo_start');
return { txt1, f, scene: await page.evaluate(()=>OV.Scenes.top().id), txt: await page.evaluate(() => document.body.innerText.slice(0, 1500)) };
