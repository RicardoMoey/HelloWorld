// Camper: X-COM nunca sai da nave; todos ajoelham e terminam o turno (fogo de reação). Compara com o bot.
const sim = require('/home/user/HelloWorld/ovni-1999/tools/sim.js');
const OV = globalThis.OV;
const args = Object.fromEntries(process.argv.slice(2).map((a) => a.split('=')));
const ufo = args.ufo || 'small_scout', diff = +(args.diff || 1), month = +(args.month || 0), night = +(args.night || 0), seeds = +(args.seeds || 10), kind = args.kind || undefined, turns = +(args.turns || 40), landed = +(args.landed||0);
function drain(gen) { let r; while (!(r = gen.next()).done); return r.value; }
function camper(seed) {
  const mission = sim.missionFor({ ufo, diff, month, night, seed, kind, landed });
  const B = OV.Battle.create(mission);
  drain(OV.Battle.beginBattle(B));
  let firstContact = null;
  while (B.phase !== 'over' && B.turn <= turns) {
    for (const u of B.units) {
      if (u.side !== 'xcom' || !(u.status === 'ok')) continue;
      if (!u.kneel) drain(OV.Act.perform(B, { type: 'kneel', unitId: u.id }));
    }
    if (firstContact === null && B.units.some(u => u.side === 'alien' && u.status === 'dead' && !u.crashDead)) firstContact = B.turn;
    if (B.phase !== 'over') drain(OV.Battle.endPlayerTurn(B));
  }
  const out = B.phase === 'over' ? B.result || OV.Battle.outcome(B) : 'cap';
  const xd = B.units.filter((u) => u.origSide === 'xcom' && u.status === 'dead').length;
  const alive = B.units.filter((u) => u.side === 'alien' && (u.status === 'ok' || u.status==='panic')).length;
  return { out, turns: B.turn, xd, ak: B.stats.aliensKilled, alive, firstContact };
}
const R = { camp: [], bot: [] };
for (let s = 1; s <= seeds; s++) {
  R.camp.push(camper(s));
  const b = sim.runBattle({ ufo, diff, month, night, seed: s, kind, turns, landed, check: false });
  R.bot.push({ out: b.outcome, turns: b.turns, xd: b.xcomDead, ak: b.aliensKilled });
}
for (const k of ['camp', 'bot']) {
  const r = R[k];
  const win = r.filter((x) => x.out === 'win').length, cap = r.filter((x) => x.out === 'cap').length;
  const avg = (f) => (r.reduce((s, x) => s + f(x), 0) / r.length).toFixed(2);
  console.log(k.padEnd(5), ufo, kind||'', 'diff', diff, 'm', month, 'night', night, '| win', win + '/' + r.length, 'cap', cap, 'xcomDead', avg((x) => x.xd), 'turns', avg((x) => x.turns), 'killed', avg(x=>x.ak), k==='camp' ? 'alienAliveAtEnd ' + avg(x=>x.alive) : '');
}
if (args.v) console.log(JSON.stringify(R.camp));
