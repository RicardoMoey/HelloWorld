await page.getByRole('button', { name: 'Iniciar missão' }).click();
const t0=Date.now();
for (let i=0;i<60;i++){ await S.sleep(500); if (await page.evaluate(()=>OV.Scenes.top().id==='battle')) break; }
await S.sleep(3000);
const f = await shot('battle_start');
const st = await page.evaluate(()=>JSON.stringify(OV.BattleUI.debug.state()).slice(0,1500));
return { secs:(Date.now()-t0)/1000, f, st, sc: await page.evaluate(()=>OV.Scenes.top().id) };
