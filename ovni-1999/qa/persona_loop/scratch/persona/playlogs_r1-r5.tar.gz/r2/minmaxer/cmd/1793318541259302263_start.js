await page.getByText('CONCLUÍDO').click(); await S.sleep(1000);
await page.getByText('INICIAR MISSÃO').click(); 
const t0=Date.now();
for (let i=0;i<60;i++){ await S.sleep(500); if (await page.evaluate(()=>OV.Scenes.top().id==='battle' && !!OV.BattleUI.debug)) break; }
await S.sleep(2500);
const f = await shot('battle_start');
const st = await page.evaluate(()=>{const B=OV.BattleUI.scene && OV.BattleUI.scene.B || null; const s=OV.BattleUI.debug.state(); return JSON.stringify(s).slice(0,1500);});
return { secs:(Date.now()-t0)/1000, f, st, sc: await page.evaluate(()=>OV.Scenes.top().id) };
