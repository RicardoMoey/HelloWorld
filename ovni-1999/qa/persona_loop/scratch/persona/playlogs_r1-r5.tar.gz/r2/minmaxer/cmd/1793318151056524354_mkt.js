await page.keyboard.press('8'); await S.sleep(1200);
const f = await shot('market');
const t = await page.evaluate(() => document.body.innerText.slice(300, 4000));
return { f, t, stores: await page.evaluate(()=>JSON.stringify(OV.Game.G.bases[0].stores)) };
