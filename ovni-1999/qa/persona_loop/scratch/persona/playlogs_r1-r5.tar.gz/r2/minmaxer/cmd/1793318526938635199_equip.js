await page.keyboard.press('e'); await S.sleep(1500);
const f = await shot('equip');
return { f, sc: await page.evaluate(()=>OV.Scenes.top().id), t: await page.evaluate(()=>document.body.innerText.slice(0,1500)) };
