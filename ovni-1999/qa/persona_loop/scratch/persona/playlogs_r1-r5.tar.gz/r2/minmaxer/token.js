// "Resposta simbólica" a um terror: chegar, ficar na nave, abortar no turno 1. Pontuação vs. ignorar.
const sim = require('/home/user/HelloWorld/ovni-1999/tools/sim.js');
const OV = globalThis.OV;
const drain = (g) => { let r; while (!(r = g.next()).done); return r.value; };
const S = OV.Data.scoring;
for (const month of [0, 1, 2, 4, 6]) {
  const rows = [];
  for (let seed = 1; seed <= 8; seed++) {
    const mission = sim.missionFor({ kind: 'terror', diff: 2, month, seed });
    mission.squad = mission.squad.slice(0, 1);
    const B = OV.Battle.create(mission);
    drain(OV.Battle.beginBattle(B));
    const civs = B.units.filter((u) => u.origSide === 'civ').length;
    const r = OV.Battle.abort(B);
    const d = OV.Battle.debrief(B, { researched: [] });
    rows.push([civs, d.score, r.craftLost]);
  }
  const ign = month < (S.terrorSiteExpiredByMonth || []).length ? S.terrorSiteExpiredByMonth[month] : S.terrorSiteExpired;
  const avg = rows.reduce((s, r) => s + r[1], 0) / rows.length;
  console.log('mês', month, 'abortar no turno 1: média', avg.toFixed(0), 'pontos (civis', rows.map((r) => r[0]).join('/'), ', nave perdida?', rows.some((r) => r[2]), ') · ignorar: −' + ign);
}
