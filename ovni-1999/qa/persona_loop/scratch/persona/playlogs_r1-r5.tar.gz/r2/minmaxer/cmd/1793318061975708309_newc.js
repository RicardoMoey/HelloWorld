await page.getByText('NOVA CAMPANHA').click();
await S.sleep(800);
const f = await shot('newcamp');
return { f, txt: await page.evaluate(() => document.body.innerText.slice(0, 1500)) };
