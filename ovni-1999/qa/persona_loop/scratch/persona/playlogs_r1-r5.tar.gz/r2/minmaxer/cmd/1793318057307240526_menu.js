const f = await shot('menu');
return { f, txt: await page.evaluate(() => document.body.innerText.slice(0, 800)), scene: await page.evaluate(()=>OV.Scenes.top().id) };
