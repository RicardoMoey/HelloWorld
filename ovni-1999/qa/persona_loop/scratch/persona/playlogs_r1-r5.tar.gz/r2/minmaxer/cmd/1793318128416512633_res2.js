await S.sleep(300);
const f = await shot('research');
return { f, txt: await page.evaluate(() => document.body.innerText.slice(300, 3000)) };
