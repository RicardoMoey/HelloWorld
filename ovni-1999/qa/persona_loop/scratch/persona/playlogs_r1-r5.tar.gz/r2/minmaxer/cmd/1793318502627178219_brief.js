await page.keyboard.press('Enter'); await S.sleep(2000);
const f = await shot('briefing');
return { f, sc: await page.evaluate(()=>OV.Scenes.top().id), t: await page.evaluate(()=>document.body.innerText.slice(0,2000)), m: await page.evaluate(()=>{const M=OV.Game.G.activeMission; return JSON.stringify(M).slice(0,600);}) };
