await page.keyboard.press('0'); await S.sleep(400);
await page.keyboard.press('4'); await S.sleep(300);
const t0 = Date.now();
for (let i=0;i<120;i++) { await S.sleep(500); const s = await page.evaluate(()=>document.querySelector('.df-root, .dogfight, #dogfight') ? 1 : 0); const txt = await page.evaluate(()=>document.body.innerText); if (/ABATIDO|DESPENHOU|DESTRU|FUGIU|ESCAPOU/i.test(txt) && i>2) break; }
const f = await shot('df_end');
return { secs: (Date.now()-t0)/1000, f, t: await page.evaluate(()=>document.body.innerText.slice(0,2000)) };
