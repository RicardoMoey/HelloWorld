H.goal = H.goal || {x:18,y:24};
H.turnPlay = async (step) => {
  const out=[]; step = step||5;
  const sq = await H.squad();
  let k=0;
  for (const u of sq) {
    k++;
    let s = await H.ui(); if (s.result || s.ended) break;
    if (!(await H.selName(u.name))) continue;
    s = await H.ui(); if (!s.unit || s.unit.id!==u.id) { out.push(u.name+' sel fail'); continue; }
    if (s.visibleAliens.length) { const r = await H.fire(s.visibleAliens[0].id); out.push(u.name.split(' ')[0]+' F '+r); s = await H.ui(); if (s.visibleAliens.length && s.unit && s.unit.tu>=20) { const r2=await H.fire(s.visibleAliens[0].id); out.push('  F2 '+r2);} continue; }
    // move toward goal
    const dx = H.goal.x - u.x, dy = (H.goal.y + ((k%5)-2)*2) - u.y; const d=Math.max(1,Math.hypot(dx,dy));
    const n = Math.min(step, d);
    let tx = Math.round(u.x + dx/d*n), ty = Math.round(u.y + dy/d*n);
    let r = await H.moveTo(tx,ty);
    if (typeof r==='string' && r.startsWith('no path')) { r = await H.moveTo(tx-1,ty+1); }
    out.push(u.name.split(' ')[0]+' M '+tx+','+ty+' '+JSON.stringify(r));
    s = await H.ui();
    if (s.visibleAliens.length && s.unit && s.unit.tu>=15) { const r2=await H.fire(s.visibleAliens[0].id); out.push('  F '+r2); }
  }
  return out;
};
H.endTurn = async () => {
  const t0=Date.now(); const s0=await H.ui();
  await H.tap(1124,766); await H.sleep(500);
  const b = await H.find('Terminar turno','#modals button'); if (b) await H.tap(b.x,b.y);
  let s; for(let i=0;i<400;i++){ s=await H.ui(); if(!s || s.result || s.ended) break; if(s.side==='xcom' && !s.playing && s.turn>s0.turn) break; await H.sleep(200);} 
  H.log('end turn → turn '+(s&&s.turn)+' in '+((Date.now()-t0)/1000)+'s');
  return [(Date.now()-t0)/1000, s && s.turn, s && s.result];
};
H.status = () => H.page.evaluate(()=>{const B=OV.Game.B; return {al:B.units.filter(u=>u.side==='alien').map(u=>u.id+':'+u.status+'@'+u.x+','+u.y+','+u.z), xs:B.units.filter(u=>u.side==='xcom').map(u=>u.name.split(' ')[0]+':'+u.status+' hp'+u.hp)};});
return 'ok';
