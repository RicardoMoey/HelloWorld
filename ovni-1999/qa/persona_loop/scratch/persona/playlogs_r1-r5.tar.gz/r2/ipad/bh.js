H.waitIdle = async (ms) => { const t0=Date.now(); let s; while(Date.now()-t0<(ms||20000)){ s=await H.ui(); if(!s || (!s.playing)) return s; await H.sleep(150);} return s; };
H.squad = () => H.page.evaluate(()=>OV.Game.B.units.filter(u=>u.side==='xcom'&&u.onMap&&u.x>=0&&u.status==='ok').map(u=>({id:u.id,name:u.name,x:u.x,y:u.y,z:u.z,tu:u.tu})));
H.selName = async (nm) => { const r = await H.page.evaluate((n)=>{const b=[...document.querySelectorAll('.bs-sq')].find(q=>(q.getAttribute('aria-label')||q.innerText).includes(n)); if(!b) return null; const r=b.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2};}, nm); if(!r) return false; await H.tap(r.x,r.y); await H.sleep(350); return true; };
H.fire = async (alienId) => {
  let s = await H.ui(); if (!s.unit) return 'nounit';
  const hand = await H.page.evaluate(()=>{const b=[...document.querySelectorAll('.bs-hand')].find(n=>!n.classList.contains('empty')); if(!b) return null; const r=b.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2, l:b.getAttribute('aria-label')};});
  if (!hand) return 'nohand';
  await H.tap(hand.x, hand.y); await H.sleep(400);
  s = await H.ui(); if (!s.menu) return 'nomenu';
  const ents = s.menu.entries.map((e,i)=>({...e,i})).filter(e=>e.enabled && e.cost<=s.unit.tu && !/Lançar|Atirar|Recarreg/i.test(e.label));
  if (!ents.length) { await H.longPress(700,400,700); return 'nofire'; }
  ents.sort((a,b)=> (b.acc - a.acc)); const e = ents[0];
  const items = await H.page.evaluate(()=>[...document.querySelectorAll('.bs-menu-item')].map(n=>{const r=n.getBoundingClientRect(); return {x:r.x+r.width/2,y:r.y+r.height/2,t:n.innerText.replace(/\s+/g,' ')};}));
  const it = items.find(x=>x.t.includes(e.label)); if(!it) return 'noitem';
  await H.tap(it.x, it.y); await H.sleep(350);
  const p = await H.page.evaluate((id)=>OV.BattleUI.debug.unitScreen(id), alienId);
  await H.tap(p.x,p.y); await H.sleep(350);
  s = await H.ui(); if (s.mode!=='target') return 'notarget';
  const lab = s.target && s.target.label;
  await H.tap(p.x,p.y); await H.sleep(300);
  await H.waitIdle(25000);
  const st = await H.page.evaluate((id)=>{const u=OV.Game.B.units.find(u=>u.id===id); return u&&u.status;}, alienId);
  return e.label+' '+lab+' → '+st;
};
H.moveTo = async (x,y) => {
  const p = await H.ts(x,y,0);
  if (p.x<200||p.x>1150||p.y<60||p.y>690) { await H.page.evaluate(([x,y])=>OV.BattleUI.debug.centre && OV.BattleUI.debug.centre(x,y,0),[x,y]); await H.sleep(300); }
  const q = await H.ts(x,y,0);
  await H.tap(q.x,q.y); await H.sleep(350);
  let s = await H.ui();
  if (!s.pathSteps || /bloque|alcance/i.test(s.pathLabel||'')) { await H.longPress(q.x,q.y,700); return 'no path: '+s.pathLabel; }
  await H.tap(q.x,q.y); await H.sleep(250);
  s = await H.waitIdle(25000);
  return s.unit ? [s.unit.x,s.unit.y,s.unit.tu] : 'gone';
};
return 'ok';
