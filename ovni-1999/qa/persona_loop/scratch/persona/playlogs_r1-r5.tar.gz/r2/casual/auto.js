S.RPRIO = ['Kit Médico','Pistola Laser','Espingarda Laser','Autópsia: Sectoide','Ligas Alienígenas','Navegação OVNI','Fonte de Energia OVNI','Elerium-115','Pistola de Plasma','Espingarda de Plasma','Armadura Pessoal'];
S.auto = async (maxMs) => {
  const t0 = Date.now(); const L = [];
  const lg = (m) => { L.push(m); log('AUTO '+m.slice(0,300)); };
  while (Date.now()-t0 < maxMs) {
    const r = await S.play(20, Math.min(120000, maxMs-(Date.now()-t0)));
    for (const x of r.all) lg(x);
    const st = r.stop;
    if (st==='popup:researchDone') { if (await S.click(/Novo projeto/i)) { await sleep(1200); const p = await S.pickResearch(S.RPRIO); lg('  research -> '+p); if (!p) { const b=page.getByRole('button',{name:/Fechar/i}); if (await b.count()) await b.first().click(); } const back=page.getByRole('button',{name:/Voltar ao Geoscape/i}); if (await back.count()) { await back.click(); await sleep(1000);} } else await S.click(/^OK/i); continue; }
    if (st==='popup:deliveryArrived' || st==='popup:craftReady' || st==='popup:transferArrived') { await S.click(/^OK/i); continue; }
    if (st==='popup:craftArrived') { if (!(await S.click(/Regressar à base/i))) await S.click(/^OK/i); continue; }
    if (st==='cbriefing') { const sh = await shot('brief_auto'); lg('BRIEFING '+(await page.evaluate(()=>document.body.innerText.slice(0,400).replace(/\n/g,' ¦ ')))+' '+sh); await page.getByRole('button',{name:/Iniciar miss/i}).click(); await sleep(4000); const B = await S.battle(30, 8); for (const x of B) lg('  '+x.slice(0,400)); continue; }
    if (st==='cdebrief') { const sh = await shot('debrief_auto'); lg('DEBRIEF '+(await page.evaluate(()=>document.body.innerText.slice(0,300).replace(/\n/g,' ¦ ')))+' '+sh); await page.getByRole('button',{name:/Continuar/i}).click(); await sleep(1500); continue; }
    if (st==='popup:ufoDetected' || st==='popup:terrorSite') { if (await S.click(/Enviar equipa/i)) { const p = await S.pickRow('^\\s*Skyranger'); lg('  send '+p); continue; } await S.click(/^OK/i); continue; }
    if (st && st.startsWith('popup:')) { const sh = await shot('stop_'+st.replace(':','_')); lg('STOP '+st+' '+sh); return L; }
    if (st && st.startsWith('dialog:')) { const sh = await shot('stopdlg'); lg('STOPDLG '+st+' '+sh); return L; }
    if (st==='limit') continue;
    const sh = await shot('stop_other'); lg('STOP '+st+' '+sh); return L;
  }
  return L;
};
return 'ok';
