S.canHit = (uid, aid) => page.evaluate(([uid,aid])=>{ const B=OV.Game.B; const u=OV.BUnits.findUnit(B,uid), a=OV.BUnits.findUnit(B,aid); if(!u||!a) return false; const hand = u.R ? 'R' : 'L'; try { const v = OV.Act.validate(B,{type:'shoot', unitId:uid, hand:'R', mode:'aimed', target:{x:a.x,y:a.y,z:a.z}}); return v; } catch(e){ return {err:String(e)}; } }, [uid,aid]);
S.sofiaTurn = async (maxMovers) => {
  const out = [];
  const sq = await S.squad();
  let moved = 0;
  for (const u of sq) {
    const s0 = await S.bs(); if (!s0 || s0.ended || s0.result || s0.side!=='xcom') break;
    const ok = await S.selectByStrip(u.id);
    if (!ok) { out.push(u.name+': nosel'); continue; }
    let va = (await S.bs()).visibleAliens || [];
    if (va.length) {
      // nearest visible alien
      const me = await page.evaluate((id)=>{const u=OV.BUnits.findUnit(OV.Game.B,id); return [u.x,u.y]}, u.id);
      va.sort((a,b)=>Math.hypot(a.x-me[0],a.y-me[1])-Math.hypot(b.x-me[0],b.y-me[1]));
      let v = await S.canHit(u.id, va[0].id);
      if (!v || !v.ok) {
        const t = await S.pickToward(u.id, 0.45, va[0].x, va[0].y);
        if (t) { const r = await S.moveTo(t); out.push(u.name+' approach '+r); }
      }
      for (let k=0;k<2;k++){ const s=await S.bs(); if(!s||s.ended||s.result) break; const vv=(s.visibleAliens||[]); if(!vv.length) break; const r = await S.fire(vv[0].id); out.push(u.name+' fire '+r.slice(0,80)); }
      continue;
    }
    if (moved >= maxMovers) continue;
    const t = await S.pickAdvance(u.id, 0.5);
    if (!t) { out.push(u.name+': no target'); continue; }
    const r = await S.moveTo(t); moved++;
    out.push(u.name+' move '+r);
  }
  return out;
};
return 'ok';
