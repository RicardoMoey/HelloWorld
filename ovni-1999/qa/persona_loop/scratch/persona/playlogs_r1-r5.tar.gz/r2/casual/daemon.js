const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const DIR = __dirname;
const GAMEPORT = process.argv[2];
const T0 = Date.now();
const S = { log: [], errors: [], shot: 0 };
function log(m){ const l = new Date().toISOString().slice(11,19)+' +'+((Date.now()-T0)/60000).toFixed(1)+'min '+m; S.log.push(l); fs.appendFileSync(DIR+'/log.txt', l+'\n'); }
(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2, hasTouch: false, locale: 'pt-PT' });
  const page = await ctx.newPage();
  page.on('pageerror', e => { S.errors.push('pageerror: '+e.message); log('PAGEERROR '+e.message); });
  page.on('console', m => { if (m.type()==='error') { S.errors.push('console: '+m.text()); log('CONSOLEERR '+m.text()); } });
  page.on('dialog', d => { log('DIALOG '+d.message()); d.accept(); });
  await page.goto('http://127.0.0.1:'+GAMEPORT+'/ovni-1999/index.html?nosw=1');
  log('loaded');
  const shot = async (name) => { const p = DIR+'/shots/'+String(++S.shot).padStart(3,'0')+'-'+name+'.png'; await page.screenshot({ path: p }); return p; };
  const srv = http.createServer((req, res) => {
    let body = ''; req.on('data', d => body += d); req.on('end', async () => {
      try {
        const fn = new Function('page','ctx','S','log','shot','sleep','require', 'return (async()=>{'+body+'})()');
        const r = await fn(page, ctx, S, log, shot, ms => new Promise(r => setTimeout(r, ms)), require);
        res.end(typeof r === 'string' ? r : JSON.stringify(r === undefined ? null : r, null, 1));
      } catch (e) { res.end('ERR '+(e && e.stack || e)); }
    });
  });
  srv.listen(+process.argv[3], '127.0.0.1', () => log('daemon ready'));
})();
