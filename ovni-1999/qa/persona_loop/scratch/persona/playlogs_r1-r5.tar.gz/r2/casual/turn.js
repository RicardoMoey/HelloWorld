S.visAliens = () => page.evaluate(() => { const B=OV.Game.B; const s=OV.BattleUI.debug.state(); return (s.visibleAliens||[]).map(a=> (typeof a==='object'?a:{id:a})); });
S.sofiaTurn = async (maxMovers) => {
  const out = [];
  const sq = await S.squad();
  let moved = 0;
  for (const u of sq) {
    const s0 = await S.bs(); if (s0.ended || s0.result || s0.side!=='xcom') break;
    const ok = await S.selectByStrip(u.id);
    if (!ok) { out.push(u.name+': nosel'); continue; }
    let va = (await S.bs()).visibleAliens || [];
    if (va.length) {
      const aid = typeof va[0]==='object' ? va[0].id : va[0];
      for (let k=0;k<2;k++){ const r = await S.fire(aid); out.push(u.name+' fire '+r); const s=await S.bs(); if(s.ended||s.result) break; va = s.visibleAliens||[]; if(!va.length) break; }
      continue;
    }
    if (moved >= maxMovers) continue;
    const t = await S.pickAdvance(u.id, 0.5);
    if (!t) { out.push(u.name+': no target'); continue; }
    const r = await S.moveTo(t); moved++;
    const s = await S.bs();
    out.push(u.name+' move '+r+' -> '+JSON.stringify([s.unit&&s.unit.x,s.unit&&s.unit.y])+' va='+JSON.stringify(s.visibleAliens));
  }
  return out;
};
return 'ok';
