S.battle = async (maxTurns, movers) => {
  const L=[]; 
  for (let t=0;t<maxTurns;t++){
    let s = await S.bs(); if (!s || s.ended || s.result) break;
    if (s.report) { L.push('T'+s.turn+' REPORT '+JSON.stringify(s.report).slice(0,600)); const sh=await shot('report_T'+s.turn); L.push('  '+sh); const b=page.getByRole('button',{name:/Entendido|Fechar|OK/i}); if (await b.count()) await b.first().click().catch(()=>{}); await sleep(400); }
    const r = await S.sofiaTurn(movers);
    s = await S.bs(); if (!s) { L.push('T? '+r.join(' | ')); break; }
    L.push('T'+s.turn+': '+r.join(' | '));
    if (s.ended || s.result) break;
    const d = await S.endTurn();
    s = await S.bs(); if (!s) { L.push('  alien -> scene changed'); break; }
    const alive = await page.evaluate(()=>OV.Game.B.units.filter(u=>u.side==='xcom'&&u.status==='ok').length);
    L.push('  alien '+d+'ms alive='+alive+' va='+JSON.stringify(s.visibleAliens));
  }
  return L;
};
return 'ok';
