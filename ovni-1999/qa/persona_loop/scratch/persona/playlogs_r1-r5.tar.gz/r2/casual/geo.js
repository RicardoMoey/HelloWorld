S.state = () => page.evaluate(()=>{const top=OV.Scenes.top().id; const c=(OV.GeoUI.current&&OV.GeoUI.current())||{}; const G=OV.Game.G; const pop=document.querySelector('.geo-pop:not(.out)'); const dlg=document.querySelector('.geo-dlg'); return {top, date:G?OV.U.fmtDate(G.t):'', popup:c.popup||null, dialog:c.dialog||null, speed:c.speed, funds:G&&G.funds, pop: pop? pop.innerText.slice(0,900):null, dlg: dlg? dlg.innerText.slice(0,900):null}});
S.waitEvent = async (ms) => { const end=Date.now()+ms; let s; while(Date.now()<end){ s = await S.state(); if (s.top!=='geoscape'||s.popup||s.dialog) return s; await page.waitForTimeout(400);} return s; };
S.click = async (re, scope) => { const loc = page.locator(scope || '.geo-pop:not(.out), #modals .modal, .geo-dlg').getByRole('button', {name: re}).first(); if (!(await loc.count())) return false; await loc.click({timeout:5000}); await sleep(700); return true; };
S.speed = async (label) => { await page.locator('.geo-sp', {hasText: label}).first().click(); };
S.seen = S.seen || {};
S.snap = async (key) => { if (!S.seen[key]) { S.seen[key]=1; return await shot('pop_'+key); } return null; };
return 'ok';
