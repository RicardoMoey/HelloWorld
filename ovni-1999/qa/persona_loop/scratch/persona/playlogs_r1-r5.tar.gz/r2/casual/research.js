S.pickResearch = async (names) => { const r = await page.evaluate((names)=>{ const bs=[...document.querySelectorAll('#modals .modal button')]; for (const nm of names){ for (const b of bs){ let e=b; for(let k=0;k<4&&e;k++){ e=e.parentElement; if(e && e.innerText.trim().startsWith(nm)) { b.click(); return nm;} } } } return null; }, names); await sleep(900); return r; };
return 'ok';
