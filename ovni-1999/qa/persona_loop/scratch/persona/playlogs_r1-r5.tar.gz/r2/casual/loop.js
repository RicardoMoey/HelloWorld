S.geoLoop = async (maxEvents, maxMs, speedLabel) => {
  const out = []; const t0 = Date.now();
  for (let i=0;i<maxEvents && Date.now()-t0<maxMs;i++) {
    let s = await S.state();
    if (s.top==='geoscape' && !s.popup && !s.dialog) { try { await S.speed(speedLabel||'1 hora'); } catch(e){} s = await S.waitEvent(Math.max(1000, maxMs-(Date.now()-t0))); }
    if (s.top!=='geoscape') { out.push(s.date+' SCENE '+s.top); return {out, stop:s.top}; }
    if (s.popup) {
      const txt = (s.pop||'').replace(/\n+/g,' ¦ ').slice(0,300);
      out.push(s.date+' POP['+s.popup+'] '+txt);
      const sh = await S.snap(s.popup); if (sh) out.push('   shot '+sh);
      const p = s.popup;
      if (p==='ufoDetected') { if (await S.click(/^Intercetar/i)) continue; }
      if (/crash|shotDown|ufoDown|ufoLanded|landed/i.test(p)) { if (await S.click(/Enviar equipa/i)) continue; }
      if (/arriv|atSite|craftAt|teamAt|dawn/i.test(p) || /EQUIPA NO LOCAL|AMANHECEU/.test(s.pop||'')) {
        if (/noite/i.test(s.pop||'') && await S.click(/Esperar pelo dia/i)) continue;
        if (await S.click(/Iniciar miss/i)) continue;
      }
      return {out, stop:'popup:'+p};
    }
    if (s.dialog) {
      out.push(s.date+' DLG['+s.dialog+'] '+(s.dlg||'').replace(/\n+/g,' ¦ ').slice(0,300));
      const sh = await S.snap('dlg_'+s.dialog); if (sh) out.push('   shot '+sh);
      return {out, stop:'dialog:'+s.dialog};
    }
  }
  return {out, stop:'limit'};
};
return 'ok';
