S.pickRow = async (re) => { const ok = await page.evaluate((src)=>{ const re=new RegExp(src,'i'); const d=document.querySelector('.geo-dlg'); if(!d) return false; const rows=[...d.querySelectorAll('button, [role=button], li, .geo-row')]; for (const r of rows){ if (re.test(r.innerText) && !r.disabled && !r.getAttribute('aria-disabled')) { r.click(); return r.innerText.slice(0,80);} } return false; }, typeof re==="string"?re:re.source); await sleep(900); return ok; };
S.dogfight = async () => {
  const out=[]; const t0=Date.now();
  while (Date.now()-t0 < 90000) {
    const top = await page.evaluate(()=>OV.Scenes.top().id);
    if (top!=='dogfight') break;
    const txt = await page.evaluate(()=>document.body.innerText);
    if (/Desligar os m[ií]sseis\?/.test(txt)) { const b=page.getByRole('button',{name:/Desligar m[ií]sseis/i}); if (await b.count()) { await b.first().click(); out.push('desligou mísseis'); } }
    await sleep(1000);
  }
  return out;
};
const prevLoop = S.geoLoop;
S.play = async (maxEvents, maxMs) => {
  const all=[]; const t0=Date.now();
  for (let i=0;i<maxEvents && Date.now()-t0<maxMs;i++){
    const r = await prevLoop(10, maxMs-(Date.now()-t0));
    all.push(...r.out);
    if (r.stop==='dialog:intercept' && /leva a equipa/.test((await S.state()).dlg||'')) { const p = await S.pickRow('^\\s*Skyranger'); all.push('  -> send '+p); if(!p){ await page.keyboard.press('Escape'); } continue; }
    if (r.stop==='dialog:intercept') { const p = await S.pickRow('^\\s*Intercetor-\\d[\\s\\S]*Pronta'); all.push('  -> intercept '+p); if(!p){ await page.keyboard.press('Escape'); all.push('  sem intercetor pronto'); } continue; }
    if (r.stop==='dialog:sendTeam' || /dialog:send|dialog:team/.test(r.stop)) { const p = await S.pickRow('^\\s*Skyranger[\\s\\S]*soldados'); all.push('  -> send '+p); if(!p) return {all, stop:r.stop}; continue; }
    if (r.stop==='dogfight') { const d = await S.dogfight(); all.push('  dogfight '+d.join(',')); continue; }
    return {all, stop:r.stop};
  }
  return {all, stop:'limit'};
};
return 'ok';
