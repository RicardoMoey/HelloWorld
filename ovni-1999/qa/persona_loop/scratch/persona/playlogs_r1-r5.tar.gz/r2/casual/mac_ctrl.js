const { chromium } = require('playwright');
(async () => {
  const GP = require('fs').readFileSync(__dirname+'/gport','utf8').trim();
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport:{width:1440,height:900}, deviceScaleFactor:2, userAgent:'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' });
  await ctx.addInitScript(()=>{ Object.defineProperty(Navigator.prototype,'platform',{get:()=> 'MacIntel'}); try{localStorage.clear();}catch(e){} });
  const page = await ctx.newPage();
  const errs=[]; page.on('pageerror',e=>errs.push(e.message));
  await page.goto('http://127.0.0.1:'+GP+'/ovni-1999/index.html?battle=medium_scout&seed=7&nosw=1');
  await page.waitForFunction(() => window.OV && OV.BattleUI && OV.BattleUI.debug.state(), null, { timeout: 30000 });
  await page.waitForTimeout(1500);
  const txt='';
  const bb = page.getByRole('button',{name:/Entendido|Fechar/i}); if (await bb.count()) await bb.first().click().catch(()=>{});
  // select aim mode via right hand slot
  await page.locator('.bs-hand[data-hand="R"]').click(); await page.waitForTimeout(400);
  let s = await page.evaluate(()=>OV.BattleUI.debug.state());
  const menu = s.menu;
  // pick first enabled shot
  const idx = s.menu ? s.menu.entries.findIndex(e=>e.enabled && /tiro/i.test(e.label)) : -1;
  if (idx>=0) await page.locator('.bs-menu-item').nth(idx).click();
  await page.waitForTimeout(400);
  s = await page.evaluate(()=>OV.BattleUI.debug.state());
  const modeBefore = s.mode;
  // ctrl+click on a tile a few tiles away
  const u = s.unit; const pt = await page.evaluate(([x,y,z])=>OV.BattleUI.debug.tileToScreen(x,y,z), [u.x-3,u.y-3,u.z]);
  await page.mouse.move(pt.x, pt.y); await page.keyboard.down('Control'); await page.waitForTimeout(150);
  const s1 = await page.evaluate(()=>OV.BattleUI.debug.state());
  await page.mouse.click(pt.x, pt.y, {modifiers:['Control']}); await page.keyboard.up('Control'); await page.waitForTimeout(800);
  const s2 = await page.evaluate(()=>OV.BattleUI.debug.state());
  await page.screenshot({path: __dirname+'/shots/mac_ctrlclick.png'});
  // meta-click
  console.log(JSON.stringify({txt:txt.slice(0,200), isMac: await page.evaluate(()=>navigator.platform), modeBefore, targetHover: s1.target, modeAfter: s2.mode, tuBefore: s.unit.tu, tuAfter: s2.unit.tu, errs}, null, 1));
  await b.close();
})();
